SubSonic Forums - A SubSonic Project
http://subsonicproject.com/

Getting Started
---------------

1) Get the code ( http://code.google.com/p/subsonicforums/ )
2) Run the database scripts in SubSonic.Forums.Database\Quick Scripts
   a) Execute "1 Create Database.sql" on master
   b) Execute "2 Create Resources.sql" on SubSonicForums
   c) Execute "3 Populate Data.sql" on SubSonicForums
   d) Execute "4 Enable FullText.sql" on SubSonicForums
3) Create the provider services database
   a) Create a database named ASPNETDB using SQL Management Studio
   b) Run "Add Services.cmd" in the Solution directory
4) Build the website
5) Ensure the configuration is pointing to the local SubSonicForums database
6) Launch the website (Forums\Default.aspx)

Build Instructions
------------------

There is more than one Solution. One is useful for those users who have Visual Studio Team System
Edition while others with Visual Studio Pro Edition can use the other.

SubSonicForums.sln (VSTS 2005)
SubSonicForums.Db.sln (VS Pro 2005)

The Team System version has a test project that only recognized by Team System while the Db solution
has a Database project only recognized by VS Pro.

Near Future Plans
-----------------

The VS 2008 will be out soon and this project will move to it immediately. Unit testing will start
using the newly built-in features of VS 2008 that have been in VSTS 2005. At that point there will 
be just one Solution for the project as everything will be merged together, however, an alternate
Solution may be created to support Express editions of Visual Studio 2008.

Notes
-----

The Database project is only supposed in VS Pro 2005 and above, but it is not necessary in order
to run the creation scripts for the SubSonicForums database. The scripts can be run successfully 
with SQL Management Studio with the same results. The Database project simply has all of the 
individual resources (tables, stored procedures, functions and views) for ease of maintenance
while the master creation scripts are generated as the individual scripts are updated.

Source Control:
http://code.google.com/p/subsonicforums/

Issue Tracker:
http://code.google.com/p/subsonicforums/issues/

Project Members:
http://code.google.com/u/robconery/ (Rob Conery, Owner)
http://code.google.com/u/offwhite/ (Brennan Stehling, Contributor)
http://code.google.com/u/kfricovsky/ (Kevin Fricovsky, Contributor)
http://code.google.com/u/canofunk/
http://code.google.com/u/scbarry/
http://code.google.com/u/@VhRfRFVSAhBFWgN7/
http://code.google.com/u/datacop/
