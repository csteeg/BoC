using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SubSonic.Forums.Tests {
    /// <summary>
    /// Summary description for Formatting_Censorship
    /// </summary>
    [TestClass]
    public class Formatting_Censorship {
        public Formatting_Censorship() {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Censor_Basic() {
            Post p = new Post();
            p.Subject = "Fuck this shit";
            p.PostText = "<script>alert('boff')</script>";

            p.Subject = SubSonic.Forums.ForumService.CleanPostText(p.Subject);
            p.PostText = SubSonic.Forums.ForumService.CleanPostText(p.PostText);

            Assert.IsTrue(p.Subject != "Fuck this shit");
            Assert.IsTrue(p.PostText != "<script>alert('boff')</script>");
        }
    }
}
