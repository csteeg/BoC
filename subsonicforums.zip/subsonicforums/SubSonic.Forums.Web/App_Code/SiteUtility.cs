using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// A class for you to use as needed; extend's SubSonic's core utility set
/// </summary>
public class SiteUtility
{
    /// <summary>
    /// This is the Role that we evaluate for CMS editing privvies
    /// Change as needed
    /// </summary>
    const string CONTENT_EDITOR_ROLE = "Content Editor";
    const string ADMIN_ROLE = "Administrator";
    const string SYS_ADMIN_ROLE = "SystemAdministrator";
   
    public static bool UserCanEdit() {
        return HttpContext.Current.User.IsInRole(CONTENT_EDITOR_ROLE);
    }
    public static bool UserIsAdmin() {
        bool result = HttpContext.Current.User.IsInRole(ADMIN_ROLE) || HttpContext.Current.User.IsInRole(SYS_ADMIN_ROLE);
        return result;
    }
    public static string GetUserName(){
        string result = "";
        if (HttpContext.Current != null) {
            result = HttpContext.Current.User.Identity.Name;
        }
        return result;
    }
}
