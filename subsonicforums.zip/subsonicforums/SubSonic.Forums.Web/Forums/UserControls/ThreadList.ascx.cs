using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;

public partial class Forums_UserControls_ThreadList : System.Web.UI.UserControl {

    int forumID = 0;
    int currentPageNumber = 1;
    string _forumUrl = String.Empty;
    protected void Page_Load(object sender, EventArgs e) {

    }
    public void LoadThreadsByForum(int _forumID, int pageNumber, string forumUrl) {
        forumID = _forumID;
        currentPageNumber = pageNumber;
        rptThreads.DataSource = ForumService.GetForumThreadList(forumID, pageNumber, SiteUtility.GetUserName());
        rptThreads.DataBind();
        LoadPageCount();
    }
    public void LoadThreadsByAuthor(string authorName, int pageNumber) {
        currentPageNumber = pageNumber;
        rptThreads.DataSource = ForumService.GetForumThreadList(authorName, pageNumber);
        rptThreads.DataBind();
    }


    void LoadPageCount() {

        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        string pageLinks = "";

        int threadCount = new SubSonic.Query(Tables.Thread).WHERE(Thread.Columns.Deleted, false).AND(Thread.Columns.ForumID, forumID).GetCount(Thread.Columns.ThreadID);
        int pageCount = 0;
        int pageSize = 50;
        string pagerFormat = "<a href='" + _forumUrl + "?pg={0}'>{0}</a> | ";

        if (threadCount > pageSize) {
            pageCount = threadCount / pageSize;
            //0 offset plus the leftovers
            pageCount += 2;
            for (int i = 1; i < pageCount; i++) {
                if (i == currentPageNumber) {
                    sb.Append("<b>" + i.ToString() + "</b> | ");
                } else {
                    sb.AppendFormat(pagerFormat, i.ToString());

                }
            }

            pageLinks = sb.ToString();
            pageLinks = SubSonic.Sugar.Strings.Chop(pageLinks, 3);
        }

        litPageCount.Text = pageLinks;
        litPageCount2.Text = pageLinks;

    }

    protected string GetReadClass(object userHasRead) {
        bool bRead = (bool)userHasRead;
        string result = "unreadthread";
        if (bRead)
            result = "readthread";

        return result;
    }

}
