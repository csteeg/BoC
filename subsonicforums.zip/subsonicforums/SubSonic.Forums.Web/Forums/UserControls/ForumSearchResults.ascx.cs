using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;

public partial class Forums_UserControls_ForumSearchResults : System.Web.UI.UserControl {

    private string _linkTarget="";

    public string LinkTarget {
        get { return _linkTarget; }
        set { _linkTarget = value; }
    }


    private int _resultCount=0;

    public int ResultCount {
        get { return _resultCount; }
    }
	
    
    protected void Page_Load(object sender, EventArgs e) {

    }
    void SearchCMS(string query) {
        rptResults.DataSource=SPs.CmsSearch(query).GetReader();
        rptResults.DataBind();
        rptResults.Visible = rptResults.Items.Count > 0;
    }
    public void SearchAllThreads(string query) {
        try {
            IDataReader rdr = SPs.SearchAllThreads(query).GetReader();
            rptSearch.DataSource = rdr;
            IsAnswerSearch = false;
            rptSearch.DataBind();
            pnlSearch.Visible = true;
        } catch(Exception x) {
            ShowFail();
        }
        CheckResults(query);
        SearchCMS(query);
    }
    void CheckResults(string query) {
        _resultCount = rptSearch.Items.Count;
        if (rptSearch.Items.Count == 0) {
            ResultMessage1.ShowFail("No results for '<i>" + query + "</i>' in the forums...");
        }
        if (rptResults.Items.Count == 0) {
            ResultMessage2.ShowFail("No results for '<i>" + query + "</i>' in the site docs...");

        }
    }
    void ShowFail() {
        ResultMessage1.ShowFail("We seem to have issues running this query for you. This can happen if your query isn't specific enough. Please try again");

    }
    bool IsAnswerSearch = true;
    protected string GetResponse(object AnswerType) {
        if (String.IsNullOrEmpty(AnswerType.ToString())) {
            return "Reply";
        } else {
            return AnswerType.ToString();
        }
    }

    public void SearchAnsweredThreads(string query) {
        try {
            IDataReader rdr = SPs.SearchAnsweredThreads(query).GetReader();
            rptSearch.DataSource = rdr;
            rptSearch.DataBind();
             pnlSearch.Visible = true;
        } catch(Exception x) {
            ShowFail();

        }
        SearchCMS(query);
        CheckResults(query);
    }

}
