using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;


public partial class Forums_UserControls_Dashboard_SearchSubscriptions : System.Web.UI.UserControl {
    protected void Page_Load(object sender, EventArgs e) {
        if (!Page.IsPostBack) {
            LoadSearches();
        }
    }

    protected void rptSearches_ItemCommand(object source, RepeaterCommandEventArgs e) {
        Literal litID = (Literal)e.Item.FindControl("litSubscriptionID");
        int subID = int.Parse(litID.Text);
        UserSearchSubscription.Delete(subID);
        LoadSearches();
    }
    void LoadSearches() {
        rptSearches.DataSource = new UserSearchSubscriptionCollection().Where("createdBy", SiteUtility.GetUserName()).Load();
        rptSearches.DataBind();
        rptSearches.Visible = rptSearches.Items.Count>0;

    }
    protected void btnGo_Click(object sender, EventArgs e) {
        UserSearchSubscription search = new UserSearchSubscription();
        search.SearchCriteria = txtSearch.Text;
        search.Save(SiteUtility.GetUserName());
        LoadSearches();
    }
}
