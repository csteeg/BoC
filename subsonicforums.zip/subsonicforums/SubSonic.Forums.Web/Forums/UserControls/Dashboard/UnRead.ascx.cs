using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;
using SubSonic;

public partial class Forums_UserControls_Dashboard_UnRead : System.Web.UI.UserControl {
    protected void Page_Load(object sender, EventArgs e) {

        DataSet ds = SPs.UserUnreadThreads(SiteUtility.GetUserName()).GetDataSet();
        rptThreads.DataSource = ds.Tables[0];
        rptThreads.DataBind();

        //the count is the second table
        int records = (int)ds.Tables[1].Rows[0][0];

        if (records > 20) {
            litCount.Text = " (20 of " + records.ToString() + ")";
        }
    }
}
