using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;
public partial class Forums_UserControls_Dashboard_ForumGroups : System.Web.UI.UserControl {
    ForumGroupCollection groups = new ForumGroupCollection();

    protected void Page_Load(object sender, EventArgs e) {

        groups = ForumService.GetForumGroups();
        rptForumGroups.DataSource = groups;
        rptForumGroups.DataBind();

    }
    protected ForumCollection GetForums(object oGroupID) {
        int groupID = (int)oGroupID;
        return groups.GetForums(groupID);

    }
}
