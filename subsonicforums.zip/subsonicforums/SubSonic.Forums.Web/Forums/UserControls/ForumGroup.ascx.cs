using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;

public partial class Forums_UserControls_ForumGroup : System.Web.UI.UserControl {

    private string _groupName;

    public string GroupName {
        get { return _groupName; }
        set { _groupName = value; }
    }
	
    private ForumCollection _forums=new ForumCollection();

    public ForumCollection Forums {
        get { return _forums; }
        set { _forums = value; }
    }
    protected void Page_Load(object sender, EventArgs e) {
        forumList.DataSource = _forums;
        forumList.DataBind();
    }
}
