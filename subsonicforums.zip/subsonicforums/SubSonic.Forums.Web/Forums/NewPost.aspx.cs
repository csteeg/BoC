using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic;
using SubSonic.Forums;



public partial class Forums_NewPost : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

    }
    protected void btnPreview_Click(object sender, EventArgs e) {
        litPreview.Text = SubSonic.Forums.ForumService.FormatPostBody(PostBody.Text);
    }
    protected void btnCancel_Click(object sender, EventArgs e) {

    }

    bool HavePreviousPosts() {
        bool result = false;
        SubSonic.Forums.Enums.PostType postType = (SubSonic.Forums.Enums.PostType)int.Parse(PostTypeID.SelectedValue);

        if (postType == SubSonic.Forums.Enums.PostType.Question || postType == SubSonic.Forums.Enums.PostType.Problem) {
            ForumSearchResults1.SearchAnsweredThreads(Subject.Text);
            if (ForumSearchResults1.ResultCount > 0) {
                result = true;
            }
        }
        return result;
        
    }
    void ToggleSearch(bool showIt) {
        pnlLookup.Visible = showIt;
        pnlNewPost.Visible = !showIt;

    }
    protected void btnPost_Click(object sender, EventArgs e) {

        SaveNewPost(true);


    }
    void SaveNewPost(bool runLookup) {
        bool executePost = runLookup;

        if (runLookup) {
            executePost = !HavePreviousPosts();
        } else {
            executePost = true;
        }
        
        if(!executePost){
            ToggleSearch(true);
        } else {

            //get the ID
            int forumID = SubSonic.Sugar.Web.QueryString<int>("f");

            if (forumID != 0) {

                //save em, then redirect to the new forum
                Post p = new Post();
                p.Subject = Subject.Text;
                p.PostText = PostBody.Text;
                p.AuthorEmail = Profile.Email;
                //new post
                int threadTypeID = int.Parse(PostTypeID.SelectedValue);

                string newPostUrl = SubSonic.Forums.ForumService.SaveNewPost(p, User.Identity.Name, forumID, threadTypeID);
                //this is the in the form "forum-name/threadID.aspx"


                //redirect to new post...
                Response.Redirect("~/forums/thread/" + newPostUrl);

            }
        }
    }
    protected void btnReturn_Click(object sender, EventArgs e) {
        ToggleSearch(false);

    }
    protected void btnNoLuck_Click(object sender, EventArgs e) {
        SaveNewPost(false);
    }
}
