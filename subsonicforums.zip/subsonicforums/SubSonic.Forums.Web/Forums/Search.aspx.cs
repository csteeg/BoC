using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Forums_Search : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        this.Title = "Forum Search";

        string passedInQuery = SubSonic.Sugar.Web.QueryString<string>("q");
        if (!Page.IsPostBack && !string.IsNullOrEmpty(passedInQuery)) {
            txtSearch.Text = passedInQuery;

            int searchAll=SubSonic.Sugar.Web.QueryString<int>("all");
            chkShowAll.Checked = searchAll > 0;
            RunSearch(passedInQuery);
        }

    }
    protected void btnGo_Click(object sender, EventArgs e) {
        string redirUrl = "search.aspx?q=" + txtSearch.Text;
        if (chkShowAll.Checked)
            redirUrl += "&all=1";

        Response.Redirect(redirUrl);
    }

    void RunSearch(string query) {
        if (chkShowAll.Checked) {
            ForumSearchResults1.SearchAllThreads(query);

        } else {
            ForumSearchResults1.SearchAnsweredThreads(query);

        }

        this.Title = "Search: " + txtSearch.Text;
    }
}
