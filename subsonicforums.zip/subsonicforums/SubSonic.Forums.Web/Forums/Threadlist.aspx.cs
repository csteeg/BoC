using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Sugar;
using SubSonic.Forums;
using System.Text;
using System.IO;

public partial class Forums_Threadlist : System.Web.UI.Page {
    protected string Gravatar = "";
    string threadbits = "";
    int threadID = 0;
    protected Thread thread = null;

    protected void Page_Load(object sender, EventArgs e) {
        threadbits = Web.QueryString<string>("p");
        //this comes in with /forum url/thread id.aspx
        string sThreadID = Path.GetFileNameWithoutExtension(threadbits);
        int.TryParse(sThreadID, out threadID);
        
        //events
        rptReplies.ItemDataBound += new RepeaterItemEventHandler(rptReplies_ItemDataBound);
        rptReplies.ItemCommand += new RepeaterCommandEventHandler(rptReplies_ItemCommand);
        
        
        
        if (!Page.IsPostBack) {

            

            if (threadID > 0) {

                LoadBits();
                
            }

        }
        rsslink.NavigateUrl = "~/forums/rss/thread/" + threadID + ".aspx";
    }



    void LoadBits() {
        thread = ForumService.GetThreadDisplay(threadID, User.Identity.Name);
        //trThreadStatus.Visible = false;

        //loop the answers and set the answer status...
        litThreadStatus.Text = "";
        if (thread.Answers.Count > 0) {
            pnlAnswered.Visible = true;
            foreach (ThreadResponse answer in thread.Answers) {
                //yah i know...
                litThreadStatus.Text +="<img src='"+Page.ResolveUrl("~/forums/forumicons/answered.png")+"' align=absmiddle>&nbsp;<a href=#"+answer.PostID.ToString()+">"+ answer.Description + " by " + answer.ResponseAuthor+"</a><br>";
            }
        }
        
        lblStartPostType.Text = thread.ThreadTypeDescription + ": ";
        //lblStartPostSubjext.Text = thread.ThreadStarter.Subject;
        lblStartPostText.Text = thread.ThreadStarter.FormattedPostText;
        lblStartPostAuthor.Text = thread.ThreadStarter.CreatedBy;
        lblStartPostDateIndo.Text = GetPostDate(thread.ThreadStarter.CreatedOn);
        lblThreadID.Text = thread.ThreadStarter.ThreadID.ToString();
        litThreadStartPostID.Text = thread.ThreadStarter.PostID.ToString();

        //tdTopic.Attributes.Add("class", thread.ThreadStarter.PostType.ToLower());
        litUnformattedPostText.Text = thread.ThreadStarter.PostText;
        string watchType = Enum.GetName(typeof(SubSonic.Forums.Enums.ThreadWatchOptions), thread.UserWatchOption);
        lstWatch.SelectedValue = watchType;
        
        lblGravatar.Text = GetGravatar(thread.ThreadStarter.AuthorEmail, 80);
        
        lblThreadUrl.Text = thread.ThreadUrl;
        lnkForumNav.NavigateUrl = "~/forums/default.aspx?f="+thread.ParentForum.ForumID;
        lnkForumNav.Text = thread.ParentForum.ForumName;
        lnkThreadTitle.Text = thread.ThreadStarter.Subject;

        lnkNewPost.NavigateUrl = "~/forums/newpost.aspx?f="+thread.Forum.ForumID.ToString();

        if (!String.IsNullOrEmpty(thread.AnswerStatus)) {
            litThreadStatus.Text = thread.AnswerStatus;
            //trThreadStatus.Visible = true;
        }

        rptReplies.DataSource = thread.Replies;
        rptReplies.DataBind();

        rptVoices.DataSource = thread.ThreadPosters;
        rptVoices.DataBind();

        

        this.Title = ForumSettings.LoadSettings().ForumName+" - "+thread.ThreadStarter.PostType + ": "+thread.ThreadStarter.Subject;
    }
    protected string GetPostDate(DateTime postDate) {
        string dateDiff = SubSonic.Sugar.Dates.ReadableDiff(postDate, DateTime.Now);
        if (String.IsNullOrEmpty(dateDiff))
            dateDiff = "just now";

        return postDate.ToShortDateString() + " (" + dateDiff + ")"; ;
    }
    protected string GetRoles(object userRoles) {
        StringBuilder sb = new StringBuilder();
        string iconFormat="<img src='"+Page.ResolveUrl("~/forums/forumicons/roles/")+"{0}.gif'><br><br>";
        if (userRoles != null) {
            string[] roles = userRoles.ToString().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in roles) {
                sb.AppendFormat(iconFormat, s);
            }
        }
        return sb.ToString();

    }
    protected string GetGravatar(string email, int size) {
        string result = "";
        if (!String.IsNullOrEmpty(email)) {
            result= SubSonic.Forums.Gravatar.GetGravatarImage(email, "");
        }
        return result;
    }
    protected void btnReply_Click(object sender, EventArgs e) {

        //save down the reply

        Post p = new Post();
        p.ThreadID = int.Parse(lblThreadID.Text);
        p.PostText = txtReplyBody.Text;
        p.Subject = "Reply: " + lnkThreadTitle.Text;
        p.AuthorEmail = Profile.Email;
        p.PostTypeID = (int)SubSonic.Forums.Enums.PostType.Reply;

        ForumService.SaveReply(p, SiteUtility.GetUserName());
        
        //redirect to refresh the page
        //Response.Redirect("~/forums/" + lblThreadUrl.Text);
        LoadBits();

    }
    protected void lnkDeleteThread_Click(object sender, EventArgs e) {

        ForumService.DeleteThread(int.Parse(lblThreadID.Text));
        Response.Redirect("~/forums");

    }

    protected void lnkEditTopic_Click(object sender, EventArgs e) {

        pnlEditThread.Visible = true;
        lblStartPostText.Visible = false;
        txtEditTopic.Text = litUnformattedPostText.Text;
    }
    protected void SaveThreadEdit(object sender, EventArgs e) {
        
        ForumService.EditPost(int.Parse(litThreadStartPostID.Text), txtEditTopic.Text, SiteUtility.GetUserName());
        pnlEditThread.Visible = false;
        lblStartPostText.Visible = true;
        LoadBits();
    
    }


    protected void btnChangeThread_Click(object sender, EventArgs e) {
        int newTypeID = int.Parse(ddlChangePostTypeID.SelectedValue);
        ForumService.ChangeThreadPostType(int.Parse(lblThreadID.Text), newTypeID,SiteUtility.GetUserName());
        //Response.Redirect("~/forums/" + lblThreadUrl.Text);
        LoadBits();
    }




    protected bool UserCanSetAnswer() {
        bool result = false;
        if (thread != null) {
            if (SiteUtility.UserIsAdmin()) {
                result = true;
            } else {
                //if the author can set the reply
                if (thread.UserCanSetAnswer) {
                    //make sure that the current user is the author...
                    result = SubSonic.Utilities.Utility.IsMatch(SiteUtility.GetUserName(), thread.CreatedBy);
                }
            }
        }
        return result;
    }
    protected bool UserCanEditPost(string postAuthor) {
        bool result = false;
        if (thread != null) {
            if (SiteUtility.UserIsAdmin()) {
                result = true;
            } else {
                result = SubSonic.Utilities.Utility.IsMatch(postAuthor.ToLower(), SiteUtility.GetUserName().ToLower());
            }
        }
        return result;

    }
    protected bool UserCanEditTopic() {
        bool result = false;
        if (thread != null) {
            if (SiteUtility.UserIsAdmin()) {
                result = true;
            } else {
                result = SubSonic.Utilities.Utility.IsMatch(thread.CreatedBy, SiteUtility.GetUserName());
            }
        }
        return result;

    }
    protected string GetSignature(object signature) {
        
        //yah, I know - hackish.
        string signatureFormat="<tr><td height=100>{0}<td></tr>";


        string result = "";
        if (signature != null) {
            result = string.Format(signatureFormat, signature);
        }
        return result;
    }
    protected string GetPostDesignation(object postDesignation) {
        string result = "";
        
        if (postDesignation != null) {
            string format = "<tr><td><div class='answeredbox'>{0}</div></td></tr>";
            result = string.Format(format, postDesignation.ToString());
        }
        return result;
    }

    void rptReplies_ItemDataBound(object sender, RepeaterItemEventArgs e) {

        DropDownList dl = (DropDownList)e.Item.FindControl("ddlResponseOptions");
        LinkButton linkEdit = (LinkButton)e.Item.FindControl("lnkEdit");
        LinkButton lnkDelete = (LinkButton)e.Item.FindControl("lnkDelete");
        Literal litAuthor = (Literal)e.Item.FindControl("litPostAuthor");

       
        string postAuthor = litAuthor.Text;
        //linkEdit.Visible = UserCanEditPost(postAuthor);


        //the thread contains the list items we need 
        foreach(ThreadTypeResponse option in thread.ResponseOptions){
            dl.Items.Add(new ListItem(option.Description, option.ThreadTypeResponseID.ToString()));
        }
        dl.Items.Add(new ListItem("Remove", "0"));

        //set the delete button
        lnkDelete.Attributes.Add("onclick", "return CheckDelete();");

    }
    protected bool ShowEditPost(object postAuthor) {
        return UserCanEditPost(postAuthor.ToString());
    }
    void rptReplies_ItemCommand(object source, RepeaterCommandEventArgs e) {

        Literal litPostID = (Literal)e.Item.FindControl("litPostID");
        int postID = int.Parse(litPostID.Text);


        if (e.CommandName == "AnswerSet") {
            DropDownList dl = (DropDownList)e.Item.FindControl("ddlResponseOptions");
            int responseID = int.Parse(dl.SelectedValue);

            if (responseID > 0) {
                SubSonic.Forums.Enums.ThreadResponse responseType = (SubSonic.Forums.Enums.ThreadResponse)responseID;
                ForumService.SetPostAsAnswer(postID, responseType, SiteUtility.GetUserName());
            } else {
                ForumService.RemoveAnswer(postID, SiteUtility.GetUserName());
            }
            LoadBits();
        } else if (e.CommandName == "DeletePost") {
            ForumService.DeletePost(postID);
            LoadBits();
        } else if (e.CommandName == "EditPost") {

            //pull out the control
            Panel pnlDisplay = (Panel)e.Item.FindControl("pnlDisplay");
            Panel pnlEdit = (Panel)e.Item.FindControl("pnlEdit");

            pnlEdit.Visible = true;
            pnlDisplay.Visible = false;
        } else if (e.CommandName == "SaveEdit") {

            //pull out the post
            TextBox txtEdit=(TextBox)e.Item.FindControl("txtEdit");
            ForumService.EditPost(postID, txtEdit.Text, SiteUtility.GetUserName());
            LoadBits();
        }



    }

    bool PostIsAnswer(int postID) {
        bool result=false;
        foreach (ThreadResponse answer in thread.Answers) {
            if (answer.PostID == postID)
                result = true;
        }
        return result;
    }

    static bool isEven = false;
    protected string GetDisplayClass(object postID) {
        string result = "";
        if (PostIsAnswer((int)postID)) {
            result = "answerpost";
        } else {

            // so much nicer than the Alternate template...
            result = isEven ? "normalpost" : "alternatepost";
            isEven = !isEven;
        }
        return result;

    }
    protected void lstWatch_SelectedIndexChanged(object sender, EventArgs e) {
        SubSonic.Forums.Enums.ThreadWatchOptions options = (SubSonic.Forums.Enums.ThreadWatchOptions)SubSonic.Utilities.Utility.StringToEnum(typeof(SubSonic.Forums.Enums.ThreadWatchOptions), lstWatch.SelectedValue);
        ForumService.SetThreadWatch(options, SiteUtility.GetUserName(), int.Parse(lblThreadID.Text));
        LoadBits();

    }
}
