using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using SubSonic.Forums;

public partial class Forums_RSS_Thread : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.ContentType = "text/xml";

        //query string here
        Thread th = new Thread(Thread.Columns.ThreadID, SubSonic.Sugar.Web.QueryString<int>("th"));
        ForumSettings fs = SubSonic.Forums.ForumSettings.LoadSettings();

        //HttpContext.Current

        XmlTextWriter xwriter = new XmlTextWriter(Response.OutputStream, Encoding.UTF8);
        xwriter.WriteStartDocument();
        xwriter.WriteStartElement("rss"); //start rss
        xwriter.WriteAttributeString("version", "2.0");

        xwriter.WriteStartElement("channel"); //start rss --> channel
        xwriter.WriteElementString("title", fs.ForumName + " - " + th.Forum.ForumName + "-" + th.ThreadStarter.Subject);
        xwriter.WriteElementString("link", th.ThreadUrl);
        xwriter.WriteElementString("description", "");
        xwriter.WriteElementString("copyright", "Copyright " + fs.ForumName + " " + DateTime.Now.Year + ". All Rights Reserved.");
        xwriter.WriteElementString("ttl", "50");
        PostCollection collection = th.PostRecords();
        foreach (Post p in collection)
        {
            xwriter.WriteStartElement("item");
            xwriter.WriteElementString("title", p.Subject);
            xwriter.WriteElementString("description", p.PostText);
            xwriter.WriteElementString("pubDate", p.CreatedOn.ToString("R"));
            xwriter.WriteElementString("link", th.ThreadUrl + "#" + p.PostID);
            xwriter.WriteElementString("author", p.CreatedBy);
            xwriter.WriteEndElement();
        }

        xwriter.WriteEndElement(); //end channel
        xwriter.WriteEndElement(); //end rss
        xwriter.WriteEndDocument();
        xwriter.Flush();
        xwriter.Close();
        Response.End();
    }
}
