using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using SubSonic.Forums;

public partial class Forums_RSS_Forum : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.ContentType = "text/xml";

        //query string here
        Forum f = new Forum(Forum.Columns.ForumID, SubSonic.Sugar.Web.QueryString<int>("f"));
        ForumSettings fs = SubSonic.Forums.ForumSettings.LoadSettings();

        XmlTextWriter xwriter = new XmlTextWriter(Response.OutputStream, Encoding.UTF8);
        xwriter.WriteStartDocument();
        xwriter.WriteStartElement("rss"); //start rss
        xwriter.WriteAttributeString("version", "2.0");

        xwriter.WriteStartElement("channel"); //start rss --> channel
        xwriter.WriteElementString("title", fs.ForumName + " - "+f.ForumName);
        xwriter.WriteElementString("link", fs.ForumRootUrl);
        xwriter.WriteElementString("description", f.Description);
        xwriter.WriteElementString("copyright", "Copyright " + fs.ForumName + " " + DateTime.Now.Year + ". All Rights Reserved.");
        xwriter.WriteElementString("ttl", "50");
        foreach (Thread th in f.Threads)
        {
            xwriter.WriteStartElement("item");
            xwriter.WriteElementString("title", th.ThreadStarter.Subject + " (" + th.Resolution + ")");
            xwriter.WriteElementString("description", th.ThreadStarter.PostText);
            xwriter.WriteElementString("pubDate", th.ThreadStarter.CreatedOn.ToString("R"));
            xwriter.WriteElementString("link", th.ThreadUrl);
            xwriter.WriteElementString("author", th.CreatedBy);
            xwriter.WriteEndElement();
        }

        xwriter.WriteEndElement(); //end channel
        xwriter.WriteEndElement(); //end rss
        xwriter.WriteEndDocument();
        xwriter.Flush();
        xwriter.Close();
        Response.End();
    }
}
