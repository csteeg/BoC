using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;

public partial class Forums_ForumProfile : System.Web.UI.Page {

    protected bool CanChangeProfile() {
        bool result = false;
        if (SiteUtility.UserIsAdmin() || SubSonic.Utilities.Utility.IsMatch(SiteUtility.GetUserName(), userName)) {
            result = true;
        }
        return result;

    }
    string userName = "";
    void SetUserName() {
        userName = SiteUtility.GetUserName();
        string otherUser=SubSonic.Sugar.Web.QueryString<string>("u");

        if (!String.IsNullOrEmpty(otherUser)){
            userName = otherUser;
        }

    }
    protected void Page_Load(object sender, EventArgs e) {
        if (!Page.IsPostBack) {

            SetUserName();
            litUser.Text = "Profile: "+userName;
            
            pnlPersonal.Visible = CanChangeProfile();
            pnlAdmin.Visible = SiteUtility.UserIsAdmin();

            LoadInfo();
            string returnUrl = SubSonic.Sugar.Web.QueryString<string>("ReturnUrl");
            if (!String.IsNullOrEmpty(returnUrl)) {
                lnkReturn.NavigateUrl = returnUrl;
                
                //they were sent here cause we needed some info
                
            } else {
                lnkReturn.Visible = false;
                litMessage.Visible = false;
            }
        }
    }

    void LoadInfo() {
        UserProfile p = new UserProfile(userName);
        litGravvy.Text = SubSonic.Forums.Gravatar.GetGravatarImage(p.Email, "");
        txtEmail.Text = p.Email;
        txtSignature.Text = p.Signature;
        litTotalPosts.Text = p.TotalPosts.ToString();
        litAnswers.Text = p.Props.ToString();
        litMemberSince.Text = p.MemberSince.ToShortDateString();
        txtBigNose.Text = p.HelpfulKeywords;
        txtRoles.Text = p.UserRoles;
        chkIsActive.Checked = p.IsApproved;

        ThreadList1.LoadThreadsByAuthor(userName, 1);

    }

    void SaveProfile() {

        //synch the app info
        Profile.Email = txtEmail.Text;
        UserProfile p = new UserProfile("username", SiteUtility.GetUserName());
        p.Email = txtEmail.Text;
        p.Signature = txtSignature.Text;
        p.HelpfulKeywords = txtBigNose.Text;
        p.Save(SiteUtility.GetUserName());

        if (!String.IsNullOrEmpty(p.Signature)) {
            p.Signature = ForumService.CleanPostText(p.Signature);
        }

        //this is optional - comment out if you want the user to be able to specify a different forum email
        //address
        MembershipUser u=Membership.GetUser(p.UserName);
        u.Email = p.Email;
        Membership.UpdateUser(u);

        ResultMessage1.ShowSuccess("Profile Saved");

    }
    protected void btnSave_Click(object sender, EventArgs e) {
        SaveProfile();
    }

    protected void btnSetPassword_Click(object sender, EventArgs e) {

        //change the user's password
        SetUserName();

        MembershipUser user = Membership.GetUser(userName);
        bool success=user.ChangePassword(txtOldPassword.Text, txtNewPassword.Text);

        if (success)
            ResultMessage2.ShowSuccess("password changed");
        else
            ResultMessage2.ShowFail("error saving password");

    }

    protected void btnRoleSet_Click(object sender, EventArgs e) {
         SetUserName();
         UserProfile prof = new UserProfile(userName);
         prof.UserRoles = txtRoles.Text;
         prof.Save(SiteUtility.GetUserName());

         ResultMessage2.ShowSuccess("Roles Changed");

    }
}
