using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;
using SubSonic;

public partial class Forums_Forum : System.Web.UI.Page {

    protected ThreadCollection threads;
    protected Forum forum;
    protected string ForumTitle = "Bad Request";
    protected string pageLinks = "";
    const int pageSize = 50;
    int pageNum = 1;

    protected void Page_Load(object sender, EventArgs e) {
    
        string pageUrl = SubSonic.Utilities.Utility.GetParameter("p");
        //hack to support UrlRewrites
        if (pageUrl.Contains("?pg=")) {
            string sPageNum = SubSonic.Sugar.Strings.Clip(pageUrl, "=").Replace("=","");
            
            pageNum = int.Parse(sPageNum);
            //strip off the pg querystring stuff
            pageUrl = SubSonic.Sugar.Strings.Chop(pageUrl, "?");
        }
        

        if (!Page.IsPostBack) {

            //forum info
            forum = new Forum("forumUrl", pageUrl);
            litDescription.Text = forum.Description;
            litForumId.Text = forum.ForumID.ToString();
            this.Title = "Forums: " + forum.ForumName;
            ForumTitle = forum.ForumName;

            LoadThreads(pageNum);
        }
    }
    void LoadThreads(int pageNumber) {
        ThreadList1.LoadThreadsByForum(forum.ForumID, pageNumber, forum.ForumUrl);

    }
    protected string GetNewPostLink() {
        string result = "";
        result = Page.ResolveUrl("~/forums/NewPost.aspx?f=" + litForumId.Text);
        return result;
    }
}
