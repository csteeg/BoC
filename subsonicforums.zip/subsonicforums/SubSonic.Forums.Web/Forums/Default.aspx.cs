using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using SubSonic.Forums;

public partial class Forums_Default : System.Web.UI.Page {
    int pageNumber = 1;

    protected void Page_Load(object sender, EventArgs e) {
        if (!Page.IsPostBack) {
            
            LoadGroups();
            int forumID = 0;
            
            pageNumber = SubSonic.Sugar.Web.QueryString<int>("pg");
            forumID = SubSonic.Sugar.Web.QueryString<int>("f");

            if (pageNumber == 0)
                pageNumber = 1;

            if (forumID > 0) {
                radForumGroups.SelectedValue = forumID.ToString();
                LoadByForum(forumID);
            } else {

                //this is first entry, so see if we should load from the Profile
                if (User.Identity.IsAuthenticated) {
                    if (!String.IsNullOrEmpty(Profile.ForumThreadView)) {
                        string threadView = Profile.ForumThreadView;
                        if (threadView.StartsWith("forumid:")) {
                            //scrape off the id
                            string[] bits = threadView.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                            forumID = int.Parse(bits[1]);
                            radForumGroups.SelectedValue = forumID.ToString();
                            LoadByForum(forumID);

                        } else {
                            LoadPersonalized(threadView);
                            radOptions.SelectedValue = threadView;
                        }
                    } else {
                        LoadInitial();
                    }
                } else {
                    LoadInitial();
                }
            }

        }
        pnlPersonalized.Visible = User.Identity.IsAuthenticated;

        

    }
    void LoadInitial() {
        if (radForumGroups.Items.Count > 0) {
            radForumGroups.SelectedIndex = 0;
            LoadByForum(int.Parse(radForumGroups.SelectedValue));

        }
    }
    void LoadGroups() {
        ForumCollection coll = new ForumCollection().Load();
        radForumGroups.Items.Clear();

        foreach (Forum f in coll) {
            radForumGroups.Items.Add(new ListItem(f.ForumName, f.ForumID.ToString()));
        }
    }

    void LoadByForum(int forumID) {
        ThreadCollection coll = ForumService.GetForumThreadList(forumID, pageNumber, SiteUtility.GetUserName());
        rptThreads.DataSource = coll;
        rptThreads.DataBind();
        LoadPageCount(forumID);

        litTitle.Text = radForumGroups.SelectedItem.Text + " >> Page " + pageNumber;
        if(User.Identity.IsAuthenticated){
            Profile.ForumThreadView = "forumid:" + forumID.ToString();
        }
        lnkNewPost.NavigateUrl = "~/forums/newpost.aspx?f="+forumID.ToString();
        rsslink.NavigateUrl = "~/forums/rss/forum/"+forumID.ToString()+".aspx";
    }
    void LoadUnread() {
        DataSet ds = SPs.UserUnreadThreads(SiteUtility.GetUserName()).GetDataSet();
        rptThreads.DataSource = ds.Tables[0];
        rptThreads.DataBind();

        //the count is the second table
        int records = (int)ds.Tables[1].Rows[0][0];

        if (records > 20) {
            litPageCount.Text = " (20 of " + records.ToString() + ")";
            litPageCount2.Text = "";
        } else {
            litPageCount.Text = "";
            litPageCount2.Text = "";
        }
        litTitle.Text = "Threads You Haven't Read";


    }
    void LoadNewest() {
        rptThreads.DataSource = SPs.NewestThreads(SiteUtility.GetUserName()).GetReader();
        rptThreads.DataBind();
        litPageCount.Text = "";
        litPageCount2.Text = "";
        litTitle.Text = "Newest Threads";

    }
    void LoadWatched() {
        rptThreads.DataSource = SPs.UserWatchedThreads(SiteUtility.GetUserName()).GetReader();
        rptThreads.DataBind();
        litPageCount.Text = "";
        litPageCount2.Text = "";
        litTitle.Text = "Your Watched Threads";

    }
    void LoadMyPosts() {
        rptThreads.DataSource = SPs.UserThreads(SiteUtility.GetUserName()).GetReader();
        rptThreads.DataBind();
        litPageCount.Text = "";
        litPageCount2.Text = "";
        litTitle.Text = "Threads You Have Posted On";

    }
    void LoadPersonalized(string selection) {
        switch (selection) {
            case "unread":
                LoadUnread();
                break;
            case "newest":
                LoadNewest();
                break;
            case "watched":
                LoadWatched();
                break;
            case "myposts":
                LoadMyPosts();
                break;
        }
        Profile.ForumThreadView = selection;
    }
    protected void radOptions_SelectedIndexChanged(object sender, EventArgs e) {
        radForumGroups.ClearSelection();
        string selection = radOptions.SelectedValue;

        LoadPersonalized(selection);
        lnkNewPost.Visible = false;

    }
    protected void radForumGroups_SelectedIndexChanged(object sender, EventArgs e) {
        Response.Redirect("default.aspx?f=" + radForumGroups.SelectedValue);
        lnkNewPost.Visible = true;
    }

    void LoadPageCount(int forumID) {

        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        string pageLinks = "";
        
        int threadCount = new SubSonic.Query(Tables.Thread).WHERE(Thread.Columns.Deleted, false).AND(Thread.Columns.ForumID, forumID).GetCount(Thread.Columns.ThreadID);
        int pageCount = 0;
        int pageSize = 50;
        string pagerFormat = "<a href='default.aspx?f="+forumID.ToString()+"&pg={0}'>{0}</a> | ";

        if (threadCount > pageSize) {
            pageCount = threadCount / pageSize;
            //0 offset plus the leftovers
            pageCount += 2;
            for (int i = 1; i < pageCount; i++) {
                if (i == pageNumber) {
                    sb.Append("<b>" + i.ToString() + "</b> | ");
                } else {
                    sb.AppendFormat(pagerFormat, i.ToString());

                }
            }

            pageLinks = sb.ToString();
            pageLinks = SubSonic.Sugar.Strings.Chop(pageLinks, 3);
        }

        litPageCount.Text = pageLinks;
        litPageCount2.Text = pageLinks;

    }


}
