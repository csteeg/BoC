using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class LoginModal : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

    }
    protected void btnRegister_Click(object sender, EventArgs e) {
        //register them
        MembershipCreateStatus status;
        Membership.CreateUser(txtUserName.Text, txtPassword.Text, txtEmail.Text, txtQ.Text, txtA.Text, true, out status);

        //add the profile
        if (status == MembershipCreateStatus.Success) {


            //add them to the UserProfile table
            SubSonic.Forums.ForumService.CreateUserProfile(txtUserName.Text, txtEmail.Text);
            btnRegister.Enabled = false;
            
            //set the cookie
            FormsAuthentication.SetAuthCookie(txtUserName.Text, true);
            Profile.Email = txtEmail.Text;

            //close the window
            CloseMe();

        } else {
            if (status == MembershipCreateStatus.DuplicateEmail) {
                ResultMessage1.ShowFail("This email is already in our system");

            }
            if (status == MembershipCreateStatus.DuplicateUserName) {
                ResultMessage2.ShowFail("Need to use another login - this one's taken");

            }
            if (status == MembershipCreateStatus.InvalidEmail) {
                ResultMessage1.ShowFail("Invalid email address");

            }
            if (status == MembershipCreateStatus.InvalidPassword) {
                ResultMessage1.ShowFail("Invalid password. Needs to be 6 or more letters/numbers");

            }
            if (status == MembershipCreateStatus.UserRejected) {
                ResultMessage1.ShowFail("You cannot register at this time");

            }
        }
    }
    void CloseMe() {
        Response.Write("<script type=\"text/javascript\">parent.location = parent.location;</script>");
        Response.Flush();
        Response.End();

    }

    protected void btnLogin_Click(object sender, EventArgs e) {
        string userName=txtLogUserName.Text;
        string password=txtLogPassword.Text;

        //validate the user
        if (Membership.ValidateUser(userName, txtLogPassword.Text)) {
            FormsAuthentication.SetAuthCookie(userName, true);

            if (chkLoginRemeber.Checked) {
                Response.Cookies["SSFORUM"].Value = userName;
                Response.Cookies["SSFORUM"].Expires = DateTime.Now.AddDays(365);
                //close the window
            }

            //if they don't have an email, set it now
            if (String.IsNullOrEmpty(Profile.Email)) {
                SubSonic.Forums.UserProfile prof = new SubSonic.Forums.UserProfile(userName);
                Profile.Email = prof.Email;
            }


            CloseMe();
        }else{
            ResultMessage4.ShowFail("No luck...");
        }
    }
    protected void lnkForgot_Click(object sender, EventArgs e) {
        Response.Write("<script>parent.location.href='"+Page.ResolveUrl("~/PasswordRecover.aspx")+"';</script>");
        Response.Flush();
        Response.End();

    }
}
