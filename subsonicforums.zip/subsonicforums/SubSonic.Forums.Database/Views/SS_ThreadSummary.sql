IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'SS_ThreadSummary')
	BEGIN
		DROP  View SS_ThreadSummary
	END
GO

CREATE View SS_ThreadSummary AS

SELECT     SS_Post_1.Subject AS ThreadSubject, SS_Post_1.FormattedPostText AS Question, dbo.SS_Post.FormattedPostText AS Reply, 
                      dbo.SS_Thread.ThreadUrl, dbo.SS_Post.PostID, SS_Post_1.CreatedBy AS ThreadAuthor, dbo.SS_Post.CreatedBy AS ReplyAuthor
FROM         dbo.SS_Thread INNER JOIN
                      dbo.SS_Post ON dbo.SS_Thread.ThreadID = dbo.SS_Post.ThreadID INNER JOIN
                      dbo.SS_Post AS SS_Post_1 ON dbo.SS_Thread.StartPostID = SS_Post_1.PostID AND dbo.SS_Post.PostID <> SS_Post_1.PostID

GO

--GRANT SELECT ON SS_ThreadSummary TO PUBLIC
--GO
