IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'SS_ThreadPostType')
	BEGIN
		DROP  View SS_ThreadPostType
	END
GO

CREATE View SS_ThreadPostType AS

SELECT     dbo.SS_Thread.ThreadID, dbo.SS_PostType.Description AS PostType, dbo.SS_Thread.Subject, dbo.SS_Thread.ThreadUrl
FROM         dbo.SS_PostType INNER JOIN
                      dbo.SS_Post ON dbo.SS_PostType.PostTypeID = dbo.SS_Post.PostTypeID INNER JOIN
                      dbo.SS_Thread ON dbo.SS_Post.PostID = dbo.SS_Thread.StartPostID

GO

--GRANT SELECT ON SS_ThreadPostType TO PUBLIC
--GO
