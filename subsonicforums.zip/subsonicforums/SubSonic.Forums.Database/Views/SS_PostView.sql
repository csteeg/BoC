IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'SS_PostView')
	BEGIN
		DROP  View SS_PostView
	END
GO

CREATE View SS_PostView AS

SELECT     dbo.SS_Post.ThreadID, dbo.SS_Post.Subject, dbo.SS_PostType.Description AS PostType, dbo.SS_PostType.PostTypeID, dbo.SS_Post.PostGUID, 
                      dbo.SS_Post.FormattedPostText, dbo.SS_Post.CreatedOn, dbo.SS_Post.CreatedBy, dbo.SS_Post.PostID, dbo.SS_Post.Deleted, 
                      dbo.SS_UserProfile.Signature, dbo.SS_ThreadTypeResponse.PostDesignation, dbo.SS_ThreadTypeResponse.Description AS Response, 
                      dbo.SS_UserProfile.Email AS AuthorEmail, dbo.SS_UserProfile.Props, dbo.SS_Post.PostText, dbo.SS_UserProfile.UserRoles
FROM         dbo.SS_ThreadTypeResponse INNER JOIN
                      dbo.SS_User_Answer ON dbo.SS_ThreadTypeResponse.ThreadTypeResponseID = dbo.SS_User_Answer.ThreadTypeResponseID RIGHT OUTER JOIN
                      dbo.SS_Post INNER JOIN
                      dbo.SS_PostType ON dbo.SS_Post.PostTypeID = dbo.SS_PostType.PostTypeID INNER JOIN
                      dbo.SS_UserProfile ON dbo.SS_Post.CreatedBy = dbo.SS_UserProfile.UserName ON dbo.SS_User_Answer.PostID = dbo.SS_Post.PostID

GO

--GRANT SELECT ON SS_PostView TO PUBLIC
--GO
