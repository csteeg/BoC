IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'SS_ThreadWatchList')
	BEGIN
		DROP  View SS_ThreadWatchList
	END
GO

CREATE View SS_ThreadWatchList AS

SELECT     dbo.SS_UserProfile.Email, dbo.SS_User_WatchedThread.UserName, dbo.SS_User_WatchedThread.ThreadID, 
                      dbo.SS_User_WatchedThread.ThreadUrl, dbo.SS_UserProfile.AllowEmailContact, dbo.SS_UserProfile.HTMLEmail, 
                      dbo.SS_User_WatchedThread.AnswerOnly, dbo.SS_User_WatchedThread.EmailNotify
FROM         dbo.SS_UserProfile INNER JOIN
                      dbo.SS_User_WatchedThread ON dbo.SS_UserProfile.UserName = dbo.SS_User_WatchedThread.UserName

GO

--GRANT SELECT ON SS_ThreadWatchList TO PUBLIC
--GO
