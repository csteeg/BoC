IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'SS_ThreadView')
	BEGIN
		DROP  View SS_ThreadView
	END
GO

CREATE View SS_ThreadView AS

SELECT     dbo.SS_Thread.ThreadID, dbo.SS_Thread.ThreadTypeID, dbo.SS_Thread.Subject, dbo.SS_Thread.ForumID, dbo.SS_Thread.Resolution, 
                      dbo.SS_Thread.StartPostID, dbo.SS_Thread.ThreadUrl, dbo.SS_Thread.Views, dbo.SS_Thread.TotalReplies, dbo.SS_Thread.LastViewDate, 
                      dbo.SS_Thread.LastReplyAuthor, dbo.SS_Thread.LastReplyDate, dbo.SS_Thread.CreatedBy, dbo.SS_Thread.CreatedOn, dbo.SS_Thread.ModifiedBy, 
                      dbo.SS_Thread.ModifiedOn, dbo.SS_Thread.Deleted, dbo.SS_Thread.IsLocked, dbo.SS_Thread.IsStickied, dbo.SS_ThreadType.Description, 
                      dbo.SS_ThreadType.ListOrder, dbo.SS_ThreadType.Icon
FROM         dbo.SS_Thread INNER JOIN
                      dbo.SS_ThreadType ON dbo.SS_Thread.ThreadTypeID = dbo.SS_ThreadType.ThreadTypeID
                      
GO

--GRANT SELECT ON SS_ThreadView TO PUBLIC
--GO
