IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'SS_ThreadResponses')
	BEGIN
		DROP  View SS_ThreadResponses
	END
GO

CREATE View SS_ThreadResponses AS

SELECT     dbo.SS_Thread.ThreadID, dbo.SS_ThreadTypeResponse.ThreadTypeResponseID, dbo.SS_ThreadTypeResponse.ThreadTypeID, 
                      dbo.SS_ThreadTypeResponse.Description, dbo.SS_ThreadTypeResponse.PostDesignation, dbo.SS_ThreadTypeResponse.IsSearchable, 
                      dbo.SS_ThreadTypeResponse.IsDefault, dbo.SS_Post.CreatedBy AS ResponseAuthor, dbo.SS_Thread.Subject, dbo.SS_Post.PostID
FROM         dbo.SS_Post INNER JOIN
                      dbo.SS_Thread ON dbo.SS_Post.ThreadID = dbo.SS_Thread.ThreadID INNER JOIN
                      dbo.SS_User_Answer ON dbo.SS_Post.PostID = dbo.SS_User_Answer.PostID INNER JOIN
                      dbo.SS_ThreadTypeResponse ON dbo.SS_User_Answer.ThreadTypeResponseID = dbo.SS_ThreadTypeResponse.ThreadTypeResponseID

GO

--GRANT SELECT ON SS_ThreadResponses TO PUBLIC
--GO
