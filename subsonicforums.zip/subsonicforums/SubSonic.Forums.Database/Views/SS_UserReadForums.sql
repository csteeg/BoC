IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'SS_UserReadForums')
	BEGIN
		DROP  View SS_UserReadForums
	END
GO

CREATE View SS_UserReadForums AS

SELECT     dbo.SS_User_ReadThread.ReadID, dbo.SS_User_ReadThread.UserName, dbo.SS_User_ReadThread.ThreadID, dbo.SS_Thread.ForumID, 
                      dbo.SS_User_ReadThread.ReadDate
FROM         dbo.SS_Thread INNER JOIN
                      dbo.SS_User_ReadThread ON dbo.SS_Thread.ThreadID = dbo.SS_User_ReadThread.ThreadID

GO

--GRANT SELECT ON SS_UserReadForums TO PUBLIC
--GO
