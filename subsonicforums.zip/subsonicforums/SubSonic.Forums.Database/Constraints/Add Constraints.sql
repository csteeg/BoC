
-- FK_SS_Post_SS_PostType
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Post_SS_PostType')
	BEGIN
		ALTER TABLE [dbo].[SS_Post]
			DROP CONSTRAINT FK_SS_Post_SS_PostType
	END
GO
ALTER TABLE [dbo].[SS_Post]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_Post_SS_PostType] FOREIGN KEY([PostTypeID])
REFERENCES [SS_PostType] ([PostTypeID])
ALTER TABLE [dbo].[SS_Post] CHECK CONSTRAINT [FK_SS_Post_SS_PostType]

-- FK_SS_Post_SS_Thread
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Post_SS_Thread')
	BEGIN
		ALTER TABLE [dbo].[SS_Post]
			DROP CONSTRAINT FK_SS_Post_SS_Thread
	END
GO
ALTER TABLE [dbo].[SS_Post]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_Post_SS_Thread] FOREIGN KEY([ThreadID])
REFERENCES [SS_Thread] ([ThreadID])
ALTER TABLE [dbo].[SS_Post] CHECK CONSTRAINT [FK_SS_Post_SS_Thread]

-- FK_SS_Post_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Post_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_Post]
			DROP CONSTRAINT FK_SS_Post_SS_UserProfile
	END
GO
ALTER TABLE [dbo].[SS_Post]  WITH CHECK ADD  CONSTRAINT [FK_SS_Post_SS_UserProfile] FOREIGN KEY([CreatedBy])
REFERENCES [SS_UserProfile] ([UserName])
ALTER TABLE [dbo].[SS_Post] CHECK CONSTRAINT [FK_SS_Post_SS_UserProfile]

-- FK_SS_User_WatchedThread_SS_Thread
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_WatchedThread_SS_Thread')
	BEGIN
		ALTER TABLE [dbo].[SS_User_WatchedThread]
			DROP CONSTRAINT FK_SS_User_WatchedThread_SS_Thread
	END
GO
ALTER TABLE [dbo].[SS_User_WatchedThread]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_WatchedThread_SS_Thread] FOREIGN KEY([ThreadID])
REFERENCES [SS_Thread] ([ThreadID])
ALTER TABLE [dbo].[SS_User_WatchedThread] CHECK CONSTRAINT [FK_SS_User_WatchedThread_SS_Thread]

-- FK_SS_User_WatchedThread_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_WatchedThread_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_User_WatchedThread]
			DROP CONSTRAINT FK_SS_User_WatchedThread_SS_UserProfile
	END
GO
ALTER TABLE [dbo].[SS_User_WatchedThread]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_WatchedThread_SS_UserProfile] FOREIGN KEY([UserName])
REFERENCES [SS_UserProfile] ([UserName])
ALTER TABLE [dbo].[SS_User_WatchedThread] CHECK CONSTRAINT [FK_SS_User_WatchedThread_SS_UserProfile]

-- FK_SS_Thread_SS_Forum
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Thread_SS_Forum')
	BEGIN
		ALTER TABLE [dbo].[SS_Thread]
			DROP CONSTRAINT FK_SS_Thread_SS_Forum
	END
GO
ALTER TABLE [dbo].[SS_Thread]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_Thread_SS_Forum] FOREIGN KEY([ForumID])
REFERENCES [SS_Forum] ([ForumID])
ALTER TABLE [dbo].[SS_Thread] CHECK CONSTRAINT [FK_SS_Thread_SS_Forum]

-- FK_SS_Thread_SS_ThreadType
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Thread_SS_ThreadType')
	BEGIN
		ALTER TABLE [dbo].[SS_Thread]
			DROP CONSTRAINT FK_SS_Thread_SS_ThreadType
	END
GO
ALTER TABLE [dbo].[SS_Thread]  WITH CHECK ADD  CONSTRAINT [FK_SS_Thread_SS_ThreadType] FOREIGN KEY([ThreadTypeID])
REFERENCES [SS_ThreadType] ([ThreadTypeID])
ALTER TABLE [dbo].[SS_Thread] CHECK CONSTRAINT [FK_SS_Thread_SS_ThreadType]

-- FK_SS_ThreadResponse_Map_SS_Post
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_ThreadResponse_Map_SS_Post')
	BEGIN
		ALTER TABLE [dbo].[SS_User_Answer]
			DROP CONSTRAINT FK_SS_ThreadResponse_Map_SS_Post
	END
GO
ALTER TABLE [dbo].[SS_User_Answer]  WITH CHECK ADD  CONSTRAINT [FK_SS_ThreadResponse_Map_SS_Post] FOREIGN KEY([PostID])
REFERENCES [SS_Post] ([PostID])
ALTER TABLE [dbo].[SS_User_Answer] CHECK CONSTRAINT [FK_SS_ThreadResponse_Map_SS_Post]

-- FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse')
	BEGIN
		ALTER TABLE [dbo].[SS_User_Answer]
			DROP CONSTRAINT FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse
	END
GO
ALTER TABLE [dbo].[SS_User_Answer]  WITH CHECK ADD  CONSTRAINT [FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse] FOREIGN KEY([ThreadTypeResponseID])
REFERENCES [SS_ThreadTypeResponse] ([ThreadTypeResponseID])
ALTER TABLE [dbo].[SS_User_Answer] CHECK CONSTRAINT [FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse]

-- FK_SS_User_Answer_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_Answer_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_User_Answer]
			DROP CONSTRAINT FK_SS_User_Answer_SS_UserProfile
	END
GO
ALTER TABLE [dbo].[SS_User_Answer]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_Answer_SS_UserProfile] FOREIGN KEY([CreatedBy])
REFERENCES [SS_UserProfile] ([UserName])
ALTER TABLE [dbo].[SS_User_Answer] CHECK CONSTRAINT [FK_SS_User_Answer_SS_UserProfile]

-- FK_SS_ThreaadTypeResponse_SS_ThreadType
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_ThreaadTypeResponse_SS_ThreadType')
	BEGIN
		ALTER TABLE [dbo].[SS_ThreadTypeResponse]
			DROP CONSTRAINT FK_SS_ThreaadTypeResponse_SS_ThreadType
	END
GO
ALTER TABLE [dbo].[SS_ThreadTypeResponse]  WITH CHECK ADD  CONSTRAINT [FK_SS_ThreaadTypeResponse_SS_ThreadType] FOREIGN KEY([ThreadTypeID])
REFERENCES [SS_ThreadType] ([ThreadTypeID])
ALTER TABLE [dbo].[SS_ThreadTypeResponse] CHECK CONSTRAINT [FK_SS_ThreaadTypeResponse_SS_ThreadType]

-- FK_SS_User_ForumRole_SS_ForumRole
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_ForumRole_SS_ForumRole')
	BEGIN
		ALTER TABLE [dbo].[SS_User_ForumRole]
			DROP CONSTRAINT FK_SS_User_ForumRole_SS_ForumRole
	END
GO
ALTER TABLE [dbo].[SS_User_ForumRole]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_ForumRole_SS_ForumRole] FOREIGN KEY([roleID])
REFERENCES [SS_ForumRole] ([RoleID])
ALTER TABLE [dbo].[SS_User_ForumRole] CHECK CONSTRAINT [FK_SS_User_ForumRole_SS_ForumRole]

-- FK_SS_User_ForumRole_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_ForumRole_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_User_ForumRole]
			DROP CONSTRAINT FK_SS_User_ForumRole_SS_UserProfile
	END
GO
ALTER TABLE [dbo].[SS_User_ForumRole]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_ForumRole_SS_UserProfile] FOREIGN KEY([userName])
REFERENCES [SS_UserProfile] ([UserName])
ALTER TABLE [dbo].[SS_User_ForumRole] CHECK CONSTRAINT [FK_SS_User_ForumRole_SS_UserProfile]

-- FK_SS_UserSearchSubscription_SS_UserProfile1
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_UserSearchSubscription_SS_UserProfile1')
	BEGIN
		ALTER TABLE [dbo].[SS_UserSearchSubscription]
			DROP CONSTRAINT FK_SS_UserSearchSubscription_SS_UserProfile1
	END
GO
ALTER TABLE [dbo].[SS_UserSearchSubscription]  WITH CHECK ADD  CONSTRAINT [FK_SS_UserSearchSubscription_SS_UserProfile1] FOREIGN KEY([CreatedBy])
REFERENCES [SS_UserProfile] ([UserName])
ALTER TABLE [dbo].[SS_UserSearchSubscription] CHECK CONSTRAINT [FK_SS_UserSearchSubscription_SS_UserProfile1]

-- FK_SS_User_ReadThreads_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_ReadThreads_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_User_ReadThread]
			DROP CONSTRAINT FK_SS_User_ReadThreads_SS_UserProfile
	END
GO
ALTER TABLE [dbo].[SS_User_ReadThread]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_ReadThreads_SS_UserProfile] FOREIGN KEY([UserName])
REFERENCES [SS_UserProfile] ([UserName])
ALTER TABLE [dbo].[SS_User_ReadThread] CHECK CONSTRAINT [FK_SS_User_ReadThreads_SS_UserProfile]

-- FK_SS_Forum_SS_Forum_Group
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Forum_SS_Forum_Group')
	BEGIN
		ALTER TABLE [dbo].[SS_Forum]
			DROP CONSTRAINT FK_SS_Forum_SS_Forum_Group
	END
GO
ALTER TABLE [dbo].[SS_Forum]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_Forum_SS_Forum_Group] FOREIGN KEY([GroupID])
REFERENCES [SS_Forum_Group] ([GroupID])
ALTER TABLE [dbo].[SS_Forum] CHECK CONSTRAINT [FK_SS_Forum_SS_Forum_Group]
