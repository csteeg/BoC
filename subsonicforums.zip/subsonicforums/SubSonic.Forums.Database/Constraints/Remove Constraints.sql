
-- FK_SS_Post_SS_PostType
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Post_SS_PostType')
	BEGIN
		ALTER TABLE [dbo].[SS_Post]
			DROP CONSTRAINT FK_SS_Post_SS_PostType
	END
GO

-- FK_SS_Post_SS_Thread
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Post_SS_Thread')
	BEGIN
		ALTER TABLE [dbo].[SS_Post]
			DROP CONSTRAINT FK_SS_Post_SS_Thread
	END
GO

-- FK_SS_Post_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Post_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_Post]
			DROP CONSTRAINT FK_SS_Post_SS_UserProfile
	END
GO

-- FK_SS_User_WatchedThread_SS_Thread
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_WatchedThread_SS_Thread')
	BEGIN
		ALTER TABLE [dbo].[SS_User_WatchedThread]
			DROP CONSTRAINT FK_SS_User_WatchedThread_SS_Thread
	END
GO

-- FK_SS_User_WatchedThread_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_WatchedThread_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_User_WatchedThread]
			DROP CONSTRAINT FK_SS_User_WatchedThread_SS_UserProfile
	END
GO

-- FK_SS_Thread_SS_Forum
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Thread_SS_Forum')
	BEGIN
		ALTER TABLE [dbo].[SS_Thread]
			DROP CONSTRAINT FK_SS_Thread_SS_Forum
	END
GO

-- FK_SS_Thread_SS_ThreadType
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Thread_SS_ThreadType')
	BEGIN
		ALTER TABLE [dbo].[SS_Thread]
			DROP CONSTRAINT FK_SS_Thread_SS_ThreadType
	END
GO

-- FK_SS_ThreadResponse_Map_SS_Post
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_ThreadResponse_Map_SS_Post')
	BEGIN
		ALTER TABLE [dbo].[SS_User_Answer]
			DROP CONSTRAINT FK_SS_ThreadResponse_Map_SS_Post
	END
GO

-- FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse')
	BEGIN
		ALTER TABLE [dbo].[SS_User_Answer]
			DROP CONSTRAINT FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse
	END
GO

-- FK_SS_User_Answer_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_Answer_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_User_Answer]
			DROP CONSTRAINT FK_SS_User_Answer_SS_UserProfile
	END
GO

-- FK_SS_ThreaadTypeResponse_SS_ThreadType
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_ThreaadTypeResponse_SS_ThreadType')
	BEGIN
		ALTER TABLE [dbo].[SS_ThreadTypeResponse]
			DROP CONSTRAINT FK_SS_ThreaadTypeResponse_SS_ThreadType
	END
GO

-- FK_SS_User_ForumRole_SS_ForumRole
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_ForumRole_SS_ForumRole')
	BEGIN
		ALTER TABLE [dbo].[SS_User_ForumRole]
			DROP CONSTRAINT FK_SS_User_ForumRole_SS_ForumRole
	END
GO

-- FK_SS_User_ForumRole_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_ForumRole_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_User_ForumRole]
			DROP CONSTRAINT FK_SS_User_ForumRole_SS_UserProfile
	END
GO

-- FK_SS_UserSearchSubscription_SS_UserProfile1
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_UserSearchSubscription_SS_UserProfile1')
	BEGIN
		ALTER TABLE [dbo].[SS_UserSearchSubscription]
			DROP CONSTRAINT FK_SS_UserSearchSubscription_SS_UserProfile1
	END
GO

-- FK_SS_User_ReadThreads_SS_UserProfile
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_User_ReadThreads_SS_UserProfile')
	BEGIN
		ALTER TABLE [dbo].[SS_User_ReadThread]
			DROP CONSTRAINT FK_SS_User_ReadThreads_SS_UserProfile
	END
GO

-- FK_SS_Forum_SS_Forum_Group
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'F' AND name = 'FK_SS_Forum_SS_Forum_Group')
	BEGIN
		ALTER TABLE [dbo].[SS_Forum]
			DROP CONSTRAINT FK_SS_Forum_SS_Forum_Group
	END
GO
