IF EXISTS (SELECT * FROM sysobjects WHERE  type in (N'FN', N'IF', N'TF', N'FS', N'FT') AND name = 'GetLastPoster')
	BEGIN
		DROP  Function  GetLastPoster
	END

GO

CREATE FUNCTION dbo.GetLastPoster
	(
		@threadID int
	)
RETURNS nvarchar(50)
AS
	BEGIN
	
	DECLARE @result nvarchar(50)
	
		SELECT TOP 1 @result=SS_Post.CreatedBy + ' on ' + CONVERT(nvarchar(50),SS_Post.CreatedOn)
		FROM SS_Post
		WHERE threadID=@threadID
		ORDER BY createdOn DESC		
	RETURN @result
	END
GO

--GRANT EXEC ON GetLastPoster TO PUBLIC
--GO
