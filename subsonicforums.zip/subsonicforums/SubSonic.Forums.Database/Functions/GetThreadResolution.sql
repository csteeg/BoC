IF EXISTS (SELECT * FROM sysobjects WHERE  type in (N'FN', N'IF', N'TF', N'FS', N'FT') AND name = 'GetThreadResolution')
	BEGIN
		DROP  Function  GetThreadResolution
	END

GO

CREATE FUNCTION [dbo].[GetThreadResolution] 
	(
		@threadID int
	)
RETURNS nvarchar(50)
AS
	BEGIN
	DECLARE @result nvarchar(50)

	
	SELECT     @result=SS_PostRatingType.Resolution
	FROM         SS_PostRatings INNER JOIN
	                      SS_PostRatingType ON SS_PostRatings.RatingTypeID = SS_PostRatingType.RatingTypeID AND 
	                      SS_PostRatings.RatingTypeID = SS_PostRatingType.RatingTypeID
	WHERE threadID=@threadID AND SS_PostRatingType.RatingTypeID <> 1
	
	IF @result IS NULL
		SELECT @result='Open'
	
	RETURN @result
	END

--GRANT EXEC ON GetThreadResolution TO PUBLIC
--GO
