IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'CMS_Page')
	BEGIN
		DROP  Table CMS_Page
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CMS_Page]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CMS_Page](
		[PageID] [int] IDENTITY(1,1) NOT NULL,
		[Title] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Body] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Locale] [char](5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[ParentID] [int] NULL,
		[PageGuid] [uniqueidentifier] NOT NULL,
		[MenuTitle] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Roles] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Summary] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[PageUrl] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Keywords] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[CreatedOn] [datetime] NOT NULL,
		[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ModifiedOn] [datetime] NOT NULL,
		[ModifiedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Deleted] [bit] NOT NULL,
	 CONSTRAINT [PK_CMS_Page_1] PRIMARY KEY CLUSTERED 
	(
		[PageID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

GRANT SELECT ON CMS_Page TO PUBLIC
GO
