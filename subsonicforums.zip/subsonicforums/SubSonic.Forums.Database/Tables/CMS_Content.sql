IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'CMS_Content')
	BEGIN
		DROP  Table CMS_Content
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CMS_Content]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[CMS_Content](
		[ContentID] [int] IDENTITY(1,1) NOT NULL,
		[ContentGUID] [uniqueidentifier] NOT NULL,
		[Title] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ContentName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Body] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Locale] [nvarchar](7) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[CreatedOn] [datetime] NULL,
		[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ModifiedOn] [datetime] NULL,
		[ModifiedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	 CONSTRAINT [PK_CMS_Content] PRIMARY KEY CLUSTERED 
	(
		[ContentID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO

--GRANT SELECT ON CMS_Content TO PUBLIC
--GO
