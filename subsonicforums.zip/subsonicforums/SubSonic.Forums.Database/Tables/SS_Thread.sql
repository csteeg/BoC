IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_Thread')
	BEGIN
		DROP  Table SS_Thread
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_Thread]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_Thread](
	[ThreadID] [int] IDENTITY(1,1) NOT NULL,
	[ThreadTypeID] [int] NOT NULL CONSTRAINT [DF_SS_Thread_ThreadTypeID]  DEFAULT ((1)),
	[Subject] [nvarchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ForumID] [int] NOT NULL,
	[Resolution] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SS_Thread_Resolution]  DEFAULT (N'Open'),
	[StartPostID] [int] NOT NULL CONSTRAINT [DF_SS_Thread_StartPostID]  DEFAULT ((0)),
	[ThreadUrl] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SS_Thread_ThreadUrl]  DEFAULT (''),
	[Views] [int] NOT NULL CONSTRAINT [DF_SS_Thread_Views]  DEFAULT ((0)),
	[TotalReplies] [int] NOT NULL CONSTRAINT [DF_SS_Thread_Posts]  DEFAULT ((0)),
	[LastViewDate] [datetime] NULL,
	[LastReplyAuthor] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LastReplyDate] [datetime] NULL,
	[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Thread_CreatedOn]  DEFAULT (getdate()),
	[ModifiedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Thread_ModifiedOn]  DEFAULT (getdate()),
	[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_Thread_Deleted]  DEFAULT ((0)),
	[IsLocked] [bit] NOT NULL CONSTRAINT [DF_SS_Thread_IsClosed]  DEFAULT ((0)),
	[IsStickied] [bit] NOT NULL CONSTRAINT [DF_SS_Thread_IsStickied]  DEFAULT ((0)),
	CONSTRAINT [PK_SS_Thread] PRIMARY KEY CLUSTERED 
	(
	[ThreadID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_Thread TO PUBLIC
--GO
