IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_ThreadTypeResponse')
	BEGIN
		DROP  Table SS_ThreadTypeResponse
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_ThreadTypeResponse]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_ThreadTypeResponse](
		[ThreadTypeResponseID] [int] IDENTITY(1,1) NOT NULL,
		[ThreadTypeID] [int] NULL,
		[Description] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[PostDesignation] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[IsSearchable] [bit] NOT NULL CONSTRAINT [DF_SS_ThreadTypeResponse_IsSearchable]  DEFAULT ((0)),
		[IsDefault] [bit] NOT NULL CONSTRAINT [DF_SS_ThreadTypeResponse_IsDefault]  DEFAULT ((0)),
		[AnswererPropsValue] [int] NOT NULL CONSTRAINT [DF_SS_ThreadTypeResponse_PropsForUser]  DEFAULT ((1)),
		[ThreadAuthorPropsValue] [int] NOT NULL CONSTRAINT [DF_SS_ThreadTypeResponse_ThreadAuthorPropsValue]  DEFAULT ((0)),
	 CONSTRAINT [PK_SS_ThreaadTypeResponse] PRIMARY KEY CLUSTERED 
	(
		[ThreadTypeResponseID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_ThreadTypeResponse TO PUBLIC
--GO
