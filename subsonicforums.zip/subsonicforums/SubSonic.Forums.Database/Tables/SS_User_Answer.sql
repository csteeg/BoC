IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_User_Answer')
	BEGIN
		DROP  Table SS_User_Answer
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_User_Answer]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_User_Answer](
		[AnswerID] [int] IDENTITY(1,1) NOT NULL,
		[PostID] [int] NOT NULL,
		[ThreadTypeResponseID] [int] NOT NULL,
		[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_ThreadResponse_Map_CreatedOn]  DEFAULT (getdate()),
		[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Props] [int] NOT NULL CONSTRAINT [DF_SS_User_Answer_Props]  DEFAULT ((0)),
	 CONSTRAINT [PK_SS_ThreadResponse_Map] PRIMARY KEY CLUSTERED 
	(
		[AnswerID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_User_Answer TO PUBLIC
--GO
