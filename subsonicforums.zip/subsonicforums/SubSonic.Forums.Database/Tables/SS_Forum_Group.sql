IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_Forum_Group')
	BEGIN
		DROP  Table SS_Forum_Group
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_Forum_Group]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_Forum_Group](
		[GroupID] [int] IDENTITY(1,1) NOT NULL,
		[GroupName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Description] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Roles] [nvarchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_SS_Forum_Group_Roles]  DEFAULT (N'*'),
		[ListOrder] [int] NOT NULL CONSTRAINT [DF_SS_Forum_Group_ListOrder]  DEFAULT ((1)),
		[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Forum_Group_CreatedOn]  DEFAULT (getdate()),
		[ModifiedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Forum_Group_ModifiedOn]  DEFAULT (getdate()),
		[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_Forum_Group_Deleted]  DEFAULT ((0)),
	 CONSTRAINT [PK_SS_Forum_Group] PRIMARY KEY CLUSTERED 
	(
		[GroupID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_Forum_Group TO PUBLIC
--GO
