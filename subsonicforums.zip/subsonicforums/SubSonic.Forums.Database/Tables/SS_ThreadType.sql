IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_ThreadType')
	BEGIN
		DROP  Table SS_ThreadType
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_ThreadType]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_ThreadType](
		[ThreadTypeID] [int] IDENTITY(1,1) NOT NULL,
		[Description] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ListOrder] [int] NOT NULL CONSTRAINT [DF_SS_ThreadType_ListOrder]  DEFAULT ((0)),
		[Icon] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[CssClass] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[AuthorCanDesignateAnswer] [bit] NOT NULL CONSTRAINT [DF_SS_ThreadType_AuthorCanAnswer]  DEFAULT ((0)),
	 CONSTRAINT [PK_SS_ThreadType] PRIMARY KEY CLUSTERED 
	(
		[ThreadTypeID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_ThreadType TO PUBLIC
--GO
