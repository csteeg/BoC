IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_MailQueue')
	BEGIN
		DROP  Table SS_MailQueue
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_MailQueue]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_MailQueue](
		[MailerID] [int] IDENTITY(1,1) NOT NULL,
		[UserName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Email] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Subject] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[Body] [nvarchar](2500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[IsHtml] [bit] NOT NULL CONSTRAINT [DF_SS_MailQueue_IsHtml]  DEFAULT ((1)),
		[QueueDate] [datetime] NOT NULL CONSTRAINT [DF_SS_MailQueue_QueueDate]  DEFAULT (getdate()),
		[SendDate] [datetime] NULL,
		[SMTPResponse] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[WasSent] [bit] NOT NULL CONSTRAINT [DF_SS_MailQueue_WasSent]  DEFAULT ((0)),
		[RetryCount] [int] NOT NULL CONSTRAINT [DF_SS_MailQueue_RetryCount]  DEFAULT ((5)),
		[ShouldSend] [bit] NOT NULL CONSTRAINT [DF_SS_MailQueue_ShouldSend]  DEFAULT ((1)),
		[LastTry] [datetime] NULL,
	 CONSTRAINT [PK_SS_MailQueue] PRIMARY KEY CLUSTERED 
	(
		[MailerID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_MailQueue TO PUBLIC
--GO
