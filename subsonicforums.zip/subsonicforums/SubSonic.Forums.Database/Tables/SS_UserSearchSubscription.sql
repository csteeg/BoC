IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_UserSearchSubscription')
	BEGIN
		DROP  Table SS_UserSearchSubscription
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_UserSearchSubscription]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_UserSearchSubscription](
		[SubscriptionID] [int] IDENTITY(1,1) NOT NULL,
		[SearchCriteria] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_UserSearchSubscription_CreatedOn]  DEFAULT (getdate()),
		[ModifiedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_UserSearchSubscription_ModifiedOn]  DEFAULT (getdate()),
		[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_UserSearchSubscription_Deleted]  DEFAULT ((0)),
	 CONSTRAINT [PK_SS_UserSearchSubscription] PRIMARY KEY CLUSTERED 
	(
		[SubscriptionID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_UserSearchSubscription TO PUBLIC
--GO
