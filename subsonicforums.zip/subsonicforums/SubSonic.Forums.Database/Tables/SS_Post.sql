IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_Post')
	BEGIN
		DROP  Table SS_Post
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_Post]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_Post](
		[PostID] [int] IDENTITY(1,1) NOT NULL,
		[Subject] [nvarchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[ThreadID] [int] NOT NULL,
		[PostGUID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_SS_Post_PostGUID]  DEFAULT (newid()),
		[PostTypeID] [int] NOT NULL CONSTRAINT [DF_SS_Post_PostTypeID]  DEFAULT ((1)),
		[PostText] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[FormattedPostText] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ModeratorMessage] [nvarchar](1500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[IPAddress] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[AuthorEmail] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Post_CreatedOn]  DEFAULT (getdate()),
		[ModifiedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Post_ModifiedOn]  DEFAULT (getdate()),
		[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_Post_Deleted]  DEFAULT ((0)),
		[IsAnswer] [bit] NOT NULL CONSTRAINT [DF_SS_Post_IsAnswer]  DEFAULT ((0)),
	 CONSTRAINT [PK_SS_Post] PRIMARY KEY CLUSTERED 
	(
		[PostID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_Post TO PUBLIC
--GO
