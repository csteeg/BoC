IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_ForumRole')
	BEGIN
		DROP  Table SS_ForumRole
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_ForumRole]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[SS_ForumRole](
		[RoleID] [int] IDENTITY(1,1) NOT NULL,
		[RoleName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Description] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Icon] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	 CONSTRAINT [PK_SS_ForumRole] PRIMARY KEY CLUSTERED 
	(
		[RoleID] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO

--GRANT SELECT ON SS_ForumRole TO PUBLIC
--GO
