IF EXISTS (SELECT * FROM sysobjects WHERE type = 'U' AND name = 'SS_ApplicationLog')
	BEGIN
		DROP  Table SS_ApplicationLog
	END
GO

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SS_ApplicationLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[SS_ApplicationLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[Context] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](1500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[UserName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ExtraInfo] [nvarchar](2500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LogDate] [datetime] NOT NULL CONSTRAINT [DF_SS_ApplicationLog_LogDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_SS_ApplicationLog] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END

GO

--GRANT SELECT ON SS_ApplicationLog TO PUBLIC
--GO
