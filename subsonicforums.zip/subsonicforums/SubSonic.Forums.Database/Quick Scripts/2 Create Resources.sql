
-- Creates all tables, stored procedures, views, functions and foreign keys

USE [SubSonicForums]
GO
/****** Object:  Table [dbo].[SS_Censorship]    Script Date: 11/08/2007 10:49:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_Censorship](
	[ExpressionID] [int] NOT NULL,
	[Expression] [nvarchar](20) NULL,
	[Replacement] [nvarchar](20) NULL,
 CONSTRAINT [PK_SS_Censorship] PRIMARY KEY CLUSTERED 
(
	[ExpressionID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_FormatBlock]    Script Date: 11/08/2007 10:49:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_FormatBlock](
	[FormatID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[Definition] [nvarchar](50) NOT NULL,
	[StartTag] [nvarchar](50) NOT NULL,
	[EndTag] [nvarchar](50) NULL,
	[Replacement] [nvarchar](500) NULL,
	[StartBlockWith] [nvarchar](50) NULL,
	[EndBlockWith] [nvarchar](50) NULL,
 CONSTRAINT [PK_SS_FormatBlock] PRIMARY KEY CLUSTERED 
(
	[FormatID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_Forum_Group]    Script Date: 11/08/2007 10:49:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_Forum_Group](
	[GroupID] [int] IDENTITY(1,1) NOT NULL,
	[GroupName] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[Roles] [nvarchar](250) NOT NULL CONSTRAINT [DF_SS_Forum_Group_Roles]  DEFAULT (N'*'),
	[ListOrder] [int] NOT NULL CONSTRAINT [DF_SS_Forum_Group_ListOrder]  DEFAULT ((1)),
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Forum_Group_CreatedOn]  DEFAULT (getdate()),
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Forum_Group_ModifiedOn]  DEFAULT (getdate()),
	[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_Forum_Group_Deleted]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_Forum_Group] PRIMARY KEY CLUSTERED 
(
	[GroupID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_ForumRole]    Script Date: 11/08/2007 10:49:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_ForumRole](
	[RoleID] [int] IDENTITY(1,1) NOT NULL,
	[RoleName] [nvarchar](50) NULL,
	[Description] [nvarchar](500) NULL,
	[Icon] [nvarchar](50) NULL,
 CONSTRAINT [PK_SS_ForumRole] PRIMARY KEY CLUSTERED 
(
	[RoleID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_MailQueue]    Script Date: 11/08/2007 10:49:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_MailQueue](
	[MailerID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Email] [nvarchar](50) NOT NULL,
	[Subject] [nvarchar](50) NOT NULL,
	[Body] [nvarchar](2500) NOT NULL,
	[IsHtml] [bit] NOT NULL CONSTRAINT [DF_SS_MailQueue_IsHtml]  DEFAULT ((1)),
	[QueueDate] [datetime] NOT NULL CONSTRAINT [DF_SS_MailQueue_QueueDate]  DEFAULT (getdate()),
	[SendDate] [datetime] NULL,
	[SMTPResponse] [nvarchar](500) NULL,
	[WasSent] [bit] NOT NULL CONSTRAINT [DF_SS_MailQueue_WasSent]  DEFAULT ((0)),
	[RetryCount] [int] NOT NULL CONSTRAINT [DF_SS_MailQueue_RetryCount]  DEFAULT ((5)),
	[ShouldSend] [bit] NOT NULL CONSTRAINT [DF_SS_MailQueue_ShouldSend]  DEFAULT ((1)),
	[LastTry] [datetime] NULL,
 CONSTRAINT [PK_SS_MailQueue] PRIMARY KEY CLUSTERED 
(
	[MailerID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_PostType]    Script Date: 11/08/2007 10:49:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_PostType](
	[PostTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[IsResponse] [bit] NOT NULL CONSTRAINT [DF_SS_PostType_IsResponse]  DEFAULT ((1)),
	[ListOrder] [int] NOT NULL CONSTRAINT [DF_SS_PostType_ListOrder]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_PostType] PRIMARY KEY CLUSTERED 
(
	[PostTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_ThreadType]    Script Date: 11/08/2007 10:49:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_ThreadType](
	[ThreadTypeID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](50) NULL,
	[ListOrder] [int] NOT NULL CONSTRAINT [DF_SS_ThreadType_ListOrder]  DEFAULT ((0)),
	[Icon] [nvarchar](50) NULL,
	[CssClass] [nvarchar](50) NULL,
	[AuthorCanDesignateAnswer] [bit] NOT NULL CONSTRAINT [DF_SS_ThreadType_AuthorCanAnswer]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_ThreadType] PRIMARY KEY CLUSTERED 
(
	[ThreadTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_UserProfile]    Script Date: 11/08/2007 10:49:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_UserProfile](
	[UserName] [nvarchar](50) NOT NULL,
	[TotalPosts] [int] NOT NULL CONSTRAINT [DF_SS_UserProfile_TotalPosts]  DEFAULT ((0)),
	[MemberSince] [datetime] NOT NULL CONSTRAINT [DF_SS_UserProfile_MemberSince]  DEFAULT (getdate()),
	[Email] [nvarchar](50) NOT NULL,
	[Signature] [nvarchar](150) NULL,
	[Props] [int] NOT NULL CONSTRAINT [DF_SS_UserProfile_TotalAnswers]  DEFAULT ((0)),
	[IsApproved] [bit] NOT NULL CONSTRAINT [DF_SS_UserProfile_IsApproved]  DEFAULT ((1)),
	[IsModerated] [bit] NOT NULL CONSTRAINT [DF_SS_UserProfile_IsModerated]  DEFAULT ((0)),
	[Bio] [nvarchar](2500) NULL,
	[TimeZone] [float] NULL,
	[HTMLEmail] [bit] NOT NULL CONSTRAINT [DF_SS_UserProfile_HTMLEmail]  DEFAULT ((1)),
	[AllowEmailContact] [bit] NOT NULL CONSTRAINT [DF_SS_UserProfile_AllowEmailContact]  DEFAULT ((1)),
	[HelpfulKeywords] [nvarchar](250) NULL,
	[UserRoles] [nvarchar](250) NULL,
 CONSTRAINT [PK_SS_UserProfile] PRIMARY KEY CLUSTERED 
(
	[UserName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  UserDefinedFunction [dbo].[GetThreadResolution]    Script Date: 11/08/2007 10:49:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetThreadResolution] 
	(
		@threadID int
	)
RETURNS nvarchar(50)
AS
	BEGIN
	DECLARE @result nvarchar(50)

	
	SELECT     @result=SS_PostRatingType.Resolution
	FROM         SS_PostRatings INNER JOIN
	                      SS_PostRatingType ON SS_PostRatings.RatingTypeID = SS_PostRatingType.RatingTypeID AND 
	                      SS_PostRatings.RatingTypeID = SS_PostRatingType.RatingTypeID
	WHERE threadID=@threadID AND SS_PostRatingType.RatingTypeID <> 1
	
	IF @result IS NULL
		SELECT @result='Open'
	
	RETURN @result
	END

--GRANT EXEC ON GetThreadResolution TO PUBLIC
--GO
GO
/****** Object:  Table [dbo].[CMS_Content]    Script Date: 11/08/2007 10:49:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Content](
	[ContentID] [int] IDENTITY(1,1) NOT NULL,
	[ContentGUID] [uniqueidentifier] NOT NULL,
	[Title] [nvarchar](500) NULL,
	[ContentName] [nvarchar](50) NOT NULL,
	[Body] [nvarchar](max) NULL,
	[Locale] [nvarchar](7) NOT NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NULL,
	[ModifiedBy] [nvarchar](50) NULL,
 CONSTRAINT [PK_CMS_Content] PRIMARY KEY CLUSTERED 
(
	[ContentID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[CMS_Search]    Script Date: 11/08/2007 10:49:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[CMS_Search]
(
	@query varchar(2000)
)
AS

RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_Search]    Script Date: 11/08/2007 10:49:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_Search]
(
	@query varchar(2000)
)
AS

RETURN
GO
/****** Object:  Table [dbo].[CMS_Page]    Script Date: 11/08/2007 10:49:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CMS_Page](
	[PageID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](500) NOT NULL,
	[Body] [nvarchar](max) NULL,
	[Locale] [char](5) NOT NULL,
	[ParentID] [int] NULL,
	[PageGuid] [uniqueidentifier] NOT NULL,
	[MenuTitle] [nvarchar](50) NOT NULL,
	[Roles] [nvarchar](500) NOT NULL,
	[Summary] [nvarchar](500) NULL,
	[PageUrl] [nvarchar](500) NOT NULL,
	[Keywords] [nvarchar](500) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[Deleted] [bit] NOT NULL,
 CONSTRAINT [PK_CMS_Page_1] PRIMARY KEY CLUSTERED 
(
	[PageID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[SS_ApplicationLog]    Script Date: 11/08/2007 10:49:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_ApplicationLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[Context] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](1500) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[ExtraInfo] [nvarchar](2500) NULL,
	[LogDate] [datetime] NOT NULL CONSTRAINT [DF_SS_ApplicationLog_LogDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_SS_ApplicationLog] PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_Forum]    Script Date: 11/08/2007 10:49:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_Forum](
	[ForumID] [int] IDENTITY(1,1) NOT NULL,
	[ForumName] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[ForumUrl] [nvarchar](150) NULL,
	[GroupID] [int] NOT NULL,
	[ListOrder] [nvarchar](50) NOT NULL CONSTRAINT [DF_SS_Forum_ListOrder]  DEFAULT ((1)),
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Forum_CreatedOn]  DEFAULT (getdate()),
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Forum_ModifiedOn]  DEFAULT (getdate()),
	[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_Forum_Deleted]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_Forum] PRIMARY KEY CLUSTERED 
(
	[ForumID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_User_ForumRole]    Script Date: 11/08/2007 10:49:49 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_User_ForumRole](
	[userName] [nvarchar](50) NOT NULL,
	[roleID] [int] NOT NULL,
 CONSTRAINT [PK_SS_User_ForumRole] PRIMARY KEY CLUSTERED 
(
	[userName] ASC,
	[roleID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_Post]    Script Date: 11/08/2007 10:49:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_Post](
	[PostID] [int] IDENTITY(1,1) NOT NULL,
	[Subject] [nvarchar](250) NOT NULL,
	[ThreadID] [int] NOT NULL,
	[PostGUID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_SS_Post_PostGUID]  DEFAULT (newid()),
	[PostTypeID] [int] NOT NULL CONSTRAINT [DF_SS_Post_PostTypeID]  DEFAULT ((1)),
	[PostText] [nvarchar](max) NOT NULL,
	[FormattedPostText] [nvarchar](max) NULL,
	[ModeratorMessage] [nvarchar](1500) NULL,
	[IPAddress] [nvarchar](50) NULL,
	[AuthorEmail] [nvarchar](50) NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Post_CreatedOn]  DEFAULT (getdate()),
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Post_ModifiedOn]  DEFAULT (getdate()),
	[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_Post_Deleted]  DEFAULT ((0)),
	[IsAnswer] [bit] NOT NULL CONSTRAINT [DF_SS_Post_IsAnswer]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_Post] PRIMARY KEY CLUSTERED 
(
	[PostID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_Thread]    Script Date: 11/08/2007 10:49:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_Thread](
	[ThreadID] [int] IDENTITY(1,1) NOT NULL,
	[ThreadTypeID] [int] NOT NULL CONSTRAINT [DF_SS_Thread_ThreadTypeID]  DEFAULT ((1)),
	[Subject] [nvarchar](250) NOT NULL,
	[ForumID] [int] NOT NULL,
	[Resolution] [nvarchar](50) NOT NULL CONSTRAINT [DF_SS_Thread_Resolution]  DEFAULT (N'Open'),
	[StartPostID] [int] NOT NULL CONSTRAINT [DF_SS_Thread_StartPostID]  DEFAULT ((0)),
	[ThreadUrl] [nvarchar](50) NOT NULL CONSTRAINT [DF_SS_Thread_ThreadUrl]  DEFAULT (''),
	[Views] [int] NOT NULL CONSTRAINT [DF_SS_Thread_Views]  DEFAULT ((0)),
	[TotalReplies] [int] NOT NULL CONSTRAINT [DF_SS_Thread_Posts]  DEFAULT ((0)),
	[LastViewDate] [datetime] NULL,
	[LastReplyAuthor] [nvarchar](50) NULL,
	[LastReplyDate] [datetime] NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Thread_CreatedOn]  DEFAULT (getdate()),
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_Thread_ModifiedOn]  DEFAULT (getdate()),
	[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_Thread_Deleted]  DEFAULT ((0)),
	[IsLocked] [bit] NOT NULL CONSTRAINT [DF_SS_Thread_IsClosed]  DEFAULT ((0)),
	[IsStickied] [bit] NOT NULL CONSTRAINT [DF_SS_Thread_IsStickied]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_Thread] PRIMARY KEY CLUSTERED 
(
	[ThreadID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_ThreadTypeResponse]    Script Date: 11/08/2007 10:49:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_ThreadTypeResponse](
	[ThreadTypeResponseID] [int] IDENTITY(1,1) NOT NULL,
	[ThreadTypeID] [int] NULL,
	[Description] [nvarchar](50) NULL,
	[PostDesignation] [nvarchar](50) NULL,
	[IsSearchable] [bit] NOT NULL CONSTRAINT [DF_SS_ThreadTypeResponse_IsSearchable]  DEFAULT ((0)),
	[IsDefault] [bit] NOT NULL CONSTRAINT [DF_SS_ThreadTypeResponse_IsDefault]  DEFAULT ((0)),
	[AnswererPropsValue] [int] NOT NULL CONSTRAINT [DF_SS_ThreadTypeResponse_PropsForUser]  DEFAULT ((1)),
	[ThreadAuthorPropsValue] [int] NOT NULL CONSTRAINT [DF_SS_ThreadTypeResponse_ThreadAuthorPropsValue]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_ThreaadTypeResponse] PRIMARY KEY CLUSTERED 
(
	[ThreadTypeResponseID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_User_ReadThread]    Script Date: 11/08/2007 10:49:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_User_ReadThread](
	[ReadID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[ThreadID] [int] NOT NULL,
	[ReadDate] [datetime] NOT NULL CONSTRAINT [DF_SS_User_ReadThreads_ReadDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_SS_User_ReadThreads_1] PRIMARY KEY CLUSTERED 
(
	[ReadID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_UserSearchSubscription]    Script Date: 11/08/2007 10:49:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_UserSearchSubscription](
	[SubscriptionID] [int] IDENTITY(1,1) NOT NULL,
	[SearchCriteria] [nvarchar](500) NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_UserSearchSubscription_CreatedOn]  DEFAULT (getdate()),
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_UserSearchSubscription_ModifiedOn]  DEFAULT (getdate()),
	[Deleted] [bit] NOT NULL CONSTRAINT [DF_SS_UserSearchSubscription_Deleted]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_UserSearchSubscription] PRIMARY KEY CLUSTERED 
(
	[SubscriptionID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_User_WatchedThread]    Script Date: 11/08/2007 10:49:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_User_WatchedThread](
	[UserName] [nvarchar](50) NOT NULL,
	[ThreadID] [int] NOT NULL,
	[ThreadUrl] [nvarchar](50) NOT NULL,
	[EmailNotify] [bit] NOT NULL CONSTRAINT [DF_SS_User_WatchedThread_EmailNotify]  DEFAULT ((1)),
	[CreatedOn] [datetime] NULL CONSTRAINT [DF_SS_User_WatchedThread_CreatedOn]  DEFAULT (getdate()),
	[AnswerOnly] [bit] NOT NULL CONSTRAINT [DF_SS_User_WatchedThread_AnswerOnly]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_User_Bookmarks] PRIMARY KEY CLUSTERED 
(
	[UserName] ASC,
	[ThreadID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SS_User_Answer]    Script Date: 11/08/2007 10:49:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SS_User_Answer](
	[AnswerID] [int] IDENTITY(1,1) NOT NULL,
	[PostID] [int] NOT NULL,
	[ThreadTypeResponseID] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL CONSTRAINT [DF_SS_ThreadResponse_Map_CreatedOn]  DEFAULT (getdate()),
	[CreatedBy] [nvarchar](50) NOT NULL,
	[Props] [int] NOT NULL CONSTRAINT [DF_SS_User_Answer_Props]  DEFAULT ((0)),
 CONSTRAINT [PK_SS_ThreadResponse_Map] PRIMARY KEY CLUSTERED 
(
	[AnswerID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[SS_GetForumGroups]    Script Date: 11/08/2007 10:49:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_GetForumGroups]
AS

SELECT * FROM SS_Forum_Group WHERE deleted=0

SELECT *,
--Get the thread count
(SELECT COUNT(threadID) FROM SS_Thread 
WHERE forumID=SS_Forum.ForumID AND SS_Thread.Deleted=0)
as ThreadCount,

--get the post count
(SELECT COUNT(postID) FROM SS_Post
 INNER JOIN SS_Thread ON SS_Post.ThreadID=SS_Thread.ThreadID
 WHERE SS_Thread.ForumID=SS_Forum.ForumID  AND SS_Post.Deleted=0)
as PostCount

FROM SS_Forum WHERE Deleted=0

RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_WipeoutForums]    Script Date: 11/08/2007 10:49:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_WipeoutForums]
AS

BEGIN
	DELETE FROM SS_User_ReadThread
	DELETE FROM SS_User_Answer
	DELETE FROM SS_User_WatchedThread
	DELETE FROM SS_User_ForumRole
	DELETE FROM SS_UserSearchSubscription
	DELETE FROM SS_Post
	DELETE FROM SS_Thread
	DELETE FROM SS_Forum
	DELETE FROM SS_Forum_Group
	DELETE FROM SS_UserProfile
	DELETE FROM SS_MailQueue
	
END
GO
/****** Object:  View [dbo].[SS_PostView]    Script Date: 11/08/2007 10:49:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE View [dbo].[SS_PostView] AS

SELECT     dbo.SS_Post.ThreadID, dbo.SS_Post.Subject, dbo.SS_PostType.Description AS PostType, dbo.SS_PostType.PostTypeID, dbo.SS_Post.PostGUID, 
                      dbo.SS_Post.FormattedPostText, dbo.SS_Post.CreatedOn, dbo.SS_Post.CreatedBy, dbo.SS_Post.PostID, dbo.SS_Post.Deleted, 
                      dbo.SS_UserProfile.Signature, dbo.SS_ThreadTypeResponse.PostDesignation, dbo.SS_ThreadTypeResponse.Description AS Response, 
                      dbo.SS_UserProfile.Email AS AuthorEmail, dbo.SS_UserProfile.Props, dbo.SS_Post.PostText, dbo.SS_UserProfile.UserRoles
FROM         dbo.SS_ThreadTypeResponse INNER JOIN
                      dbo.SS_User_Answer ON dbo.SS_ThreadTypeResponse.ThreadTypeResponseID = dbo.SS_User_Answer.ThreadTypeResponseID RIGHT OUTER JOIN
                      dbo.SS_Post INNER JOIN
                      dbo.SS_PostType ON dbo.SS_Post.PostTypeID = dbo.SS_PostType.PostTypeID INNER JOIN
                      dbo.SS_UserProfile ON dbo.SS_Post.CreatedBy = dbo.SS_UserProfile.UserName ON dbo.SS_User_Answer.PostID = dbo.SS_Post.PostID
GO
/****** Object:  View [dbo].[SS_ThreadPostType]    Script Date: 11/08/2007 10:49:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE View [dbo].[SS_ThreadPostType] AS

SELECT     dbo.SS_Thread.ThreadID, dbo.SS_PostType.Description AS PostType, dbo.SS_Thread.Subject, dbo.SS_Thread.ThreadUrl
FROM         dbo.SS_PostType INNER JOIN
                      dbo.SS_Post ON dbo.SS_PostType.PostTypeID = dbo.SS_Post.PostTypeID INNER JOIN
                      dbo.SS_Thread ON dbo.SS_Post.PostID = dbo.SS_Thread.StartPostID
GO
/****** Object:  View [dbo].[SS_ThreadView]    Script Date: 11/08/2007 10:49:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE View [dbo].[SS_ThreadView] AS

SELECT     dbo.SS_Thread.ThreadID, dbo.SS_Thread.ThreadTypeID, dbo.SS_Thread.Subject, dbo.SS_Thread.ForumID, dbo.SS_Thread.Resolution, 
                      dbo.SS_Thread.StartPostID, dbo.SS_Thread.ThreadUrl, dbo.SS_Thread.Views, dbo.SS_Thread.TotalReplies, dbo.SS_Thread.LastViewDate, 
                      dbo.SS_Thread.LastReplyAuthor, dbo.SS_Thread.LastReplyDate, dbo.SS_Thread.CreatedBy, dbo.SS_Thread.CreatedOn, dbo.SS_Thread.ModifiedBy, 
                      dbo.SS_Thread.ModifiedOn, dbo.SS_Thread.Deleted, dbo.SS_Thread.IsLocked, dbo.SS_Thread.IsStickied, dbo.SS_ThreadType.Description, 
                      dbo.SS_ThreadType.ListOrder, dbo.SS_ThreadType.Icon
FROM         dbo.SS_Thread INNER JOIN
                      dbo.SS_ThreadType ON dbo.SS_Thread.ThreadTypeID = dbo.SS_ThreadType.ThreadTypeID
GO
/****** Object:  StoredProcedure [dbo].[SS_UserThreads]    Script Date: 11/08/2007 10:49:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_UserThreads]
(
	@userName nvarchar(50)
)
AS

SELECT     TOP (50) SS_Thread.ThreadID, SS_Forum.ForumID, SS_Forum.ForumName, SS_Forum.ForumUrl, SS_Thread.Subject, SS_Thread.ThreadUrl, 
                      SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, SS_Thread.CreatedBy, 
                      SS_Thread.CreatedOn, SS_UserProfile.UserName AS ThreadAuthor, SS_UserProfile.Email AS AuthorEmail, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Resolution, 'true' as UserHasRead
FROM         SS_UserProfile INNER JOIN
                      SS_Thread INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_Forum ON SS_Thread.ForumID = SS_Forum.ForumID INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID ON SS_UserProfile.UserName = SS_Thread.CreatedBy
WHERE SS_Thread.ThreadID IN (SELECT DISTINCT TOP 50  ThreadID FROM SS_POST WHERE createdBy=@userName)
ORDER BY SS_Thread.LastReplyDate DESC
RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_SearchAllThreads]    Script Date: 11/08/2007 10:49:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_SearchAllThreads]
(
	@query varchar(2000)
)
AS

SELECT     SS_Post.Subject, SS_Post.FormattedPostText, FT.RANK, SS_Thread.Subject AS Topic, SS_Thread.CreatedBy AS ThreadAuthor, 
                      SS_ThreadTypeResponse.IsSearchable, SS_ThreadTypeResponse.Description AS Response, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Deleted, SS_Thread.ThreadUrl, SS_Post.PostID, SS_UserProfile.Email AS AuthorEmail, 
                      SS_ThreadTypeResponse_1.PostDesignation
					  AS AnswerType
                      
FROM         SS_ThreadTypeResponse AS SS_ThreadTypeResponse_1 INNER JOIN
                      SS_User_Answer ON SS_ThreadTypeResponse_1.ThreadTypeResponseID = SS_User_Answer.ThreadTypeResponseID RIGHT OUTER JOIN
                      FREETEXTTABLE(SS_Post, *, @query, 50) AS FT INNER JOIN
                      SS_Post ON FT.[KEY] = SS_Post.PostID INNER JOIN
                      SS_Thread ON SS_Post.ThreadID = SS_Thread.ThreadID INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_ThreadTypeResponse ON SS_ThreadType.ThreadTypeID = SS_ThreadTypeResponse.ThreadTypeID INNER JOIN
                      SS_UserProfile ON SS_Thread.CreatedBy = SS_UserProfile.UserName ON SS_User_Answer.PostID = SS_Post.PostID
WHERE     (SS_Post.Deleted = 0) AND (SS_ThreadTypeResponse.IsSearchable = 1) AND (SS_Thread.Deleted = 0)
	
	RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_NewestThreads]    Script Date: 11/08/2007 10:49:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_NewestThreads]
(
	@userName nvarchar(50)
)
AS

SELECT     TOP (20) SS_Thread.ThreadID, SS_Forum.ForumID, SS_Forum.ForumName, SS_Forum.ForumUrl, SS_Thread.Subject, SS_Thread.ThreadUrl, 
                      SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, SS_Thread.CreatedBy, 
                      SS_Thread.CreatedOn, SS_UserProfile.UserName AS ThreadAuthor, SS_UserProfile.Email AS AuthorEmail, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Resolution, 
                      CASE
                      (SELECT TOP 1 readID FROM SS_User_ReadThread WHERE threadID=SS_Thread.ThreadID)
                      WHEN NULL THEN 'false'
                      ELSE 'true'
                      END
                      as UserHasRead
FROM         SS_UserProfile INNER JOIN
                      SS_Thread INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_Forum ON SS_Thread.ForumID = SS_Forum.ForumID INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID ON SS_UserProfile.UserName = SS_Thread.CreatedBy

ORDER BY SS_Thread.CreatedOn DESC

RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_SearchAnsweredThreads]    Script Date: 11/08/2007 10:49:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_SearchAnsweredThreads]
(
	@query varchar(2000)
)
AS

SELECT     SS_Post.Subject, SS_Post.FormattedPostText, FT.RANK, SS_Thread.Subject AS Topic, SS_Thread.CreatedBy AS ThreadAuthor, 
                      SS_ThreadTypeResponse.IsSearchable, SS_ThreadTypeResponse.Description AS Response, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Deleted, SS_Thread.ThreadUrl, SS_Post.PostID, SS_ThreadTypeResponse_1.PostDesignation AS AnswerType, 
                      SS_User_Answer.CreatedBy AS AnswerAuthor, SS_UserProfile.Email AS AuthorEmail
FROM         FREETEXTTABLE(SS_Post, *, @query, 50) AS FT INNER JOIN
                      SS_Post ON FT.[KEY] = SS_Post.PostID INNER JOIN
                      SS_Thread ON SS_Post.ThreadID = SS_Thread.ThreadID INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_ThreadTypeResponse ON SS_ThreadType.ThreadTypeID = SS_ThreadTypeResponse.ThreadTypeID INNER JOIN
                      SS_User_Answer ON SS_Post.PostID = SS_User_Answer.PostID INNER JOIN
                      SS_ThreadTypeResponse AS SS_ThreadTypeResponse_1 ON 
                      SS_User_Answer.ThreadTypeResponseID = SS_ThreadTypeResponse_1.ThreadTypeResponseID INNER JOIN
                      SS_UserProfile ON SS_Thread.CreatedBy = SS_UserProfile.UserName
WHERE     (SS_Post.Deleted = 0) AND (SS_ThreadTypeResponse.IsSearchable = 1) AND (SS_Thread.Deleted = 0)

RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_SearchUnAnsweredThreads]    Script Date: 11/08/2007 10:49:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_SearchUnAnsweredThreads]
(
	@query varchar(2000)
)
AS

SELECT     SS_Post.Subject, SS_Post.FormattedPostText, FT.RANK, SS_Thread.Subject AS Topic, SS_Thread.CreatedBy AS ThreadAuthor, 
                      SS_ThreadTypeResponse.IsSearchable, SS_ThreadTypeResponse.Description AS Response, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Deleted, SS_Thread.ThreadUrl, SS_Post.PostID, SS_ThreadTypeResponse_1.PostDesignation AS AnswerType, 
                      SS_User_Answer.CreatedBy AS AnswerAuthor, SS_UserProfile.Email AS AuthorEmail
FROM         FREETEXTTABLE(SS_Post, *, @query, 50) AS FT INNER JOIN
                      SS_Post ON FT.[KEY] = SS_Post.PostID INNER JOIN
                      SS_Thread ON SS_Post.ThreadID = SS_Thread.ThreadID INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_ThreadTypeResponse ON SS_ThreadType.ThreadTypeID = SS_ThreadTypeResponse.ThreadTypeID INNER JOIN
                      SS_User_Answer ON SS_Post.PostID = SS_User_Answer.PostID INNER JOIN
                      SS_ThreadTypeResponse AS SS_ThreadTypeResponse_1 ON 
                      SS_User_Answer.ThreadTypeResponseID = SS_ThreadTypeResponse_1.ThreadTypeResponseID INNER JOIN
                      SS_UserProfile ON SS_Thread.CreatedBy = SS_UserProfile.UserName
WHERE     (SS_Post.Deleted = 0) AND (SS_ThreadTypeResponse.IsSearchable = 1) AND (SS_Thread.Deleted = 0) AND 
                      (SS_ThreadTypeResponse_1.PostDesignation IS NULL)	

RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_UserCanHelpWith]    Script Date: 11/08/2007 10:49:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_UserCanHelpWith]
(
	@userName nvarchar(50),
	@query nvarchar(500)
)
AS

SELECT     SS_Thread.ThreadUrl, SS_Thread.ThreadID, SS_ThreadType.Description AS ThreadType, SS_User_Answer.AnswerID, 
                      LEFT(SS_Post.FormattedPostText, 100) + '...' AS PostText, SS_Thread.Resolution, SS_Thread.Subject
FROM         FREETEXTTABLE(SS_Post, *, @query, 10) AS FT CROSS JOIN
                      SS_Thread INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID LEFT OUTER JOIN
                      SS_User_Answer INNER JOIN
                      SS_Post AS SS_Post_1 ON SS_User_Answer.PostID = SS_Post_1.PostID ON SS_Thread.ThreadID = SS_Post_1.ThreadID
WHERE     (FT.[KEY] = SS_Post.PostID) AND (SS_User_Answer.AnswerID IS NULL)


RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_UserUnreadThreads]    Script Date: 11/08/2007 10:49:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_UserUnreadThreads]
(
	@userName nvarchar(50)
)
AS

SELECT     TOP (20) SS_Thread.ThreadID, SS_Forum.ForumID, SS_Forum.ForumName, SS_Forum.ForumUrl, SS_Thread.Subject, SS_Thread.ThreadUrl, 
                      SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, SS_Thread.CreatedBy, 
                      SS_Thread.CreatedOn, SS_UserProfile.UserName AS ThreadAuthor, SS_UserProfile.Email AS AuthorEmail, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Resolution, 0 as UserHasRead
FROM         SS_UserProfile INNER JOIN
                      SS_Thread INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_Forum ON SS_Thread.ForumID = SS_Forum.ForumID INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID ON SS_UserProfile.UserName = SS_Thread.CreatedBy
WHERE     (SS_Thread.ThreadID NOT IN
                          (SELECT     ThreadID
                            FROM          SS_User_ReadThread
                            WHERE      (UserName = @userName)))
ORDER BY SS_Thread.LastReplyDate DESC

SELECT COUNT(threadID) as notReadCount FROM SS_Thread WHERE SS_Thread.ThreadID NOT IN (SELECT threadID FROM SS_User_ReadThread WHERE userName=@userName)

RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_UserWatchedThreads]    Script Date: 11/08/2007 10:49:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_UserWatchedThreads]
(
	@userName nvarchar(50)
)
AS

SELECT     TOP (50) SS_Thread.ThreadID, SS_Forum.ForumID, SS_Forum.ForumName, SS_Forum.ForumUrl, SS_Thread.Subject, SS_Thread.ThreadUrl, 
                      SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, SS_Thread.CreatedBy, 
                      SS_Thread.CreatedOn, SS_UserProfile.UserName AS ThreadAuthor, SS_UserProfile.Email AS AuthorEmail, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Resolution, 'true' as UserHasRead
FROM         SS_UserProfile INNER JOIN
                      SS_Thread INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_Forum ON SS_Thread.ForumID = SS_Forum.ForumID INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID ON SS_UserProfile.UserName = SS_Thread.CreatedBy
WHERE SS_Thread.ThreadID IN (SELECT threadID FROM SS_User_WatchedThread WHERE userName=@userName)
ORDER BY SS_Thread.LastReplyDate DESC
RETURN
GO
/****** Object:  View [dbo].[SS_ThreadWatchList]    Script Date: 11/08/2007 10:49:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE View [dbo].[SS_ThreadWatchList] AS

SELECT     dbo.SS_UserProfile.Email, dbo.SS_User_WatchedThread.UserName, dbo.SS_User_WatchedThread.ThreadID, 
                      dbo.SS_User_WatchedThread.ThreadUrl, dbo.SS_UserProfile.AllowEmailContact, dbo.SS_UserProfile.HTMLEmail, 
                      dbo.SS_User_WatchedThread.AnswerOnly, dbo.SS_User_WatchedThread.EmailNotify
FROM         dbo.SS_UserProfile INNER JOIN
                      dbo.SS_User_WatchedThread ON dbo.SS_UserProfile.UserName = dbo.SS_User_WatchedThread.UserName
GO
/****** Object:  View [dbo].[SS_ThreadSummary]    Script Date: 11/08/2007 10:49:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE View [dbo].[SS_ThreadSummary] AS

SELECT     SS_Post_1.Subject AS ThreadSubject, SS_Post_1.FormattedPostText AS Question, dbo.SS_Post.FormattedPostText AS Reply, 
                      dbo.SS_Thread.ThreadUrl, dbo.SS_Post.PostID, SS_Post_1.CreatedBy AS ThreadAuthor, dbo.SS_Post.CreatedBy AS ReplyAuthor
FROM         dbo.SS_Thread INNER JOIN
                      dbo.SS_Post ON dbo.SS_Thread.ThreadID = dbo.SS_Post.ThreadID INNER JOIN
                      dbo.SS_Post AS SS_Post_1 ON dbo.SS_Thread.StartPostID = SS_Post_1.PostID AND dbo.SS_Post.PostID <> SS_Post_1.PostID
GO
/****** Object:  View [dbo].[SS_UserReadForums]    Script Date: 11/08/2007 10:49:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE View [dbo].[SS_UserReadForums] AS

SELECT     dbo.SS_User_ReadThread.ReadID, dbo.SS_User_ReadThread.UserName, dbo.SS_User_ReadThread.ThreadID, dbo.SS_Thread.ForumID, 
                      dbo.SS_User_ReadThread.ReadDate
FROM         dbo.SS_Thread INNER JOIN
                      dbo.SS_User_ReadThread ON dbo.SS_Thread.ThreadID = dbo.SS_User_ReadThread.ThreadID
GO
/****** Object:  View [dbo].[SS_ThreadResponses]    Script Date: 11/08/2007 10:49:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE View [dbo].[SS_ThreadResponses] AS

SELECT     dbo.SS_Thread.ThreadID, dbo.SS_ThreadTypeResponse.ThreadTypeResponseID, dbo.SS_ThreadTypeResponse.ThreadTypeID, 
                      dbo.SS_ThreadTypeResponse.Description, dbo.SS_ThreadTypeResponse.PostDesignation, dbo.SS_ThreadTypeResponse.IsSearchable, 
                      dbo.SS_ThreadTypeResponse.IsDefault, dbo.SS_Post.CreatedBy AS ResponseAuthor, dbo.SS_Thread.Subject, dbo.SS_Post.PostID
FROM         dbo.SS_Post INNER JOIN
                      dbo.SS_Thread ON dbo.SS_Post.ThreadID = dbo.SS_Thread.ThreadID INNER JOIN
                      dbo.SS_User_Answer ON dbo.SS_Post.PostID = dbo.SS_User_Answer.PostID INNER JOIN
                      dbo.SS_ThreadTypeResponse ON dbo.SS_User_Answer.ThreadTypeResponseID = dbo.SS_ThreadTypeResponse.ThreadTypeResponseID
GO
/****** Object:  UserDefinedFunction [dbo].[GetLastPoster]    Script Date: 11/08/2007 10:49:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetLastPoster]
	(
		@threadID int
	)
RETURNS nvarchar(50)
AS
	BEGIN
	
	DECLARE @result nvarchar(50)
	
		SELECT TOP 1 @result=SS_Post.CreatedBy + ' on ' + CONVERT(nvarchar(50),SS_Post.CreatedOn)
		FROM SS_Post
		WHERE threadID=@threadID
		ORDER BY createdOn DESC		
	RETURN @result
	END
GO
/****** Object:  StoredProcedure [dbo].[CMS_GetPageHierarchy]    Script Date: 11/08/2007 10:49:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[CMS_GetPageHierarchy]
AS

	WITH PageCTE (parentID, pageID, title, pageUrl, menuTitle, theLevel,sortKey)
	AS
	(
	-- Anchor member definition. These records are your "top level", or "anchor"
	SELECT e.parentID, e.pageID, e.title, e.pageUrl, e.menuTitle,
	0 AS theLevel,
		--this is my sortkey- using VARBINARY
		CAST (e.pageID AS VARBINARY(900))
	FROM CMS_Page AS e
	WHERE parentID IS NULL
	--UNION the top level to the "child level"
		UNION ALL
	-- Recursive member definition
	--ths is the same query as above, but we''re going to join it now to the
		--CTE itself
		SELECT e.parentID, e.pageID, e.title, e.pageUrl, e.menuTitle, theLevel + 1,
	--increment the sortkey
	CAST (d.sortKey + CAST (e.pageID AS BINARY(4)) AS VARBINARY(900))
	FROM CMS_Page AS e
	INNER JOIN PageCTE AS d
	ON e.parentID = d.pageID
	)
	-- Run a select from the CTE, and sort it by the sortKey
	SELECT * FROM PageCTE
	order by sortKey
	 
	RETURN
GO
/****** Object:  StoredProcedure [dbo].[CMS_GetPageHierarchyByParent]    Script Date: 11/08/2007 10:49:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[CMS_GetPageHierarchyByParent]
(
	@parentID int
)
AS

WITH PageCTE (parentID, pageID, title, theLevel,sortKey)
AS
(
-- Anchor member definition. These records are your "top level", or "anchor"
SELECT e.parentID, e.pageID, e.title,
0 AS theLevel,
	--this is my sortkey- using VARBINARY
	CAST (e.pageID AS VARBINARY(900))
FROM CMS_Page AS e
WHERE pageID= @parentID
--UNION the top level to the "child level"
	UNION ALL
-- Recursive member definition
--ths is the same query as above, but we're going to join it now to the
	--CTE itself
	SELECT e.parentID, e.pageID, e.title, theLevel + 1,
--increment the sortkey
CAST (d.sortKey + CAST (e.pageID AS BINARY(4)) AS VARBINARY(900))
FROM CMS_Page AS e
INNER JOIN PageCTE AS d
ON e.parentID = d.pageID
)
-- Run a select from the CTE, and sort it by the sortKey
SELECT * FROM PageCTE
order by sortKey

 
RETURN
GO
/****** Object:  StoredProcedure [dbo].[SS_GetThread]    Script Date: 11/08/2007 10:49:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SS_GetThread]
(
	@threadID int,
	@userName nvarchar(50)=''
)
AS


--#######################################################################
--Housekeeping
--#######################################################################
	--mark thread as read by this user
	IF @userName<>''
		IF NOT EXISTS (
			SELECT userName FROM SS_User_ReadThread 
			WHERE userName=@userName 
			AND threadID=@threadID)
			
			INSERT INTO SS_User_ReadThread(userName,threadID) VALUES(@userName, @threadID)
	
	
	--debit the view count
	UPDATE SS_Thread SET Views=Views+1, LastViewDate=getdate()
	WHERE threadID=@threadID
	
--#######################################################################
--RETURN Sets
--#######################################################################

	---get the first post, this is the thread starter
	DECLARE @threadStartPostID int
	DECLARE @forumID int
	
	SELECT TOP 1  @threadStartPostID= PostID 
	FROM SS_Post WHERE threadID=@threadID
	ORDER BY CreatedOn
	
	SELECT @forumID=forumID FROM SS_Thread WHERE threadID=@threadID
	
	--the thread info
	SELECT     SS_Thread.ThreadID, SS_Thread.ThreadTypeID, SS_Thread.Subject, SS_Thread.ForumID, SS_Thread.Resolution, SS_Thread.StartPostID, 
	                      SS_Thread.ThreadUrl, SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, 
	                      SS_Thread.CreatedBy, SS_Thread.CreatedOn, SS_Thread.ModifiedBy, SS_Thread.ModifiedOn, SS_Thread.Deleted, SS_Thread.IsLocked, 
	                      SS_Thread.IsStickied, SS_ThreadType.AuthorCanDesignateAnswer, SS_ThreadType.CssClass, SS_ThreadType.Icon, SS_ThreadType.ListOrder, 
	                      SS_ThreadType.Description AS ThreadType
	FROM         SS_Thread INNER JOIN
	                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID
	WHERE     (SS_Thread.ThreadID = @threadID)
	
	--starter post
	SELECT     ThreadID, Subject, PostType, PostTypeID, PostGUID, FormattedPostText, CreatedOn, CreatedBy, PostID, Deleted, Signature, PostDesignation, 
	                      Response, AuthorEmail, Props, PostText, UserRoles
	FROM         SS_PostView
	WHERE     (PostID = @threadStartPostID)

	--next, get all the replies
	SELECT     SS_PostView.ThreadID, SS_PostView.Subject, SS_PostView.PostType, SS_PostView.PostTypeID, SS_PostView.PostGUID, 
	                      SS_PostView.FormattedPostText, SS_PostView.CreatedOn, SS_PostView.CreatedBy, SS_PostView.PostID, SS_PostView.Deleted, 
	                      SS_PostView.Signature, SS_PostView.PostDesignation, SS_PostView.Response, SS_PostView.AuthorEmail, SS_PostView.Props, 
	                      SS_PostView.PostText, SS_PostView.UserRoles
	FROM         SS_Thread INNER JOIN
	                      SS_PostView ON SS_Thread.ThreadID = SS_PostView.ThreadID AND SS_Thread.StartPostID <> SS_PostView.PostID
	WHERE     (SS_PostView.ThreadID = @threadID)
	ORDER BY SS_PostView.CreatedOn
	
	--parent forum
	SELECT     ForumID, ForumName, ForumUrl, Deleted, Description, GroupID, ListOrder, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
	FROM         SS_Forum
	WHERE     (Deleted = 0) AND (ForumID = @forumID)


	
	--answers
	SELECT     ThreadID, ThreadTypeResponseID, ThreadTypeID, Description, PostDesignation, IsSearchable, IsDefault, ResponseAuthor, Subject, PostID
	FROM         SS_ThreadResponses
	WHERE     (ThreadID = @threadID)
	
	--response options
	SELECT     SS_ThreadTypeResponse.ThreadTypeResponseID, SS_ThreadTypeResponse.ThreadTypeID, SS_ThreadTypeResponse.Description, 
	                      SS_ThreadTypeResponse.PostDesignation, SS_ThreadTypeResponse.IsSearchable, SS_ThreadTypeResponse.IsDefault, 
	                      SS_ThreadTypeResponse.AnswererPropsValue, SS_ThreadTypeResponse.ThreadAuthorPropsValue, SS_Thread.ThreadID
	FROM         SS_Thread INNER JOIN
	                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
	                      SS_ThreadTypeResponse ON SS_ThreadType.ThreadTypeID = SS_ThreadTypeResponse.ThreadTypeID
	WHERE     (SS_Thread.ThreadID = @threadID)
	
	--see if this thread is watched
	DECLARE @watched bit
	IF EXISTS(SELECT threadID FROM SS_User_WatchedThread WHERE userName=@userName and threadID=@threadID)
		SELECT @watched=1
	ELSE
		SELECT @watched=0
		
	SELECT @watched as UserIsWatching
	RETURN
GO
/****** Object:  ForeignKey [FK_SS_Forum_SS_Forum_Group]    Script Date: 11/08/2007 10:49:24 ******/
ALTER TABLE [dbo].[SS_Forum]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_Forum_SS_Forum_Group] FOREIGN KEY([GroupID])
REFERENCES [dbo].[SS_Forum_Group] ([GroupID])
GO
ALTER TABLE [dbo].[SS_Forum] CHECK CONSTRAINT [FK_SS_Forum_SS_Forum_Group]
GO
/****** Object:  ForeignKey [FK_SS_Post_SS_PostType]    Script Date: 11/08/2007 10:49:36 ******/
ALTER TABLE [dbo].[SS_Post]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_Post_SS_PostType] FOREIGN KEY([PostTypeID])
REFERENCES [dbo].[SS_PostType] ([PostTypeID])
GO
ALTER TABLE [dbo].[SS_Post] CHECK CONSTRAINT [FK_SS_Post_SS_PostType]
GO
/****** Object:  ForeignKey [FK_SS_Post_SS_Thread]    Script Date: 11/08/2007 10:49:36 ******/
ALTER TABLE [dbo].[SS_Post]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_Post_SS_Thread] FOREIGN KEY([ThreadID])
REFERENCES [dbo].[SS_Thread] ([ThreadID])
GO
ALTER TABLE [dbo].[SS_Post] CHECK CONSTRAINT [FK_SS_Post_SS_Thread]
GO
/****** Object:  ForeignKey [FK_SS_Post_SS_UserProfile]    Script Date: 11/08/2007 10:49:36 ******/
ALTER TABLE [dbo].[SS_Post]  WITH CHECK ADD  CONSTRAINT [FK_SS_Post_SS_UserProfile] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[SS_UserProfile] ([UserName])
GO
ALTER TABLE [dbo].[SS_Post] CHECK CONSTRAINT [FK_SS_Post_SS_UserProfile]
GO
/****** Object:  ForeignKey [FK_SS_Thread_SS_Forum]    Script Date: 11/08/2007 10:49:42 ******/
ALTER TABLE [dbo].[SS_Thread]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_Thread_SS_Forum] FOREIGN KEY([ForumID])
REFERENCES [dbo].[SS_Forum] ([ForumID])
GO
ALTER TABLE [dbo].[SS_Thread] CHECK CONSTRAINT [FK_SS_Thread_SS_Forum]
GO
/****** Object:  ForeignKey [FK_SS_Thread_SS_ThreadType]    Script Date: 11/08/2007 10:49:42 ******/
ALTER TABLE [dbo].[SS_Thread]  WITH CHECK ADD  CONSTRAINT [FK_SS_Thread_SS_ThreadType] FOREIGN KEY([ThreadTypeID])
REFERENCES [dbo].[SS_ThreadType] ([ThreadTypeID])
GO
ALTER TABLE [dbo].[SS_Thread] CHECK CONSTRAINT [FK_SS_Thread_SS_ThreadType]
GO
/****** Object:  ForeignKey [FK_SS_ThreaadTypeResponse_SS_ThreadType]    Script Date: 11/08/2007 10:49:46 ******/
ALTER TABLE [dbo].[SS_ThreadTypeResponse]  WITH NOCHECK ADD  CONSTRAINT [FK_SS_ThreaadTypeResponse_SS_ThreadType] FOREIGN KEY([ThreadTypeID])
REFERENCES [dbo].[SS_ThreadType] ([ThreadTypeID])
GO
ALTER TABLE [dbo].[SS_ThreadTypeResponse] CHECK CONSTRAINT [FK_SS_ThreaadTypeResponse_SS_ThreadType]
GO
/****** Object:  ForeignKey [FK_SS_ThreadResponse_Map_SS_Post]    Script Date: 11/08/2007 10:49:48 ******/
ALTER TABLE [dbo].[SS_User_Answer]  WITH CHECK ADD  CONSTRAINT [FK_SS_ThreadResponse_Map_SS_Post] FOREIGN KEY([PostID])
REFERENCES [dbo].[SS_Post] ([PostID])
GO
ALTER TABLE [dbo].[SS_User_Answer] CHECK CONSTRAINT [FK_SS_ThreadResponse_Map_SS_Post]
GO
/****** Object:  ForeignKey [FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse]    Script Date: 11/08/2007 10:49:48 ******/
ALTER TABLE [dbo].[SS_User_Answer]  WITH CHECK ADD  CONSTRAINT [FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse] FOREIGN KEY([ThreadTypeResponseID])
REFERENCES [dbo].[SS_ThreadTypeResponse] ([ThreadTypeResponseID])
GO
ALTER TABLE [dbo].[SS_User_Answer] CHECK CONSTRAINT [FK_SS_ThreadResponse_Map_SS_ThreadTypeResponse]
GO
/****** Object:  ForeignKey [FK_SS_User_Answer_SS_UserProfile]    Script Date: 11/08/2007 10:49:48 ******/
ALTER TABLE [dbo].[SS_User_Answer]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_Answer_SS_UserProfile] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[SS_UserProfile] ([UserName])
GO
ALTER TABLE [dbo].[SS_User_Answer] CHECK CONSTRAINT [FK_SS_User_Answer_SS_UserProfile]
GO
/****** Object:  ForeignKey [FK_SS_User_ForumRole_SS_ForumRole]    Script Date: 11/08/2007 10:49:49 ******/
ALTER TABLE [dbo].[SS_User_ForumRole]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_ForumRole_SS_ForumRole] FOREIGN KEY([roleID])
REFERENCES [dbo].[SS_ForumRole] ([RoleID])
GO
ALTER TABLE [dbo].[SS_User_ForumRole] CHECK CONSTRAINT [FK_SS_User_ForumRole_SS_ForumRole]
GO
/****** Object:  ForeignKey [FK_SS_User_ForumRole_SS_UserProfile]    Script Date: 11/08/2007 10:49:49 ******/
ALTER TABLE [dbo].[SS_User_ForumRole]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_ForumRole_SS_UserProfile] FOREIGN KEY([userName])
REFERENCES [dbo].[SS_UserProfile] ([UserName])
GO
ALTER TABLE [dbo].[SS_User_ForumRole] CHECK CONSTRAINT [FK_SS_User_ForumRole_SS_UserProfile]
GO
/****** Object:  ForeignKey [FK_SS_User_ReadThreads_SS_UserProfile]    Script Date: 11/08/2007 10:49:50 ******/
ALTER TABLE [dbo].[SS_User_ReadThread]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_ReadThreads_SS_UserProfile] FOREIGN KEY([UserName])
REFERENCES [dbo].[SS_UserProfile] ([UserName])
GO
ALTER TABLE [dbo].[SS_User_ReadThread] CHECK CONSTRAINT [FK_SS_User_ReadThreads_SS_UserProfile]
GO
/****** Object:  ForeignKey [FK_SS_User_WatchedThread_SS_Thread]    Script Date: 11/08/2007 10:49:52 ******/
ALTER TABLE [dbo].[SS_User_WatchedThread]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_WatchedThread_SS_Thread] FOREIGN KEY([ThreadID])
REFERENCES [dbo].[SS_Thread] ([ThreadID])
GO
ALTER TABLE [dbo].[SS_User_WatchedThread] CHECK CONSTRAINT [FK_SS_User_WatchedThread_SS_Thread]
GO
/****** Object:  ForeignKey [FK_SS_User_WatchedThread_SS_UserProfile]    Script Date: 11/08/2007 10:49:52 ******/
ALTER TABLE [dbo].[SS_User_WatchedThread]  WITH CHECK ADD  CONSTRAINT [FK_SS_User_WatchedThread_SS_UserProfile] FOREIGN KEY([UserName])
REFERENCES [dbo].[SS_UserProfile] ([UserName])
GO
ALTER TABLE [dbo].[SS_User_WatchedThread] CHECK CONSTRAINT [FK_SS_User_WatchedThread_SS_UserProfile]
GO
/****** Object:  ForeignKey [FK_SS_UserSearchSubscription_SS_UserProfile1]    Script Date: 11/08/2007 10:49:58 ******/
ALTER TABLE [dbo].[SS_UserSearchSubscription]  WITH CHECK ADD  CONSTRAINT [FK_SS_UserSearchSubscription_SS_UserProfile1] FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[SS_UserProfile] ([UserName])
GO
ALTER TABLE [dbo].[SS_UserSearchSubscription] CHECK CONSTRAINT [FK_SS_UserSearchSubscription_SS_UserProfile1]
GO
