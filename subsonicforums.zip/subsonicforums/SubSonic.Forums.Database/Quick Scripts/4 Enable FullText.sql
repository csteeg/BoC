
--enable the FT index
exec sp_fulltext_database 'enable'

--create the catalog - need to have rights to do this
exec sp_fulltext_catalog 'ForumsCatalog', 'create'

--add the tables to the index
exec sp_fulltext_table 'SS_Post', 'create', 'ForumsCatalog', 'PK_SS_Post'

--add the columns
exec sp_fulltext_column 'SS_Post', 'Subject', 'add'
exec sp_fulltext_column 'SS_Post', 'PostText', 'add'

--activate them
exec sp_fulltext_table 'SS_Post', 'activate'

--enable background updates
exec sp_fulltext_table 'SS_Post','start_change_tracking'
exec sp_fulltext_table 'SS_Post','start_background_updateindex' 

--start population
exec sp_fulltext_catalog 'ForumsCatalog','start_full'
