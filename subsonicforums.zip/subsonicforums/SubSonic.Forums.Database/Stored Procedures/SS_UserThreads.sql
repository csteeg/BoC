IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_UserThreads')
	BEGIN
		DROP  Procedure  SS_UserThreads
	END

GO

CREATE Procedure dbo.SS_UserThreads
(
	@userName nvarchar(50)
)
AS

SELECT     TOP (50) SS_Thread.ThreadID, SS_Forum.ForumID, SS_Forum.ForumName, SS_Forum.ForumUrl, SS_Thread.Subject, SS_Thread.ThreadUrl, 
                      SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, SS_Thread.CreatedBy, 
                      SS_Thread.CreatedOn, SS_UserProfile.UserName AS ThreadAuthor, SS_UserProfile.Email AS AuthorEmail, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Resolution, 'true' as UserHasRead
FROM         SS_UserProfile INNER JOIN
                      SS_Thread INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_Forum ON SS_Thread.ForumID = SS_Forum.ForumID INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID ON SS_UserProfile.UserName = SS_Thread.CreatedBy
WHERE SS_Thread.ThreadID IN (SELECT DISTINCT TOP 50  ThreadID FROM SS_POST WHERE createdBy=@userName)
ORDER BY SS_Thread.LastReplyDate DESC
RETURN

GO

--GRANT EXEC ON SS_UserThreads TO PUBLIC
--GO
