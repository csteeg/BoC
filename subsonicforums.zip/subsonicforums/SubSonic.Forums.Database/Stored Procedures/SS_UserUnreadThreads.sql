IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_UserUnreadThreads')
	BEGIN
		DROP  Procedure  SS_UserUnreadThreads
	END

GO

CREATE Procedure dbo.SS_UserUnreadThreads
(
	@userName nvarchar(50)
)
AS

SELECT     TOP (20) SS_Thread.ThreadID, SS_Forum.ForumID, SS_Forum.ForumName, SS_Forum.ForumUrl, SS_Thread.Subject, SS_Thread.ThreadUrl, 
                      SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, SS_Thread.CreatedBy, 
                      SS_Thread.CreatedOn, SS_UserProfile.UserName AS ThreadAuthor, SS_UserProfile.Email AS AuthorEmail, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Resolution, 0 as UserHasRead
FROM         SS_UserProfile INNER JOIN
                      SS_Thread INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_Forum ON SS_Thread.ForumID = SS_Forum.ForumID INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID ON SS_UserProfile.UserName = SS_Thread.CreatedBy
WHERE     (SS_Thread.ThreadID NOT IN
                          (SELECT     ThreadID
                            FROM          SS_User_ReadThread
                            WHERE      (UserName = @userName)))
ORDER BY SS_Thread.LastReplyDate DESC

SELECT COUNT(threadID) as notReadCount FROM SS_Thread WHERE SS_Thread.ThreadID NOT IN (SELECT threadID FROM SS_User_ReadThread WHERE userName=@userName)

RETURN

GO

--GRANT EXEC ON SS_UserUnreadThreads TO PUBLIC
--GO
