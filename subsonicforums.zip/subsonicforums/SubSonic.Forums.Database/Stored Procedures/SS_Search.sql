IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_Search')
	BEGIN
		DROP  Procedure  SS_Search
	END

GO

CREATE Procedure dbo.SS_Search
(
	@query varchar(2000)
)
AS

RETURN

GO

--GRANT EXEC ON SS_Search TO PUBLIC
--GO
