IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_SearchAllThreads')
	BEGIN
		DROP  Procedure  SS_SearchAllThreads
	END

GO

CREATE Procedure dbo.SS_SearchAllThreads
(
	@query varchar(2000)
)
AS

SELECT     SS_Post.Subject, SS_Post.FormattedPostText, FT.RANK, SS_Thread.Subject AS Topic, SS_Thread.CreatedBy AS ThreadAuthor, 
                      SS_ThreadTypeResponse.IsSearchable, SS_ThreadTypeResponse.Description AS Response, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Deleted, SS_Thread.ThreadUrl, SS_Post.PostID, SS_UserProfile.Email AS AuthorEmail, 
                      SS_ThreadTypeResponse_1.PostDesignation
					  AS AnswerType
                      
FROM         SS_ThreadTypeResponse AS SS_ThreadTypeResponse_1 INNER JOIN
                      SS_User_Answer ON SS_ThreadTypeResponse_1.ThreadTypeResponseID = SS_User_Answer.ThreadTypeResponseID RIGHT OUTER JOIN
                      FREETEXTTABLE(SS_Post, *, @query, 50) AS FT INNER JOIN
                      SS_Post ON FT.[KEY] = SS_Post.PostID INNER JOIN
                      SS_Thread ON SS_Post.ThreadID = SS_Thread.ThreadID INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_ThreadTypeResponse ON SS_ThreadType.ThreadTypeID = SS_ThreadTypeResponse.ThreadTypeID INNER JOIN
                      SS_UserProfile ON SS_Thread.CreatedBy = SS_UserProfile.UserName ON SS_User_Answer.PostID = SS_Post.PostID
WHERE     (SS_Post.Deleted = 0) AND (SS_ThreadTypeResponse.IsSearchable = 1) AND (SS_Thread.Deleted = 0)
	
	RETURN

GO

--GRANT EXEC ON SS_SearchAllThreads TO PUBLIC
--GO
