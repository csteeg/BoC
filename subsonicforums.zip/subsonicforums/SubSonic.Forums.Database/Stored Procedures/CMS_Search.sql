IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'CMS_Search')
	BEGIN
		DROP  Procedure  CMS_Search
	END

GO

CREATE Procedure dbo.CMS_Search
(
	@query varchar(2000)
)
AS

RETURN

GO

--GRANT EXEC ON CMS_Search TO PUBLIC
--GO
