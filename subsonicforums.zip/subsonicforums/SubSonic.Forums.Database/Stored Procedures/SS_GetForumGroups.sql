IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_GetForumGroups')
	BEGIN
		DROP  Procedure  SS_GetForumGroups
	END

GO

CREATE Procedure dbo.SS_GetForumGroups
AS

SELECT * FROM SS_Forum_Group WHERE deleted=0

SELECT *,
--Get the thread count
(SELECT COUNT(threadID) FROM SS_Thread 
WHERE forumID=SS_Forum.ForumID AND SS_Thread.Deleted=0)
as ThreadCount,

--get the post count
(SELECT COUNT(postID) FROM SS_Post
 INNER JOIN SS_Thread ON SS_Post.ThreadID=SS_Thread.ThreadID
 WHERE SS_Thread.ForumID=SS_Forum.ForumID  AND SS_Post.Deleted=0)
as PostCount

FROM SS_Forum WHERE Deleted=0

RETURN

GO

--GRANT EXEC ON SS_GetForumGroups TO PUBLIC
--GO
