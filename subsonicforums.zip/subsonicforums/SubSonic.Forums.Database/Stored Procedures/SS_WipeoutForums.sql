IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_WipeoutForums')
	BEGIN
		DROP  Procedure  SS_WipeoutForums
	END

GO

CREATE Procedure dbo.SS_WipeoutForums
AS

BEGIN
	DELETE FROM SS_User_ReadThread
	DELETE FROM SS_User_Answer
	DELETE FROM SS_User_WatchedThread
	DELETE FROM SS_User_ForumRole
	DELETE FROM SS_UserSearchSubscription
	DELETE FROM SS_Post
	DELETE FROM SS_Thread
	DELETE FROM SS_Forum
	DELETE FROM SS_Forum_Group
	DELETE FROM SS_UserProfile
	DELETE FROM SS_MailQueue
	
END
GO

--GRANT EXEC ON SS_WipeoutForums TO PUBLIC
--GO
