IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_UserCanHelpWith')
	BEGIN
		DROP  Procedure  SS_UserCanHelpWith
	END

GO

CREATE Procedure dbo.SS_UserCanHelpWith
(
	@userName nvarchar(50),
	@query nvarchar(500)
)
AS

SELECT     SS_Thread.ThreadUrl, SS_Thread.ThreadID, SS_ThreadType.Description AS ThreadType, SS_User_Answer.AnswerID, 
                      LEFT(SS_Post.FormattedPostText, 100) + ''...'' AS PostText, SS_Thread.Resolution, SS_Thread.Subject
FROM         FREETEXTTABLE(SS_Post, *, @query, 10) AS FT CROSS JOIN
                      SS_Thread INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID LEFT OUTER JOIN
                      SS_User_Answer INNER JOIN
                      SS_Post AS SS_Post_1 ON SS_User_Answer.PostID = SS_Post_1.PostID ON SS_Thread.ThreadID = SS_Post_1.ThreadID
WHERE     (FT.[KEY] = SS_Post.PostID) AND (SS_User_Answer.AnswerID IS NULL)


RETURN

GO

--GRANT EXEC ON SS_UserCanHelpWith TO PUBLIC
--GO
