IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_GetThread')
	BEGIN
		DROP  Procedure  SS_GetThread
	END

GO

CREATE Procedure dbo.SS_GetThread
(
	@threadID int,
	@userName nvarchar(50)=''
)
AS


--#######################################################################
--Housekeeping
--#######################################################################
	--mark thread as read by this user
	IF @userName<>''
		IF NOT EXISTS (
			SELECT userName FROM SS_User_ReadThread 
			WHERE userName=@userName 
			AND threadID=@threadID)
			
			INSERT INTO SS_User_ReadThread(userName,threadID) VALUES(@userName, @threadID)
	
	
	--debit the view count
	UPDATE SS_Thread SET Views=Views+1, LastViewDate=getdate()
	WHERE threadID=@threadID
	
--#######################################################################
--RETURN Sets
--#######################################################################

	---get the first post, this is the thread starter
	DECLARE @threadStartPostID int
	DECLARE @forumID int
	
	SELECT TOP 1  @threadStartPostID= PostID 
	FROM SS_Post WHERE threadID=@threadID
	ORDER BY CreatedOn
	
	SELECT @forumID=forumID FROM SS_Thread WHERE threadID=@threadID
	
	--the thread info
	SELECT     SS_Thread.ThreadID, SS_Thread.ThreadTypeID, SS_Thread.Subject, SS_Thread.ForumID, SS_Thread.Resolution, SS_Thread.StartPostID, 
	                      SS_Thread.ThreadUrl, SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, 
	                      SS_Thread.CreatedBy, SS_Thread.CreatedOn, SS_Thread.ModifiedBy, SS_Thread.ModifiedOn, SS_Thread.Deleted, SS_Thread.IsLocked, 
	                      SS_Thread.IsStickied, SS_ThreadType.AuthorCanDesignateAnswer, SS_ThreadType.CssClass, SS_ThreadType.Icon, SS_ThreadType.ListOrder, 
	                      SS_ThreadType.Description AS ThreadType
	FROM         SS_Thread INNER JOIN
	                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID
	WHERE     (SS_Thread.ThreadID = @threadID)
	
	--starter post
	SELECT     ThreadID, Subject, PostType, PostTypeID, PostGUID, FormattedPostText, CreatedOn, CreatedBy, PostID, Deleted, Signature, PostDesignation, 
	                      Response, AuthorEmail, Props, PostText, UserRoles
	FROM         SS_PostView
	WHERE     (PostID = @threadStartPostID)

	--next, get all the replies
	SELECT     SS_PostView.ThreadID, SS_PostView.Subject, SS_PostView.PostType, SS_PostView.PostTypeID, SS_PostView.PostGUID, 
	                      SS_PostView.FormattedPostText, SS_PostView.CreatedOn, SS_PostView.CreatedBy, SS_PostView.PostID, SS_PostView.Deleted, 
	                      SS_PostView.Signature, SS_PostView.PostDesignation, SS_PostView.Response, SS_PostView.AuthorEmail, SS_PostView.Props, 
	                      SS_PostView.PostText, SS_PostView.UserRoles
	FROM         SS_Thread INNER JOIN
	                      SS_PostView ON SS_Thread.ThreadID = SS_PostView.ThreadID AND SS_Thread.StartPostID <> SS_PostView.PostID
	WHERE     (SS_PostView.ThreadID = @threadID)
	ORDER BY SS_PostView.CreatedOn
	
	--parent forum
	SELECT     ForumID, ForumName, ForumUrl, Deleted, Description, GroupID, ListOrder, CreatedBy, CreatedOn, ModifiedBy, ModifiedOn
	FROM         SS_Forum
	WHERE     (Deleted = 0) AND (ForumID = @forumID)


	
	--answers
	SELECT     ThreadID, ThreadTypeResponseID, ThreadTypeID, Description, PostDesignation, IsSearchable, IsDefault, ResponseAuthor, Subject, PostID
	FROM         SS_ThreadResponses
	WHERE     (ThreadID = @threadID)
	
	--response options
	SELECT     SS_ThreadTypeResponse.ThreadTypeResponseID, SS_ThreadTypeResponse.ThreadTypeID, SS_ThreadTypeResponse.Description, 
	                      SS_ThreadTypeResponse.PostDesignation, SS_ThreadTypeResponse.IsSearchable, SS_ThreadTypeResponse.IsDefault, 
	                      SS_ThreadTypeResponse.AnswererPropsValue, SS_ThreadTypeResponse.ThreadAuthorPropsValue, SS_Thread.ThreadID
	FROM         SS_Thread INNER JOIN
	                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
	                      SS_ThreadTypeResponse ON SS_ThreadType.ThreadTypeID = SS_ThreadTypeResponse.ThreadTypeID
	WHERE     (SS_Thread.ThreadID = @threadID)
	
	--see if this thread is watched
	DECLARE @watched bit
	IF EXISTS(SELECT threadID FROM SS_User_WatchedThread WHERE userName=@userName and threadID=@threadID)
		SELECT @watched=1
	ELSE
		SELECT @watched=0
		
	SELECT @watched as UserIsWatching
	RETURN
GO

--GRANT EXEC ON SS_GetThread TO PUBLIC
--GO
