IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'SS_UserWatchedThreads')
	BEGIN
		DROP  Procedure  SS_UserWatchedThreads
	END

GO

CREATE Procedure dbo.SS_UserWatchedThreads
(
	@userName nvarchar(50)
)
AS

SELECT     TOP (50) SS_Thread.ThreadID, SS_Forum.ForumID, SS_Forum.ForumName, SS_Forum.ForumUrl, SS_Thread.Subject, SS_Thread.ThreadUrl, 
                      SS_Thread.Views, SS_Thread.TotalReplies, SS_Thread.LastViewDate, SS_Thread.LastReplyAuthor, SS_Thread.LastReplyDate, SS_Thread.CreatedBy, 
                      SS_Thread.CreatedOn, SS_UserProfile.UserName AS ThreadAuthor, SS_UserProfile.Email AS AuthorEmail, SS_ThreadType.Description AS ThreadType, 
                      SS_Thread.Resolution, 'true' as UserHasRead
FROM         SS_UserProfile INNER JOIN
                      SS_Thread INNER JOIN
                      SS_ThreadType ON SS_Thread.ThreadTypeID = SS_ThreadType.ThreadTypeID INNER JOIN
                      SS_Forum ON SS_Thread.ForumID = SS_Forum.ForumID INNER JOIN
                      SS_Post ON SS_Thread.StartPostID = SS_Post.PostID ON SS_UserProfile.UserName = SS_Thread.CreatedBy
WHERE SS_Thread.ThreadID IN (SELECT threadID FROM SS_User_WatchedThread WHERE userName=@userName)
ORDER BY SS_Thread.LastReplyDate DESC
RETURN

GO

--GRANT EXEC ON SS_UserWatchedThreads TO PUBLIC
--GO
