IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'CMS_GetPageHierarchyByParent')
	BEGIN
		DROP  Procedure  CMS_GetPageHierarchyByParent
	END

GO

CREATE Procedure dbo.CMS_GetPageHierarchyByParent
(
	@parentID int
)
AS

WITH PageCTE (parentID, pageID, title, theLevel,sortKey)
AS
(
-- Anchor member definition. These records are your "top level", or "anchor"
SELECT e.parentID, e.pageID, e.title,
0 AS theLevel,
	--this is my sortkey- using VARBINARY
	CAST (e.pageID AS VARBINARY(900))
FROM CMS_Page AS e
WHERE pageID= @parentID
--UNION the top level to the "child level"
	UNION ALL
-- Recursive member definition
--ths is the same query as above, but we're going to join it now to the
	--CTE itself
	SELECT e.parentID, e.pageID, e.title, theLevel + 1,
--increment the sortkey
CAST (d.sortKey + CAST (e.pageID AS BINARY(4)) AS VARBINARY(900))
FROM CMS_Page AS e
INNER JOIN PageCTE AS d
ON e.parentID = d.pageID
)
-- Run a select from the CTE, and sort it by the sortKey
SELECT * FROM PageCTE
order by sortKey

 
RETURN
GO

--GRANT EXEC ON CMS_GetPageHierarchyByParent TO PUBLIC
--GO
