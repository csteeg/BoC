using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    public partial class SPs{
        
        /// <summary>
        /// Creates an object wrapper for the SS_Search Procedure
        /// </summary>
        public static StoredProcedure Search(string query)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_Search" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@query", query,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_SearchAnsweredThreads Procedure
        /// </summary>
        public static StoredProcedure SearchAnsweredThreads(string query)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_SearchAnsweredThreads" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@query", query,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_SearchAllThreads Procedure
        /// </summary>
        public static StoredProcedure SearchAllThreads(string query)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_SearchAllThreads" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@query", query,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_SearchUnAnsweredThreads Procedure
        /// </summary>
        public static StoredProcedure SearchUnAnsweredThreads(string query)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_SearchUnAnsweredThreads" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@query", query,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_UserCanHelpWith Procedure
        /// </summary>
        public static StoredProcedure UserCanHelpWith(string userName, string query)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_UserCanHelpWith" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@userName", userName,DbType.String);
        	    
            sp.Command.AddParameter("@query", query,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_WipeoutForums Procedure
        /// </summary>
        public static StoredProcedure WipeoutForums()
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_WipeoutForums" , DataService.GetInstance("Forums"));
        	
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_UserUnreadThreads Procedure
        /// </summary>
        public static StoredProcedure UserUnreadThreads(string userName)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_UserUnreadThreads" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@userName", userName,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the CMS_GetPageHierarchyByParent Procedure
        /// </summary>
        public static StoredProcedure CmsGetPageHierarchyByParent(int? parentID)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("CMS_GetPageHierarchyByParent" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@parentID", parentID,DbType.Int32);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the CMS_GetPageHierarchy Procedure
        /// </summary>
        public static StoredProcedure CmsGetPageHierarchy()
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("CMS_GetPageHierarchy" , DataService.GetInstance("Forums"));
        	
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_NewestThreads Procedure
        /// </summary>
        public static StoredProcedure NewestThreads(string userName)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_NewestThreads" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@userName", userName,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_UserThreads Procedure
        /// </summary>
        public static StoredProcedure UserThreads(string userName)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_UserThreads" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@userName", userName,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_GetThread Procedure
        /// </summary>
        public static StoredProcedure GetThread(int? threadID, string userName)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_GetThread" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@threadID", threadID,DbType.Int32);
        	    
            sp.Command.AddParameter("@userName", userName,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_UserWatchedThreads Procedure
        /// </summary>
        public static StoredProcedure UserWatchedThreads(string userName)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_UserWatchedThreads" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@userName", userName,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the CMS_Search Procedure
        /// </summary>
        public static StoredProcedure CmsSearch(string query)
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("CMS_Search" , DataService.GetInstance("Forums"));
        	
            sp.Command.AddParameter("@query", query,DbType.String);
        	    
            return sp;
        }

        
        /// <summary>
        /// Creates an object wrapper for the SS_GetForumGroups Procedure
        /// </summary>
        public static StoredProcedure GetForumGroups()
        {
            SubSonic.StoredProcedure sp = new SubSonic.StoredProcedure("SS_GetForumGroups" , DataService.GetInstance("Forums"));
        	
            return sp;
        }

        
    }

    
}

