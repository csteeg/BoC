using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ThreadSummary class.
    /// </summary>
    [Serializable]
    public partial class ThreadSummaryCollection : ReadOnlyList<ThreadSummary, ThreadSummaryCollection>
    {        
        public ThreadSummaryCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the SS_ThreadSummary view.
    /// </summary>
    [Serializable]
    public partial class ThreadSummary : ReadOnlyRecord<ThreadSummary> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("SS_ThreadSummary", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarThreadSubject = new TableSchema.TableColumn(schema);
                colvarThreadSubject.ColumnName = "ThreadSubject";
                colvarThreadSubject.DataType = DbType.String;
                colvarThreadSubject.MaxLength = 250;
                colvarThreadSubject.AutoIncrement = false;
                colvarThreadSubject.IsNullable = false;
                colvarThreadSubject.IsPrimaryKey = false;
                colvarThreadSubject.IsForeignKey = false;
                colvarThreadSubject.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadSubject);
                
                TableSchema.TableColumn colvarQuestion = new TableSchema.TableColumn(schema);
                colvarQuestion.ColumnName = "Question";
                colvarQuestion.DataType = DbType.String;
                colvarQuestion.MaxLength = -1;
                colvarQuestion.AutoIncrement = false;
                colvarQuestion.IsNullable = true;
                colvarQuestion.IsPrimaryKey = false;
                colvarQuestion.IsForeignKey = false;
                colvarQuestion.IsReadOnly = false;
                
                schema.Columns.Add(colvarQuestion);
                
                TableSchema.TableColumn colvarReply = new TableSchema.TableColumn(schema);
                colvarReply.ColumnName = "Reply";
                colvarReply.DataType = DbType.String;
                colvarReply.MaxLength = -1;
                colvarReply.AutoIncrement = false;
                colvarReply.IsNullable = true;
                colvarReply.IsPrimaryKey = false;
                colvarReply.IsForeignKey = false;
                colvarReply.IsReadOnly = false;
                
                schema.Columns.Add(colvarReply);
                
                TableSchema.TableColumn colvarThreadUrl = new TableSchema.TableColumn(schema);
                colvarThreadUrl.ColumnName = "ThreadUrl";
                colvarThreadUrl.DataType = DbType.String;
                colvarThreadUrl.MaxLength = 50;
                colvarThreadUrl.AutoIncrement = false;
                colvarThreadUrl.IsNullable = false;
                colvarThreadUrl.IsPrimaryKey = false;
                colvarThreadUrl.IsForeignKey = false;
                colvarThreadUrl.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadUrl);
                
                TableSchema.TableColumn colvarPostID = new TableSchema.TableColumn(schema);
                colvarPostID.ColumnName = "PostID";
                colvarPostID.DataType = DbType.Int32;
                colvarPostID.MaxLength = 0;
                colvarPostID.AutoIncrement = false;
                colvarPostID.IsNullable = false;
                colvarPostID.IsPrimaryKey = false;
                colvarPostID.IsForeignKey = false;
                colvarPostID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostID);
                
                TableSchema.TableColumn colvarThreadAuthor = new TableSchema.TableColumn(schema);
                colvarThreadAuthor.ColumnName = "ThreadAuthor";
                colvarThreadAuthor.DataType = DbType.String;
                colvarThreadAuthor.MaxLength = 50;
                colvarThreadAuthor.AutoIncrement = false;
                colvarThreadAuthor.IsNullable = true;
                colvarThreadAuthor.IsPrimaryKey = false;
                colvarThreadAuthor.IsForeignKey = false;
                colvarThreadAuthor.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadAuthor);
                
                TableSchema.TableColumn colvarReplyAuthor = new TableSchema.TableColumn(schema);
                colvarReplyAuthor.ColumnName = "ReplyAuthor";
                colvarReplyAuthor.DataType = DbType.String;
                colvarReplyAuthor.MaxLength = 50;
                colvarReplyAuthor.AutoIncrement = false;
                colvarReplyAuthor.IsNullable = true;
                colvarReplyAuthor.IsPrimaryKey = false;
                colvarReplyAuthor.IsForeignKey = false;
                colvarReplyAuthor.IsReadOnly = false;
                
                schema.Columns.Add(colvarReplyAuthor);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("SS_ThreadSummary",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ThreadSummary()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ThreadSummary(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ThreadSummary(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ThreadSummary(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("ThreadSubject")]
        public string ThreadSubject 
	    {
		    get
		    {
			    return GetColumnValue<string>("ThreadSubject");
		    }

            set 
		    {
			    SetColumnValue("ThreadSubject", value);
            }

        }

	      
        [XmlAttribute("Question")]
        public string Question 
	    {
		    get
		    {
			    return GetColumnValue<string>("Question");
		    }

            set 
		    {
			    SetColumnValue("Question", value);
            }

        }

	      
        [XmlAttribute("Reply")]
        public string Reply 
	    {
		    get
		    {
			    return GetColumnValue<string>("Reply");
		    }

            set 
		    {
			    SetColumnValue("Reply", value);
            }

        }

	      
        [XmlAttribute("ThreadUrl")]
        public string ThreadUrl 
	    {
		    get
		    {
			    return GetColumnValue<string>("ThreadUrl");
		    }

            set 
		    {
			    SetColumnValue("ThreadUrl", value);
            }

        }

	      
        [XmlAttribute("PostID")]
        public int PostID 
	    {
		    get
		    {
			    return GetColumnValue<int>("PostID");
		    }

            set 
		    {
			    SetColumnValue("PostID", value);
            }

        }

	      
        [XmlAttribute("ThreadAuthor")]
        public string ThreadAuthor 
	    {
		    get
		    {
			    return GetColumnValue<string>("ThreadAuthor");
		    }

            set 
		    {
			    SetColumnValue("ThreadAuthor", value);
            }

        }

	      
        [XmlAttribute("ReplyAuthor")]
        public string ReplyAuthor 
	    {
		    get
		    {
			    return GetColumnValue<string>("ReplyAuthor");
		    }

            set 
		    {
			    SetColumnValue("ReplyAuthor", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string ThreadSubject = @"ThreadSubject";
            
            public static string Question = @"Question";
            
            public static string Reply = @"Reply";
            
            public static string ThreadUrl = @"ThreadUrl";
            
            public static string PostID = @"PostID";
            
            public static string ThreadAuthor = @"ThreadAuthor";
            
            public static string ReplyAuthor = @"ReplyAuthor";
            
	    }

	    #endregion
    }

}

