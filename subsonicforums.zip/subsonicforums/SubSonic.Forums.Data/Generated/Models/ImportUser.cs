using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ImportUser class.
    /// </summary>
    [Serializable]
    public partial class ImportUserCollection : ReadOnlyList<ImportUser, ImportUserCollection>
    {        
        public ImportUserCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the IMPORT_Users view.
    /// </summary>
    [Serializable]
    public partial class ImportUser : ReadOnlyRecord<ImportUser> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("IMPORT_Users", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
                colvarUserName.ColumnName = "UserName";
                colvarUserName.DataType = DbType.String;
                colvarUserName.MaxLength = 256;
                colvarUserName.AutoIncrement = false;
                colvarUserName.IsNullable = false;
                colvarUserName.IsPrimaryKey = false;
                colvarUserName.IsForeignKey = false;
                colvarUserName.IsReadOnly = false;
                
                schema.Columns.Add(colvarUserName);
                
                TableSchema.TableColumn colvarEmail = new TableSchema.TableColumn(schema);
                colvarEmail.ColumnName = "Email";
                colvarEmail.DataType = DbType.String;
                colvarEmail.MaxLength = 256;
                colvarEmail.AutoIncrement = false;
                colvarEmail.IsNullable = false;
                colvarEmail.IsPrimaryKey = false;
                colvarEmail.IsForeignKey = false;
                colvarEmail.IsReadOnly = false;
                
                schema.Columns.Add(colvarEmail);
                
                TableSchema.TableColumn colvarMemberSince = new TableSchema.TableColumn(schema);
                colvarMemberSince.ColumnName = "MemberSince";
                colvarMemberSince.DataType = DbType.DateTime;
                colvarMemberSince.MaxLength = 0;
                colvarMemberSince.AutoIncrement = false;
                colvarMemberSince.IsNullable = false;
                colvarMemberSince.IsPrimaryKey = false;
                colvarMemberSince.IsForeignKey = false;
                colvarMemberSince.IsReadOnly = false;
                
                schema.Columns.Add(colvarMemberSince);
                
                TableSchema.TableColumn colvarIsApproved = new TableSchema.TableColumn(schema);
                colvarIsApproved.ColumnName = "IsApproved";
                colvarIsApproved.DataType = DbType.Boolean;
                colvarIsApproved.MaxLength = 0;
                colvarIsApproved.AutoIncrement = false;
                colvarIsApproved.IsNullable = true;
                colvarIsApproved.IsPrimaryKey = false;
                colvarIsApproved.IsForeignKey = false;
                colvarIsApproved.IsReadOnly = false;
                
                schema.Columns.Add(colvarIsApproved);
                
                TableSchema.TableColumn colvarTotalPosts = new TableSchema.TableColumn(schema);
                colvarTotalPosts.ColumnName = "TotalPosts";
                colvarTotalPosts.DataType = DbType.Int32;
                colvarTotalPosts.MaxLength = 0;
                colvarTotalPosts.AutoIncrement = false;
                colvarTotalPosts.IsNullable = false;
                colvarTotalPosts.IsPrimaryKey = false;
                colvarTotalPosts.IsForeignKey = false;
                colvarTotalPosts.IsReadOnly = false;
                
                schema.Columns.Add(colvarTotalPosts);
                
                TableSchema.TableColumn colvarTimeZone = new TableSchema.TableColumn(schema);
                colvarTimeZone.ColumnName = "TimeZone";
                colvarTimeZone.DataType = DbType.Double;
                colvarTimeZone.MaxLength = 0;
                colvarTimeZone.AutoIncrement = false;
                colvarTimeZone.IsNullable = false;
                colvarTimeZone.IsPrimaryKey = false;
                colvarTimeZone.IsForeignKey = false;
                colvarTimeZone.IsReadOnly = false;
                
                schema.Columns.Add(colvarTimeZone);
                
                TableSchema.TableColumn colvarIsModerated = new TableSchema.TableColumn(schema);
                colvarIsModerated.ColumnName = "IsModerated";
                colvarIsModerated.DataType = DbType.Int32;
                colvarIsModerated.MaxLength = 0;
                colvarIsModerated.AutoIncrement = false;
                colvarIsModerated.IsNullable = false;
                colvarIsModerated.IsPrimaryKey = false;
                colvarIsModerated.IsForeignKey = false;
                colvarIsModerated.IsReadOnly = false;
                
                schema.Columns.Add(colvarIsModerated);
                
                TableSchema.TableColumn colvarAllowEmailContact = new TableSchema.TableColumn(schema);
                colvarAllowEmailContact.ColumnName = "AllowEmailContact";
                colvarAllowEmailContact.DataType = DbType.Int16;
                colvarAllowEmailContact.MaxLength = 0;
                colvarAllowEmailContact.AutoIncrement = false;
                colvarAllowEmailContact.IsNullable = false;
                colvarAllowEmailContact.IsPrimaryKey = false;
                colvarAllowEmailContact.IsForeignKey = false;
                colvarAllowEmailContact.IsReadOnly = false;
                
                schema.Columns.Add(colvarAllowEmailContact);
                
                TableSchema.TableColumn colvarHTMLEmail = new TableSchema.TableColumn(schema);
                colvarHTMLEmail.ColumnName = "HTMLEmail";
                colvarHTMLEmail.DataType = DbType.Int16;
                colvarHTMLEmail.MaxLength = 0;
                colvarHTMLEmail.AutoIncrement = false;
                colvarHTMLEmail.IsNullable = false;
                colvarHTMLEmail.IsPrimaryKey = false;
                colvarHTMLEmail.IsForeignKey = false;
                colvarHTMLEmail.IsReadOnly = false;
                
                schema.Columns.Add(colvarHTMLEmail);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("IMPORT_Users",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ImportUser()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ImportUser(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ImportUser(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ImportUser(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("UserName")]
        public string UserName 
	    {
		    get
		    {
			    return GetColumnValue<string>("UserName");
		    }

            set 
		    {
			    SetColumnValue("UserName", value);
            }

        }

	      
        [XmlAttribute("Email")]
        public string Email 
	    {
		    get
		    {
			    return GetColumnValue<string>("Email");
		    }

            set 
		    {
			    SetColumnValue("Email", value);
            }

        }

	      
        [XmlAttribute("MemberSince")]
        public DateTime MemberSince 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("MemberSince");
		    }

            set 
		    {
			    SetColumnValue("MemberSince", value);
            }

        }

	      
        [XmlAttribute("IsApproved")]
        public bool? IsApproved 
	    {
		    get
		    {
			    return GetColumnValue<bool?>("IsApproved");
		    }

            set 
		    {
			    SetColumnValue("IsApproved", value);
            }

        }

	      
        [XmlAttribute("TotalPosts")]
        public int TotalPosts 
	    {
		    get
		    {
			    return GetColumnValue<int>("TotalPosts");
		    }

            set 
		    {
			    SetColumnValue("TotalPosts", value);
            }

        }

	      
        [XmlAttribute("TimeZone")]
        public double TimeZone 
	    {
		    get
		    {
			    return GetColumnValue<double>("TimeZone");
		    }

            set 
		    {
			    SetColumnValue("TimeZone", value);
            }

        }

	      
        [XmlAttribute("IsModerated")]
        public int IsModerated 
	    {
		    get
		    {
			    return GetColumnValue<int>("IsModerated");
		    }

            set 
		    {
			    SetColumnValue("IsModerated", value);
            }

        }

	      
        [XmlAttribute("AllowEmailContact")]
        public short AllowEmailContact 
	    {
		    get
		    {
			    return GetColumnValue<short>("AllowEmailContact");
		    }

            set 
		    {
			    SetColumnValue("AllowEmailContact", value);
            }

        }

	      
        [XmlAttribute("HTMLEmail")]
        public short HTMLEmail 
	    {
		    get
		    {
			    return GetColumnValue<short>("HTMLEmail");
		    }

            set 
		    {
			    SetColumnValue("HTMLEmail", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string UserName = @"UserName";
            
            public static string Email = @"Email";
            
            public static string MemberSince = @"MemberSince";
            
            public static string IsApproved = @"IsApproved";
            
            public static string TotalPosts = @"TotalPosts";
            
            public static string TimeZone = @"TimeZone";
            
            public static string IsModerated = @"IsModerated";
            
            public static string AllowEmailContact = @"AllowEmailContact";
            
            public static string HTMLEmail = @"HTMLEmail";
            
	    }

	    #endregion
    }

}

