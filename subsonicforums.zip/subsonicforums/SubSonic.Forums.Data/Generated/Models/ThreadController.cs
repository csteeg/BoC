using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_Thread
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class ThreadController
    {
        // Preload our schema..
        Thread thisSchemaLoad = new Thread();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public ThreadCollection FetchAll()
        {
            ThreadCollection coll = new ThreadCollection();
            Query qry = new Query(Thread.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public ThreadCollection FetchByID(object ThreadID)
        {
            ThreadCollection coll = new ThreadCollection().Where("ThreadID", ThreadID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public ThreadCollection FetchByQuery(Query qry)
        {
            ThreadCollection coll = new ThreadCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object ThreadID)
        {
            return (Thread.Delete(ThreadID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object ThreadID)
        {
            return (Thread.Destroy(ThreadID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(int ThreadTypeID,string Subject,int ForumID,string Resolution,int StartPostID,string ThreadUrl,int Views,int TotalReplies,DateTime? LastViewDate,string LastReplyAuthor,DateTime? LastReplyDate,string CreatedBy,DateTime CreatedOn,string ModifiedBy,DateTime ModifiedOn,bool Deleted,bool IsLocked,bool IsStickied)
	    {
		    Thread item = new Thread();
		    
            item.ThreadTypeID = ThreadTypeID;
            
            item.Subject = Subject;
            
            item.ForumID = ForumID;
            
            item.Resolution = Resolution;
            
            item.StartPostID = StartPostID;
            
            item.ThreadUrl = ThreadUrl;
            
            item.Views = Views;
            
            item.TotalReplies = TotalReplies;
            
            item.LastViewDate = LastViewDate;
            
            item.LastReplyAuthor = LastReplyAuthor;
            
            item.LastReplyDate = LastReplyDate;
            
            item.CreatedBy = CreatedBy;
            
            item.CreatedOn = CreatedOn;
            
            item.ModifiedBy = ModifiedBy;
            
            item.ModifiedOn = ModifiedOn;
            
            item.Deleted = Deleted;
            
            item.IsLocked = IsLocked;
            
            item.IsStickied = IsStickied;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int ThreadID,int ThreadTypeID,string Subject,int ForumID,string Resolution,int StartPostID,string ThreadUrl,int Views,int TotalReplies,DateTime? LastViewDate,string LastReplyAuthor,DateTime? LastReplyDate,string CreatedBy,DateTime CreatedOn,string ModifiedBy,DateTime ModifiedOn,bool Deleted,bool IsLocked,bool IsStickied)
	    {
		    Thread item = new Thread();
		    
				item.ThreadID = ThreadID;
				
				item.ThreadTypeID = ThreadTypeID;
				
				item.Subject = Subject;
				
				item.ForumID = ForumID;
				
				item.Resolution = Resolution;
				
				item.StartPostID = StartPostID;
				
				item.ThreadUrl = ThreadUrl;
				
				item.Views = Views;
				
				item.TotalReplies = TotalReplies;
				
				item.LastViewDate = LastViewDate;
				
				item.LastReplyAuthor = LastReplyAuthor;
				
				item.LastReplyDate = LastReplyDate;
				
				item.CreatedBy = CreatedBy;
				
				item.CreatedOn = CreatedOn;
				
				item.ModifiedBy = ModifiedBy;
				
				item.ModifiedOn = ModifiedOn;
				
				item.Deleted = Deleted;
				
				item.IsLocked = IsLocked;
				
				item.IsStickied = IsStickied;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

