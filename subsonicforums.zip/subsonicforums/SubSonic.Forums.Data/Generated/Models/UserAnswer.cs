using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the UserAnswer class.
	/// </summary>
	[Serializable]
	public partial class UserAnswerCollection : ActiveList<UserAnswer, UserAnswerCollection> 
	{	   
		public UserAnswerCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_User_Answer table.
	/// </summary>
	[Serializable]
	public partial class UserAnswer : ActiveRecord<UserAnswer>
	{
		#region .ctors and Default Settings
		
		public UserAnswer()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public UserAnswer(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public UserAnswer(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public UserAnswer(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_User_Answer", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarAnswerID = new TableSchema.TableColumn(schema);
				colvarAnswerID.ColumnName = "AnswerID";
				colvarAnswerID.DataType = DbType.Int32;
				colvarAnswerID.MaxLength = 0;
				colvarAnswerID.AutoIncrement = true;
				colvarAnswerID.IsNullable = false;
				colvarAnswerID.IsPrimaryKey = true;
				colvarAnswerID.IsForeignKey = false;
				colvarAnswerID.IsReadOnly = false;
				colvarAnswerID.DefaultSetting = @"";
				colvarAnswerID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarAnswerID);
				
				TableSchema.TableColumn colvarPostID = new TableSchema.TableColumn(schema);
				colvarPostID.ColumnName = "PostID";
				colvarPostID.DataType = DbType.Int32;
				colvarPostID.MaxLength = 0;
				colvarPostID.AutoIncrement = false;
				colvarPostID.IsNullable = false;
				colvarPostID.IsPrimaryKey = false;
				colvarPostID.IsForeignKey = true;
				colvarPostID.IsReadOnly = false;
				colvarPostID.DefaultSetting = @"";
				
					colvarPostID.ForeignKeyTableName = "SS_Post";
				schema.Columns.Add(colvarPostID);
				
				TableSchema.TableColumn colvarThreadTypeResponseID = new TableSchema.TableColumn(schema);
				colvarThreadTypeResponseID.ColumnName = "ThreadTypeResponseID";
				colvarThreadTypeResponseID.DataType = DbType.Int32;
				colvarThreadTypeResponseID.MaxLength = 0;
				colvarThreadTypeResponseID.AutoIncrement = false;
				colvarThreadTypeResponseID.IsNullable = false;
				colvarThreadTypeResponseID.IsPrimaryKey = false;
				colvarThreadTypeResponseID.IsForeignKey = true;
				colvarThreadTypeResponseID.IsReadOnly = false;
				colvarThreadTypeResponseID.DefaultSetting = @"";
				
					colvarThreadTypeResponseID.ForeignKeyTableName = "SS_ThreadTypeResponse";
				schema.Columns.Add(colvarThreadTypeResponseID);
				
				TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
				colvarCreatedOn.ColumnName = "CreatedOn";
				colvarCreatedOn.DataType = DbType.DateTime;
				colvarCreatedOn.MaxLength = 0;
				colvarCreatedOn.AutoIncrement = false;
				colvarCreatedOn.IsNullable = false;
				colvarCreatedOn.IsPrimaryKey = false;
				colvarCreatedOn.IsForeignKey = false;
				colvarCreatedOn.IsReadOnly = false;
				
						colvarCreatedOn.DefaultSetting = @"(getdate())";
				colvarCreatedOn.ForeignKeyTableName = "";
				schema.Columns.Add(colvarCreatedOn);
				
				TableSchema.TableColumn colvarCreatedBy = new TableSchema.TableColumn(schema);
				colvarCreatedBy.ColumnName = "CreatedBy";
				colvarCreatedBy.DataType = DbType.String;
				colvarCreatedBy.MaxLength = 50;
				colvarCreatedBy.AutoIncrement = false;
				colvarCreatedBy.IsNullable = false;
				colvarCreatedBy.IsPrimaryKey = false;
				colvarCreatedBy.IsForeignKey = true;
				colvarCreatedBy.IsReadOnly = false;
				colvarCreatedBy.DefaultSetting = @"";
				
					colvarCreatedBy.ForeignKeyTableName = "SS_UserProfile";
				schema.Columns.Add(colvarCreatedBy);
				
				TableSchema.TableColumn colvarProps = new TableSchema.TableColumn(schema);
				colvarProps.ColumnName = "Props";
				colvarProps.DataType = DbType.Int32;
				colvarProps.MaxLength = 0;
				colvarProps.AutoIncrement = false;
				colvarProps.IsNullable = false;
				colvarProps.IsPrimaryKey = false;
				colvarProps.IsForeignKey = false;
				colvarProps.IsReadOnly = false;
				
						colvarProps.DefaultSetting = @"((0))";
				colvarProps.ForeignKeyTableName = "";
				schema.Columns.Add(colvarProps);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_User_Answer",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("AnswerID")]
		public int AnswerID 
		{
			get { return GetColumnValue<int>("AnswerID"); }

			set { SetColumnValue("AnswerID", value); }

		}

		  
		[XmlAttribute("PostID")]
		public int PostID 
		{
			get { return GetColumnValue<int>("PostID"); }

			set { SetColumnValue("PostID", value); }

		}

		  
		[XmlAttribute("ThreadTypeResponseID")]
		public int ThreadTypeResponseID 
		{
			get { return GetColumnValue<int>("ThreadTypeResponseID"); }

			set { SetColumnValue("ThreadTypeResponseID", value); }

		}

		  
		[XmlAttribute("CreatedOn")]
		public DateTime CreatedOn 
		{
			get { return GetColumnValue<DateTime>("CreatedOn"); }

			set { SetColumnValue("CreatedOn", value); }

		}

		  
		[XmlAttribute("CreatedBy")]
		public string CreatedBy 
		{
			get { return GetColumnValue<string>("CreatedBy"); }

			set { SetColumnValue("CreatedBy", value); }

		}

		  
		[XmlAttribute("Props")]
		public int Props 
		{
			get { return GetColumnValue<int>("Props"); }

			set { SetColumnValue("Props", value); }

		}

		
		#endregion
		
		
			
		
		#region ForeignKey Properties
		
		/// <summary>
		/// Returns a Post ActiveRecord object related to this UserAnswer
		/// 
		/// </summary>
		public SubSonic.Forums.Post Post
		{
			get { return SubSonic.Forums.Post.FetchByID(this.PostID); }

			set { SetColumnValue("PostID", value.PostID); }

		}

		
		
		/// <summary>
		/// Returns a ThreadTypeResponse ActiveRecord object related to this UserAnswer
		/// 
		/// </summary>
		public SubSonic.Forums.ThreadTypeResponse ThreadTypeResponse
		{
			get { return SubSonic.Forums.ThreadTypeResponse.FetchByID(this.ThreadTypeResponseID); }

			set { SetColumnValue("ThreadTypeResponseID", value.ThreadTypeResponseID); }

		}

		
		
		/// <summary>
		/// Returns a UserProfile ActiveRecord object related to this UserAnswer
		/// 
		/// </summary>
		public SubSonic.Forums.UserProfile UserProfile
		{
			get { return SubSonic.Forums.UserProfile.FetchByID(this.CreatedBy); }

			set { SetColumnValue("CreatedBy", value.UserName); }

		}

		
		
		#endregion
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(int varPostID,int varThreadTypeResponseID,DateTime varCreatedOn,string varCreatedBy,int varProps)
		{
			UserAnswer item = new UserAnswer();
			
			item.PostID = varPostID;
			
			item.ThreadTypeResponseID = varThreadTypeResponseID;
			
			item.CreatedOn = varCreatedOn;
			
			item.CreatedBy = varCreatedBy;
			
			item.Props = varProps;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varAnswerID,int varPostID,int varThreadTypeResponseID,DateTime varCreatedOn,string varCreatedBy,int varProps)
		{
			UserAnswer item = new UserAnswer();
			
				item.AnswerID = varAnswerID;
				
				item.PostID = varPostID;
				
				item.ThreadTypeResponseID = varThreadTypeResponseID;
				
				item.CreatedOn = varCreatedOn;
				
				item.CreatedBy = varCreatedBy;
				
				item.Props = varProps;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string AnswerID = @"AnswerID";
			 public static string PostID = @"PostID";
			 public static string ThreadTypeResponseID = @"ThreadTypeResponseID";
			 public static string CreatedOn = @"CreatedOn";
			 public static string CreatedBy = @"CreatedBy";
			 public static string Props = @"Props";
						
		}

		#endregion
	}

}

