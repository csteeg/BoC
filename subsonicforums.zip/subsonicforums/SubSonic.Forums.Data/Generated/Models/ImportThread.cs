using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ImportThread class.
    /// </summary>
    [Serializable]
    public partial class ImportThreadCollection : ReadOnlyList<ImportThread, ImportThreadCollection>
    {        
        public ImportThreadCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the IMPORT_Threads view.
    /// </summary>
    [Serializable]
    public partial class ImportThread : ReadOnlyRecord<ImportThread> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("IMPORT_Threads", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarForumID = new TableSchema.TableColumn(schema);
                colvarForumID.ColumnName = "ForumID";
                colvarForumID.DataType = DbType.Int32;
                colvarForumID.MaxLength = 0;
                colvarForumID.AutoIncrement = false;
                colvarForumID.IsNullable = false;
                colvarForumID.IsPrimaryKey = false;
                colvarForumID.IsForeignKey = false;
                colvarForumID.IsReadOnly = false;
                
                schema.Columns.Add(colvarForumID);
                
                TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
                colvarThreadID.ColumnName = "ThreadID";
                colvarThreadID.DataType = DbType.Int32;
                colvarThreadID.MaxLength = 0;
                colvarThreadID.AutoIncrement = false;
                colvarThreadID.IsNullable = false;
                colvarThreadID.IsPrimaryKey = false;
                colvarThreadID.IsForeignKey = false;
                colvarThreadID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadID);
                
                TableSchema.TableColumn colvarCreatedBy = new TableSchema.TableColumn(schema);
                colvarCreatedBy.ColumnName = "CreatedBy";
                colvarCreatedBy.DataType = DbType.String;
                colvarCreatedBy.MaxLength = 64;
                colvarCreatedBy.AutoIncrement = false;
                colvarCreatedBy.IsNullable = true;
                colvarCreatedBy.IsPrimaryKey = false;
                colvarCreatedBy.IsForeignKey = false;
                colvarCreatedBy.IsReadOnly = false;
                
                schema.Columns.Add(colvarCreatedBy);
                
                TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
                colvarCreatedOn.ColumnName = "CreatedOn";
                colvarCreatedOn.DataType = DbType.DateTime;
                colvarCreatedOn.MaxLength = 0;
                colvarCreatedOn.AutoIncrement = false;
                colvarCreatedOn.IsNullable = false;
                colvarCreatedOn.IsPrimaryKey = false;
                colvarCreatedOn.IsForeignKey = false;
                colvarCreatedOn.IsReadOnly = false;
                
                schema.Columns.Add(colvarCreatedOn);
                
                TableSchema.TableColumn colvarSubject = new TableSchema.TableColumn(schema);
                colvarSubject.ColumnName = "Subject";
                colvarSubject.DataType = DbType.String;
                colvarSubject.MaxLength = 256;
                colvarSubject.AutoIncrement = false;
                colvarSubject.IsNullable = true;
                colvarSubject.IsPrimaryKey = false;
                colvarSubject.IsForeignKey = false;
                colvarSubject.IsReadOnly = false;
                
                schema.Columns.Add(colvarSubject);
                
                TableSchema.TableColumn colvarModifiedBy = new TableSchema.TableColumn(schema);
                colvarModifiedBy.ColumnName = "ModifiedBy";
                colvarModifiedBy.DataType = DbType.String;
                colvarModifiedBy.MaxLength = 64;
                colvarModifiedBy.AutoIncrement = false;
                colvarModifiedBy.IsNullable = true;
                colvarModifiedBy.IsPrimaryKey = false;
                colvarModifiedBy.IsForeignKey = false;
                colvarModifiedBy.IsReadOnly = false;
                
                schema.Columns.Add(colvarModifiedBy);
                
                TableSchema.TableColumn colvarLastViewDate = new TableSchema.TableColumn(schema);
                colvarLastViewDate.ColumnName = "LastViewDate";
                colvarLastViewDate.DataType = DbType.DateTime;
                colvarLastViewDate.MaxLength = 0;
                colvarLastViewDate.AutoIncrement = false;
                colvarLastViewDate.IsNullable = false;
                colvarLastViewDate.IsPrimaryKey = false;
                colvarLastViewDate.IsForeignKey = false;
                colvarLastViewDate.IsReadOnly = false;
                
                schema.Columns.Add(colvarLastViewDate);
                
                TableSchema.TableColumn colvarLastReplyAuthor = new TableSchema.TableColumn(schema);
                colvarLastReplyAuthor.ColumnName = "LastReplyAuthor";
                colvarLastReplyAuthor.DataType = DbType.String;
                colvarLastReplyAuthor.MaxLength = 64;
                colvarLastReplyAuthor.AutoIncrement = false;
                colvarLastReplyAuthor.IsNullable = true;
                colvarLastReplyAuthor.IsPrimaryKey = false;
                colvarLastReplyAuthor.IsForeignKey = false;
                colvarLastReplyAuthor.IsReadOnly = false;
                
                schema.Columns.Add(colvarLastReplyAuthor);
                
                TableSchema.TableColumn colvarLastReplyDate = new TableSchema.TableColumn(schema);
                colvarLastReplyDate.ColumnName = "LastReplyDate";
                colvarLastReplyDate.DataType = DbType.DateTime;
                colvarLastReplyDate.MaxLength = 0;
                colvarLastReplyDate.AutoIncrement = false;
                colvarLastReplyDate.IsNullable = false;
                colvarLastReplyDate.IsPrimaryKey = false;
                colvarLastReplyDate.IsForeignKey = false;
                colvarLastReplyDate.IsReadOnly = false;
                
                schema.Columns.Add(colvarLastReplyDate);
                
                TableSchema.TableColumn colvarReplies = new TableSchema.TableColumn(schema);
                colvarReplies.ColumnName = "Replies";
                colvarReplies.DataType = DbType.Int32;
                colvarReplies.MaxLength = 0;
                colvarReplies.AutoIncrement = false;
                colvarReplies.IsNullable = false;
                colvarReplies.IsPrimaryKey = false;
                colvarReplies.IsForeignKey = false;
                colvarReplies.IsReadOnly = false;
                
                schema.Columns.Add(colvarReplies);
                
                TableSchema.TableColumn colvarTotalViews = new TableSchema.TableColumn(schema);
                colvarTotalViews.ColumnName = "TotalViews";
                colvarTotalViews.DataType = DbType.Int32;
                colvarTotalViews.MaxLength = 0;
                colvarTotalViews.AutoIncrement = false;
                colvarTotalViews.IsNullable = false;
                colvarTotalViews.IsPrimaryKey = false;
                colvarTotalViews.IsForeignKey = false;
                colvarTotalViews.IsReadOnly = false;
                
                schema.Columns.Add(colvarTotalViews);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("IMPORT_Threads",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ImportThread()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ImportThread(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ImportThread(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ImportThread(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("ForumID")]
        public int ForumID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ForumID");
		    }

            set 
		    {
			    SetColumnValue("ForumID", value);
            }

        }

	      
        [XmlAttribute("ThreadID")]
        public int ThreadID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ThreadID");
		    }

            set 
		    {
			    SetColumnValue("ThreadID", value);
            }

        }

	      
        [XmlAttribute("CreatedBy")]
        public string CreatedBy 
	    {
		    get
		    {
			    return GetColumnValue<string>("CreatedBy");
		    }

            set 
		    {
			    SetColumnValue("CreatedBy", value);
            }

        }

	      
        [XmlAttribute("CreatedOn")]
        public DateTime CreatedOn 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("CreatedOn");
		    }

            set 
		    {
			    SetColumnValue("CreatedOn", value);
            }

        }

	      
        [XmlAttribute("Subject")]
        public string Subject 
	    {
		    get
		    {
			    return GetColumnValue<string>("Subject");
		    }

            set 
		    {
			    SetColumnValue("Subject", value);
            }

        }

	      
        [XmlAttribute("ModifiedBy")]
        public string ModifiedBy 
	    {
		    get
		    {
			    return GetColumnValue<string>("ModifiedBy");
		    }

            set 
		    {
			    SetColumnValue("ModifiedBy", value);
            }

        }

	      
        [XmlAttribute("LastViewDate")]
        public DateTime LastViewDate 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("LastViewDate");
		    }

            set 
		    {
			    SetColumnValue("LastViewDate", value);
            }

        }

	      
        [XmlAttribute("LastReplyAuthor")]
        public string LastReplyAuthor 
	    {
		    get
		    {
			    return GetColumnValue<string>("LastReplyAuthor");
		    }

            set 
		    {
			    SetColumnValue("LastReplyAuthor", value);
            }

        }

	      
        [XmlAttribute("LastReplyDate")]
        public DateTime LastReplyDate 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("LastReplyDate");
		    }

            set 
		    {
			    SetColumnValue("LastReplyDate", value);
            }

        }

	      
        [XmlAttribute("Replies")]
        public int Replies 
	    {
		    get
		    {
			    return GetColumnValue<int>("Replies");
		    }

            set 
		    {
			    SetColumnValue("Replies", value);
            }

        }

	      
        [XmlAttribute("TotalViews")]
        public int TotalViews 
	    {
		    get
		    {
			    return GetColumnValue<int>("TotalViews");
		    }

            set 
		    {
			    SetColumnValue("TotalViews", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string ForumID = @"ForumID";
            
            public static string ThreadID = @"ThreadID";
            
            public static string CreatedBy = @"CreatedBy";
            
            public static string CreatedOn = @"CreatedOn";
            
            public static string Subject = @"Subject";
            
            public static string ModifiedBy = @"ModifiedBy";
            
            public static string LastViewDate = @"LastViewDate";
            
            public static string LastReplyAuthor = @"LastReplyAuthor";
            
            public static string LastReplyDate = @"LastReplyDate";
            
            public static string Replies = @"Replies";
            
            public static string TotalViews = @"TotalViews";
            
	    }

	    #endregion
    }

}

