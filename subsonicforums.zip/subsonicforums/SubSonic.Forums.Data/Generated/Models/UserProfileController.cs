using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_UserProfile
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class UserProfileController
    {
        // Preload our schema..
        UserProfile thisSchemaLoad = new UserProfile();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public UserProfileCollection FetchAll()
        {
            UserProfileCollection coll = new UserProfileCollection();
            Query qry = new Query(UserProfile.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public UserProfileCollection FetchByID(object UserName)
        {
            UserProfileCollection coll = new UserProfileCollection().Where("UserName", UserName).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public UserProfileCollection FetchByQuery(Query qry)
        {
            UserProfileCollection coll = new UserProfileCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object UserName)
        {
            return (UserProfile.Delete(UserName) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object UserName)
        {
            return (UserProfile.Destroy(UserName) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string UserName,int TotalPosts,DateTime MemberSince,string Email,string Signature,int Props,bool IsApproved,bool IsModerated,string Bio,double? TimeZone,bool HTMLEmail,bool AllowEmailContact,string HelpfulKeywords,string UserRoles)
	    {
		    UserProfile item = new UserProfile();
		    
            item.UserName = UserName;
            
            item.TotalPosts = TotalPosts;
            
            item.MemberSince = MemberSince;
            
            item.Email = Email;
            
            item.Signature = Signature;
            
            item.Props = Props;
            
            item.IsApproved = IsApproved;
            
            item.IsModerated = IsModerated;
            
            item.Bio = Bio;
            
            item.TimeZone = TimeZone;
            
            item.HTMLEmail = HTMLEmail;
            
            item.AllowEmailContact = AllowEmailContact;
            
            item.HelpfulKeywords = HelpfulKeywords;
            
            item.UserRoles = UserRoles;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(string UserName,int TotalPosts,DateTime MemberSince,string Email,string Signature,int Props,bool IsApproved,bool IsModerated,string Bio,double? TimeZone,bool HTMLEmail,bool AllowEmailContact,string HelpfulKeywords,string UserRoles)
	    {
		    UserProfile item = new UserProfile();
		    
				item.UserName = UserName;
				
				item.TotalPosts = TotalPosts;
				
				item.MemberSince = MemberSince;
				
				item.Email = Email;
				
				item.Signature = Signature;
				
				item.Props = Props;
				
				item.IsApproved = IsApproved;
				
				item.IsModerated = IsModerated;
				
				item.Bio = Bio;
				
				item.TimeZone = TimeZone;
				
				item.HTMLEmail = HTMLEmail;
				
				item.AllowEmailContact = AllowEmailContact;
				
				item.HelpfulKeywords = HelpfulKeywords;
				
				item.UserRoles = UserRoles;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

