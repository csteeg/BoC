using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_Forum_Group
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class ForumGroupController
    {
        // Preload our schema..
        ForumGroup thisSchemaLoad = new ForumGroup();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public ForumGroupCollection FetchAll()
        {
            ForumGroupCollection coll = new ForumGroupCollection();
            Query qry = new Query(ForumGroup.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public ForumGroupCollection FetchByID(object GroupID)
        {
            ForumGroupCollection coll = new ForumGroupCollection().Where("GroupID", GroupID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public ForumGroupCollection FetchByQuery(Query qry)
        {
            ForumGroupCollection coll = new ForumGroupCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object GroupID)
        {
            return (ForumGroup.Delete(GroupID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object GroupID)
        {
            return (ForumGroup.Destroy(GroupID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string GroupName,string Description,string Roles,int ListOrder,string CreatedBy,DateTime CreatedOn,string ModifiedBy,DateTime ModifiedOn,bool Deleted)
	    {
		    ForumGroup item = new ForumGroup();
		    
            item.GroupName = GroupName;
            
            item.Description = Description;
            
            item.Roles = Roles;
            
            item.ListOrder = ListOrder;
            
            item.CreatedBy = CreatedBy;
            
            item.CreatedOn = CreatedOn;
            
            item.ModifiedBy = ModifiedBy;
            
            item.ModifiedOn = ModifiedOn;
            
            item.Deleted = Deleted;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int GroupID,string GroupName,string Description,string Roles,int ListOrder,string CreatedBy,DateTime CreatedOn,string ModifiedBy,DateTime ModifiedOn,bool Deleted)
	    {
		    ForumGroup item = new ForumGroup();
		    
				item.GroupID = GroupID;
				
				item.GroupName = GroupName;
				
				item.Description = Description;
				
				item.Roles = Roles;
				
				item.ListOrder = ListOrder;
				
				item.CreatedBy = CreatedBy;
				
				item.CreatedOn = CreatedOn;
				
				item.ModifiedBy = ModifiedBy;
				
				item.ModifiedOn = ModifiedOn;
				
				item.Deleted = Deleted;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

