using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the Post class.
	/// </summary>
	[Serializable]
	public partial class PostCollection : ActiveList<Post, PostCollection> 
	{	   
		public PostCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_Post table.
	/// </summary>
	[Serializable]
	public partial class Post : ActiveRecord<Post>
	{
		#region .ctors and Default Settings
		
		public Post()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public Post(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public Post(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public Post(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_Post", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarPostID = new TableSchema.TableColumn(schema);
				colvarPostID.ColumnName = "PostID";
				colvarPostID.DataType = DbType.Int32;
				colvarPostID.MaxLength = 0;
				colvarPostID.AutoIncrement = true;
				colvarPostID.IsNullable = false;
				colvarPostID.IsPrimaryKey = true;
				colvarPostID.IsForeignKey = false;
				colvarPostID.IsReadOnly = false;
				colvarPostID.DefaultSetting = @"";
				colvarPostID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarPostID);
				
				TableSchema.TableColumn colvarSubject = new TableSchema.TableColumn(schema);
				colvarSubject.ColumnName = "Subject";
				colvarSubject.DataType = DbType.String;
				colvarSubject.MaxLength = 250;
				colvarSubject.AutoIncrement = false;
				colvarSubject.IsNullable = false;
				colvarSubject.IsPrimaryKey = false;
				colvarSubject.IsForeignKey = false;
				colvarSubject.IsReadOnly = false;
				colvarSubject.DefaultSetting = @"";
				colvarSubject.ForeignKeyTableName = "";
				schema.Columns.Add(colvarSubject);
				
				TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
				colvarThreadID.ColumnName = "ThreadID";
				colvarThreadID.DataType = DbType.Int32;
				colvarThreadID.MaxLength = 0;
				colvarThreadID.AutoIncrement = false;
				colvarThreadID.IsNullable = false;
				colvarThreadID.IsPrimaryKey = false;
				colvarThreadID.IsForeignKey = true;
				colvarThreadID.IsReadOnly = false;
				colvarThreadID.DefaultSetting = @"";
				
					colvarThreadID.ForeignKeyTableName = "SS_Thread";
				schema.Columns.Add(colvarThreadID);
				
				TableSchema.TableColumn colvarPostGUID = new TableSchema.TableColumn(schema);
				colvarPostGUID.ColumnName = "PostGUID";
				colvarPostGUID.DataType = DbType.Guid;
				colvarPostGUID.MaxLength = 0;
				colvarPostGUID.AutoIncrement = false;
				colvarPostGUID.IsNullable = false;
				colvarPostGUID.IsPrimaryKey = false;
				colvarPostGUID.IsForeignKey = false;
				colvarPostGUID.IsReadOnly = false;
				
						colvarPostGUID.DefaultSetting = @"(newid())";
				colvarPostGUID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarPostGUID);
				
				TableSchema.TableColumn colvarPostTypeID = new TableSchema.TableColumn(schema);
				colvarPostTypeID.ColumnName = "PostTypeID";
				colvarPostTypeID.DataType = DbType.Int32;
				colvarPostTypeID.MaxLength = 0;
				colvarPostTypeID.AutoIncrement = false;
				colvarPostTypeID.IsNullable = false;
				colvarPostTypeID.IsPrimaryKey = false;
				colvarPostTypeID.IsForeignKey = true;
				colvarPostTypeID.IsReadOnly = false;
				
						colvarPostTypeID.DefaultSetting = @"((1))";
				
					colvarPostTypeID.ForeignKeyTableName = "SS_PostType";
				schema.Columns.Add(colvarPostTypeID);
				
				TableSchema.TableColumn colvarPostText = new TableSchema.TableColumn(schema);
				colvarPostText.ColumnName = "PostText";
				colvarPostText.DataType = DbType.String;
				colvarPostText.MaxLength = -1;
				colvarPostText.AutoIncrement = false;
				colvarPostText.IsNullable = false;
				colvarPostText.IsPrimaryKey = false;
				colvarPostText.IsForeignKey = false;
				colvarPostText.IsReadOnly = false;
				colvarPostText.DefaultSetting = @"";
				colvarPostText.ForeignKeyTableName = "";
				schema.Columns.Add(colvarPostText);
				
				TableSchema.TableColumn colvarFormattedPostText = new TableSchema.TableColumn(schema);
				colvarFormattedPostText.ColumnName = "FormattedPostText";
				colvarFormattedPostText.DataType = DbType.String;
				colvarFormattedPostText.MaxLength = -1;
				colvarFormattedPostText.AutoIncrement = false;
				colvarFormattedPostText.IsNullable = true;
				colvarFormattedPostText.IsPrimaryKey = false;
				colvarFormattedPostText.IsForeignKey = false;
				colvarFormattedPostText.IsReadOnly = false;
				colvarFormattedPostText.DefaultSetting = @"";
				colvarFormattedPostText.ForeignKeyTableName = "";
				schema.Columns.Add(colvarFormattedPostText);
				
				TableSchema.TableColumn colvarModeratorMessage = new TableSchema.TableColumn(schema);
				colvarModeratorMessage.ColumnName = "ModeratorMessage";
				colvarModeratorMessage.DataType = DbType.String;
				colvarModeratorMessage.MaxLength = 1500;
				colvarModeratorMessage.AutoIncrement = false;
				colvarModeratorMessage.IsNullable = true;
				colvarModeratorMessage.IsPrimaryKey = false;
				colvarModeratorMessage.IsForeignKey = false;
				colvarModeratorMessage.IsReadOnly = false;
				colvarModeratorMessage.DefaultSetting = @"";
				colvarModeratorMessage.ForeignKeyTableName = "";
				schema.Columns.Add(colvarModeratorMessage);
				
				TableSchema.TableColumn colvarIPAddress = new TableSchema.TableColumn(schema);
				colvarIPAddress.ColumnName = "IPAddress";
				colvarIPAddress.DataType = DbType.String;
				colvarIPAddress.MaxLength = 50;
				colvarIPAddress.AutoIncrement = false;
				colvarIPAddress.IsNullable = true;
				colvarIPAddress.IsPrimaryKey = false;
				colvarIPAddress.IsForeignKey = false;
				colvarIPAddress.IsReadOnly = false;
				colvarIPAddress.DefaultSetting = @"";
				colvarIPAddress.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIPAddress);
				
				TableSchema.TableColumn colvarAuthorEmail = new TableSchema.TableColumn(schema);
				colvarAuthorEmail.ColumnName = "AuthorEmail";
				colvarAuthorEmail.DataType = DbType.String;
				colvarAuthorEmail.MaxLength = 50;
				colvarAuthorEmail.AutoIncrement = false;
				colvarAuthorEmail.IsNullable = true;
				colvarAuthorEmail.IsPrimaryKey = false;
				colvarAuthorEmail.IsForeignKey = false;
				colvarAuthorEmail.IsReadOnly = false;
				colvarAuthorEmail.DefaultSetting = @"";
				colvarAuthorEmail.ForeignKeyTableName = "";
				schema.Columns.Add(colvarAuthorEmail);
				
				TableSchema.TableColumn colvarCreatedBy = new TableSchema.TableColumn(schema);
				colvarCreatedBy.ColumnName = "CreatedBy";
				colvarCreatedBy.DataType = DbType.String;
				colvarCreatedBy.MaxLength = 50;
				colvarCreatedBy.AutoIncrement = false;
				colvarCreatedBy.IsNullable = true;
				colvarCreatedBy.IsPrimaryKey = false;
				colvarCreatedBy.IsForeignKey = true;
				colvarCreatedBy.IsReadOnly = false;
				colvarCreatedBy.DefaultSetting = @"";
				
					colvarCreatedBy.ForeignKeyTableName = "SS_UserProfile";
				schema.Columns.Add(colvarCreatedBy);
				
				TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
				colvarCreatedOn.ColumnName = "CreatedOn";
				colvarCreatedOn.DataType = DbType.DateTime;
				colvarCreatedOn.MaxLength = 0;
				colvarCreatedOn.AutoIncrement = false;
				colvarCreatedOn.IsNullable = false;
				colvarCreatedOn.IsPrimaryKey = false;
				colvarCreatedOn.IsForeignKey = false;
				colvarCreatedOn.IsReadOnly = false;
				
						colvarCreatedOn.DefaultSetting = @"(getdate())";
				colvarCreatedOn.ForeignKeyTableName = "";
				schema.Columns.Add(colvarCreatedOn);
				
				TableSchema.TableColumn colvarModifiedBy = new TableSchema.TableColumn(schema);
				colvarModifiedBy.ColumnName = "ModifiedBy";
				colvarModifiedBy.DataType = DbType.String;
				colvarModifiedBy.MaxLength = 50;
				colvarModifiedBy.AutoIncrement = false;
				colvarModifiedBy.IsNullable = true;
				colvarModifiedBy.IsPrimaryKey = false;
				colvarModifiedBy.IsForeignKey = false;
				colvarModifiedBy.IsReadOnly = false;
				colvarModifiedBy.DefaultSetting = @"";
				colvarModifiedBy.ForeignKeyTableName = "";
				schema.Columns.Add(colvarModifiedBy);
				
				TableSchema.TableColumn colvarModifiedOn = new TableSchema.TableColumn(schema);
				colvarModifiedOn.ColumnName = "ModifiedOn";
				colvarModifiedOn.DataType = DbType.DateTime;
				colvarModifiedOn.MaxLength = 0;
				colvarModifiedOn.AutoIncrement = false;
				colvarModifiedOn.IsNullable = false;
				colvarModifiedOn.IsPrimaryKey = false;
				colvarModifiedOn.IsForeignKey = false;
				colvarModifiedOn.IsReadOnly = false;
				
						colvarModifiedOn.DefaultSetting = @"(getdate())";
				colvarModifiedOn.ForeignKeyTableName = "";
				schema.Columns.Add(colvarModifiedOn);
				
				TableSchema.TableColumn colvarDeleted = new TableSchema.TableColumn(schema);
				colvarDeleted.ColumnName = "Deleted";
				colvarDeleted.DataType = DbType.Boolean;
				colvarDeleted.MaxLength = 0;
				colvarDeleted.AutoIncrement = false;
				colvarDeleted.IsNullable = false;
				colvarDeleted.IsPrimaryKey = false;
				colvarDeleted.IsForeignKey = false;
				colvarDeleted.IsReadOnly = false;
				
						colvarDeleted.DefaultSetting = @"((0))";
				colvarDeleted.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDeleted);
				
				TableSchema.TableColumn colvarIsAnswer = new TableSchema.TableColumn(schema);
				colvarIsAnswer.ColumnName = "IsAnswer";
				colvarIsAnswer.DataType = DbType.Boolean;
				colvarIsAnswer.MaxLength = 0;
				colvarIsAnswer.AutoIncrement = false;
				colvarIsAnswer.IsNullable = false;
				colvarIsAnswer.IsPrimaryKey = false;
				colvarIsAnswer.IsForeignKey = false;
				colvarIsAnswer.IsReadOnly = false;
				
						colvarIsAnswer.DefaultSetting = @"((0))";
				colvarIsAnswer.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsAnswer);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_Post",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("PostID")]
		public int PostID 
		{
			get { return GetColumnValue<int>("PostID"); }

			set { SetColumnValue("PostID", value); }

		}

		  
		[XmlAttribute("Subject")]
		public string Subject 
		{
			get { return GetColumnValue<string>("Subject"); }

			set { SetColumnValue("Subject", value); }

		}

		  
		[XmlAttribute("ThreadID")]
		public int ThreadID 
		{
			get { return GetColumnValue<int>("ThreadID"); }

			set { SetColumnValue("ThreadID", value); }

		}

		  
		[XmlAttribute("PostGUID")]
		public Guid PostGUID 
		{
			get { return GetColumnValue<Guid>("PostGUID"); }

			set { SetColumnValue("PostGUID", value); }

		}

		  
		[XmlAttribute("PostTypeID")]
		public int PostTypeID 
		{
			get { return GetColumnValue<int>("PostTypeID"); }

			set { SetColumnValue("PostTypeID", value); }

		}

		  
		[XmlAttribute("PostText")]
		public string PostText 
		{
			get { return GetColumnValue<string>("PostText"); }

			set { SetColumnValue("PostText", value); }

		}

		  
		[XmlAttribute("FormattedPostText")]
		public string FormattedPostText 
		{
			get { return GetColumnValue<string>("FormattedPostText"); }

			set { SetColumnValue("FormattedPostText", value); }

		}

		  
		[XmlAttribute("ModeratorMessage")]
		public string ModeratorMessage 
		{
			get { return GetColumnValue<string>("ModeratorMessage"); }

			set { SetColumnValue("ModeratorMessage", value); }

		}

		  
		[XmlAttribute("IPAddress")]
		public string IPAddress 
		{
			get { return GetColumnValue<string>("IPAddress"); }

			set { SetColumnValue("IPAddress", value); }

		}

		  
		[XmlAttribute("AuthorEmail")]
		public string AuthorEmail 
		{
			get { return GetColumnValue<string>("AuthorEmail"); }

			set { SetColumnValue("AuthorEmail", value); }

		}

		  
		[XmlAttribute("CreatedBy")]
		public string CreatedBy 
		{
			get { return GetColumnValue<string>("CreatedBy"); }

			set { SetColumnValue("CreatedBy", value); }

		}

		  
		[XmlAttribute("CreatedOn")]
		public DateTime CreatedOn 
		{
			get { return GetColumnValue<DateTime>("CreatedOn"); }

			set { SetColumnValue("CreatedOn", value); }

		}

		  
		[XmlAttribute("ModifiedBy")]
		public string ModifiedBy 
		{
			get { return GetColumnValue<string>("ModifiedBy"); }

			set { SetColumnValue("ModifiedBy", value); }

		}

		  
		[XmlAttribute("ModifiedOn")]
		public DateTime ModifiedOn 
		{
			get { return GetColumnValue<DateTime>("ModifiedOn"); }

			set { SetColumnValue("ModifiedOn", value); }

		}

		  
		[XmlAttribute("Deleted")]
		public bool Deleted 
		{
			get { return GetColumnValue<bool>("Deleted"); }

			set { SetColumnValue("Deleted", value); }

		}

		  
		[XmlAttribute("IsAnswer")]
		public bool IsAnswer 
		{
			get { return GetColumnValue<bool>("IsAnswer"); }

			set { SetColumnValue("IsAnswer", value); }

		}

		
		#endregion
		
		
		#region PrimaryKey Methods
		
		public SubSonic.Forums.UserAnswerCollection UserAnswerRecords()
		{
			return new SubSonic.Forums.UserAnswerCollection().Where(UserAnswer.Columns.PostID, PostID).Load();
		}

		#endregion
		
			
		
		#region ForeignKey Properties
		
		/// <summary>
		/// Returns a PostType ActiveRecord object related to this Post
		/// 
		/// </summary>
		public SubSonic.Forums.PostType PostType
		{
			get { return SubSonic.Forums.PostType.FetchByID(this.PostTypeID); }

			set { SetColumnValue("PostTypeID", value.PostTypeID); }

		}

		
		
		/// <summary>
		/// Returns a Thread ActiveRecord object related to this Post
		/// 
		/// </summary>
		public SubSonic.Forums.Thread Thread
		{
			get { return SubSonic.Forums.Thread.FetchByID(this.ThreadID); }

			set { SetColumnValue("ThreadID", value.ThreadID); }

		}

		
		
		/// <summary>
		/// Returns a UserProfile ActiveRecord object related to this Post
		/// 
		/// </summary>
		public SubSonic.Forums.UserProfile UserProfile
		{
			get { return SubSonic.Forums.UserProfile.FetchByID(this.CreatedBy); }

			set { SetColumnValue("CreatedBy", value.UserName); }

		}

		
		
		#endregion
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varSubject,int varThreadID,Guid varPostGUID,int varPostTypeID,string varPostText,string varFormattedPostText,string varModeratorMessage,string varIPAddress,string varAuthorEmail,string varCreatedBy,DateTime varCreatedOn,string varModifiedBy,DateTime varModifiedOn,bool varDeleted,bool varIsAnswer)
		{
			Post item = new Post();
			
			item.Subject = varSubject;
			
			item.ThreadID = varThreadID;
			
			item.PostGUID = varPostGUID;
			
			item.PostTypeID = varPostTypeID;
			
			item.PostText = varPostText;
			
			item.FormattedPostText = varFormattedPostText;
			
			item.ModeratorMessage = varModeratorMessage;
			
			item.IPAddress = varIPAddress;
			
			item.AuthorEmail = varAuthorEmail;
			
			item.CreatedBy = varCreatedBy;
			
			item.CreatedOn = varCreatedOn;
			
			item.ModifiedBy = varModifiedBy;
			
			item.ModifiedOn = varModifiedOn;
			
			item.Deleted = varDeleted;
			
			item.IsAnswer = varIsAnswer;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varPostID,string varSubject,int varThreadID,Guid varPostGUID,int varPostTypeID,string varPostText,string varFormattedPostText,string varModeratorMessage,string varIPAddress,string varAuthorEmail,string varCreatedBy,DateTime varCreatedOn,string varModifiedBy,DateTime varModifiedOn,bool varDeleted,bool varIsAnswer)
		{
			Post item = new Post();
			
				item.PostID = varPostID;
				
				item.Subject = varSubject;
				
				item.ThreadID = varThreadID;
				
				item.PostGUID = varPostGUID;
				
				item.PostTypeID = varPostTypeID;
				
				item.PostText = varPostText;
				
				item.FormattedPostText = varFormattedPostText;
				
				item.ModeratorMessage = varModeratorMessage;
				
				item.IPAddress = varIPAddress;
				
				item.AuthorEmail = varAuthorEmail;
				
				item.CreatedBy = varCreatedBy;
				
				item.CreatedOn = varCreatedOn;
				
				item.ModifiedBy = varModifiedBy;
				
				item.ModifiedOn = varModifiedOn;
				
				item.Deleted = varDeleted;
				
				item.IsAnswer = varIsAnswer;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string PostID = @"PostID";
			 public static string Subject = @"Subject";
			 public static string ThreadID = @"ThreadID";
			 public static string PostGUID = @"PostGUID";
			 public static string PostTypeID = @"PostTypeID";
			 public static string PostText = @"PostText";
			 public static string FormattedPostText = @"FormattedPostText";
			 public static string ModeratorMessage = @"ModeratorMessage";
			 public static string IPAddress = @"IPAddress";
			 public static string AuthorEmail = @"AuthorEmail";
			 public static string CreatedBy = @"CreatedBy";
			 public static string CreatedOn = @"CreatedOn";
			 public static string ModifiedBy = @"ModifiedBy";
			 public static string ModifiedOn = @"ModifiedOn";
			 public static string Deleted = @"Deleted";
			 public static string IsAnswer = @"IsAnswer";
						
		}

		#endregion
	}

}

