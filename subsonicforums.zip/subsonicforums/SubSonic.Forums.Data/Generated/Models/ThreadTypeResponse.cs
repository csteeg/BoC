using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the ThreadTypeResponse class.
	/// </summary>
	[Serializable]
	public partial class ThreadTypeResponseCollection : ActiveList<ThreadTypeResponse, ThreadTypeResponseCollection> 
	{	   
		public ThreadTypeResponseCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_ThreadTypeResponse table.
	/// </summary>
	[Serializable]
	public partial class ThreadTypeResponse : ActiveRecord<ThreadTypeResponse>
	{
		#region .ctors and Default Settings
		
		public ThreadTypeResponse()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public ThreadTypeResponse(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public ThreadTypeResponse(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public ThreadTypeResponse(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_ThreadTypeResponse", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarThreadTypeResponseID = new TableSchema.TableColumn(schema);
				colvarThreadTypeResponseID.ColumnName = "ThreadTypeResponseID";
				colvarThreadTypeResponseID.DataType = DbType.Int32;
				colvarThreadTypeResponseID.MaxLength = 0;
				colvarThreadTypeResponseID.AutoIncrement = true;
				colvarThreadTypeResponseID.IsNullable = false;
				colvarThreadTypeResponseID.IsPrimaryKey = true;
				colvarThreadTypeResponseID.IsForeignKey = false;
				colvarThreadTypeResponseID.IsReadOnly = false;
				colvarThreadTypeResponseID.DefaultSetting = @"";
				colvarThreadTypeResponseID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarThreadTypeResponseID);
				
				TableSchema.TableColumn colvarThreadTypeID = new TableSchema.TableColumn(schema);
				colvarThreadTypeID.ColumnName = "ThreadTypeID";
				colvarThreadTypeID.DataType = DbType.Int32;
				colvarThreadTypeID.MaxLength = 0;
				colvarThreadTypeID.AutoIncrement = false;
				colvarThreadTypeID.IsNullable = true;
				colvarThreadTypeID.IsPrimaryKey = false;
				colvarThreadTypeID.IsForeignKey = true;
				colvarThreadTypeID.IsReadOnly = false;
				colvarThreadTypeID.DefaultSetting = @"";
				
					colvarThreadTypeID.ForeignKeyTableName = "SS_ThreadType";
				schema.Columns.Add(colvarThreadTypeID);
				
				TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
				colvarDescription.ColumnName = "Description";
				colvarDescription.DataType = DbType.String;
				colvarDescription.MaxLength = 50;
				colvarDescription.AutoIncrement = false;
				colvarDescription.IsNullable = true;
				colvarDescription.IsPrimaryKey = false;
				colvarDescription.IsForeignKey = false;
				colvarDescription.IsReadOnly = false;
				colvarDescription.DefaultSetting = @"";
				colvarDescription.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDescription);
				
				TableSchema.TableColumn colvarPostDesignation = new TableSchema.TableColumn(schema);
				colvarPostDesignation.ColumnName = "PostDesignation";
				colvarPostDesignation.DataType = DbType.String;
				colvarPostDesignation.MaxLength = 50;
				colvarPostDesignation.AutoIncrement = false;
				colvarPostDesignation.IsNullable = true;
				colvarPostDesignation.IsPrimaryKey = false;
				colvarPostDesignation.IsForeignKey = false;
				colvarPostDesignation.IsReadOnly = false;
				colvarPostDesignation.DefaultSetting = @"";
				colvarPostDesignation.ForeignKeyTableName = "";
				schema.Columns.Add(colvarPostDesignation);
				
				TableSchema.TableColumn colvarIsSearchable = new TableSchema.TableColumn(schema);
				colvarIsSearchable.ColumnName = "IsSearchable";
				colvarIsSearchable.DataType = DbType.Boolean;
				colvarIsSearchable.MaxLength = 0;
				colvarIsSearchable.AutoIncrement = false;
				colvarIsSearchable.IsNullable = false;
				colvarIsSearchable.IsPrimaryKey = false;
				colvarIsSearchable.IsForeignKey = false;
				colvarIsSearchable.IsReadOnly = false;
				
						colvarIsSearchable.DefaultSetting = @"((0))";
				colvarIsSearchable.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsSearchable);
				
				TableSchema.TableColumn colvarIsDefault = new TableSchema.TableColumn(schema);
				colvarIsDefault.ColumnName = "IsDefault";
				colvarIsDefault.DataType = DbType.Boolean;
				colvarIsDefault.MaxLength = 0;
				colvarIsDefault.AutoIncrement = false;
				colvarIsDefault.IsNullable = false;
				colvarIsDefault.IsPrimaryKey = false;
				colvarIsDefault.IsForeignKey = false;
				colvarIsDefault.IsReadOnly = false;
				
						colvarIsDefault.DefaultSetting = @"((0))";
				colvarIsDefault.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsDefault);
				
				TableSchema.TableColumn colvarAnswererPropsValue = new TableSchema.TableColumn(schema);
				colvarAnswererPropsValue.ColumnName = "AnswererPropsValue";
				colvarAnswererPropsValue.DataType = DbType.Int32;
				colvarAnswererPropsValue.MaxLength = 0;
				colvarAnswererPropsValue.AutoIncrement = false;
				colvarAnswererPropsValue.IsNullable = false;
				colvarAnswererPropsValue.IsPrimaryKey = false;
				colvarAnswererPropsValue.IsForeignKey = false;
				colvarAnswererPropsValue.IsReadOnly = false;
				
						colvarAnswererPropsValue.DefaultSetting = @"((1))";
				colvarAnswererPropsValue.ForeignKeyTableName = "";
				schema.Columns.Add(colvarAnswererPropsValue);
				
				TableSchema.TableColumn colvarThreadAuthorPropsValue = new TableSchema.TableColumn(schema);
				colvarThreadAuthorPropsValue.ColumnName = "ThreadAuthorPropsValue";
				colvarThreadAuthorPropsValue.DataType = DbType.Int32;
				colvarThreadAuthorPropsValue.MaxLength = 0;
				colvarThreadAuthorPropsValue.AutoIncrement = false;
				colvarThreadAuthorPropsValue.IsNullable = false;
				colvarThreadAuthorPropsValue.IsPrimaryKey = false;
				colvarThreadAuthorPropsValue.IsForeignKey = false;
				colvarThreadAuthorPropsValue.IsReadOnly = false;
				
						colvarThreadAuthorPropsValue.DefaultSetting = @"((0))";
				colvarThreadAuthorPropsValue.ForeignKeyTableName = "";
				schema.Columns.Add(colvarThreadAuthorPropsValue);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_ThreadTypeResponse",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("ThreadTypeResponseID")]
		public int ThreadTypeResponseID 
		{
			get { return GetColumnValue<int>("ThreadTypeResponseID"); }

			set { SetColumnValue("ThreadTypeResponseID", value); }

		}

		  
		[XmlAttribute("ThreadTypeID")]
		public int? ThreadTypeID 
		{
			get { return GetColumnValue<int?>("ThreadTypeID"); }

			set { SetColumnValue("ThreadTypeID", value); }

		}

		  
		[XmlAttribute("Description")]
		public string Description 
		{
			get { return GetColumnValue<string>("Description"); }

			set { SetColumnValue("Description", value); }

		}

		  
		[XmlAttribute("PostDesignation")]
		public string PostDesignation 
		{
			get { return GetColumnValue<string>("PostDesignation"); }

			set { SetColumnValue("PostDesignation", value); }

		}

		  
		[XmlAttribute("IsSearchable")]
		public bool IsSearchable 
		{
			get { return GetColumnValue<bool>("IsSearchable"); }

			set { SetColumnValue("IsSearchable", value); }

		}

		  
		[XmlAttribute("IsDefault")]
		public bool IsDefault 
		{
			get { return GetColumnValue<bool>("IsDefault"); }

			set { SetColumnValue("IsDefault", value); }

		}

		  
		[XmlAttribute("AnswererPropsValue")]
		public int AnswererPropsValue 
		{
			get { return GetColumnValue<int>("AnswererPropsValue"); }

			set { SetColumnValue("AnswererPropsValue", value); }

		}

		  
		[XmlAttribute("ThreadAuthorPropsValue")]
		public int ThreadAuthorPropsValue 
		{
			get { return GetColumnValue<int>("ThreadAuthorPropsValue"); }

			set { SetColumnValue("ThreadAuthorPropsValue", value); }

		}

		
		#endregion
		
		
		#region PrimaryKey Methods
		
		public SubSonic.Forums.UserAnswerCollection UserAnswerRecords()
		{
			return new SubSonic.Forums.UserAnswerCollection().Where(UserAnswer.Columns.ThreadTypeResponseID, ThreadTypeResponseID).Load();
		}

		#endregion
		
			
		
		#region ForeignKey Properties
		
		/// <summary>
		/// Returns a ThreadType ActiveRecord object related to this ThreadTypeResponse
		/// 
		/// </summary>
		public SubSonic.Forums.ThreadType ThreadType
		{
			get { return SubSonic.Forums.ThreadType.FetchByID(this.ThreadTypeID); }

			set { SetColumnValue("ThreadTypeID", value.ThreadTypeID); }

		}

		
		
		#endregion
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(int? varThreadTypeID,string varDescription,string varPostDesignation,bool varIsSearchable,bool varIsDefault,int varAnswererPropsValue,int varThreadAuthorPropsValue)
		{
			ThreadTypeResponse item = new ThreadTypeResponse();
			
			item.ThreadTypeID = varThreadTypeID;
			
			item.Description = varDescription;
			
			item.PostDesignation = varPostDesignation;
			
			item.IsSearchable = varIsSearchable;
			
			item.IsDefault = varIsDefault;
			
			item.AnswererPropsValue = varAnswererPropsValue;
			
			item.ThreadAuthorPropsValue = varThreadAuthorPropsValue;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varThreadTypeResponseID,int? varThreadTypeID,string varDescription,string varPostDesignation,bool varIsSearchable,bool varIsDefault,int varAnswererPropsValue,int varThreadAuthorPropsValue)
		{
			ThreadTypeResponse item = new ThreadTypeResponse();
			
				item.ThreadTypeResponseID = varThreadTypeResponseID;
				
				item.ThreadTypeID = varThreadTypeID;
				
				item.Description = varDescription;
				
				item.PostDesignation = varPostDesignation;
				
				item.IsSearchable = varIsSearchable;
				
				item.IsDefault = varIsDefault;
				
				item.AnswererPropsValue = varAnswererPropsValue;
				
				item.ThreadAuthorPropsValue = varThreadAuthorPropsValue;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string ThreadTypeResponseID = @"ThreadTypeResponseID";
			 public static string ThreadTypeID = @"ThreadTypeID";
			 public static string Description = @"Description";
			 public static string PostDesignation = @"PostDesignation";
			 public static string IsSearchable = @"IsSearchable";
			 public static string IsDefault = @"IsDefault";
			 public static string AnswererPropsValue = @"AnswererPropsValue";
			 public static string ThreadAuthorPropsValue = @"ThreadAuthorPropsValue";
						
		}

		#endregion
	}

}

