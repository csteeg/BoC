using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_ThreadType
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class ThreadTypeController
    {
        // Preload our schema..
        ThreadType thisSchemaLoad = new ThreadType();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public ThreadTypeCollection FetchAll()
        {
            ThreadTypeCollection coll = new ThreadTypeCollection();
            Query qry = new Query(ThreadType.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public ThreadTypeCollection FetchByID(object ThreadTypeID)
        {
            ThreadTypeCollection coll = new ThreadTypeCollection().Where("ThreadTypeID", ThreadTypeID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public ThreadTypeCollection FetchByQuery(Query qry)
        {
            ThreadTypeCollection coll = new ThreadTypeCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object ThreadTypeID)
        {
            return (ThreadType.Delete(ThreadTypeID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object ThreadTypeID)
        {
            return (ThreadType.Destroy(ThreadTypeID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string Description,int ListOrder,string Icon,string CssClass,bool AuthorCanDesignateAnswer)
	    {
		    ThreadType item = new ThreadType();
		    
            item.Description = Description;
            
            item.ListOrder = ListOrder;
            
            item.Icon = Icon;
            
            item.CssClass = CssClass;
            
            item.AuthorCanDesignateAnswer = AuthorCanDesignateAnswer;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int ThreadTypeID,string Description,int ListOrder,string Icon,string CssClass,bool AuthorCanDesignateAnswer)
	    {
		    ThreadType item = new ThreadType();
		    
				item.ThreadTypeID = ThreadTypeID;
				
				item.Description = Description;
				
				item.ListOrder = ListOrder;
				
				item.Icon = Icon;
				
				item.CssClass = CssClass;
				
				item.AuthorCanDesignateAnswer = AuthorCanDesignateAnswer;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

