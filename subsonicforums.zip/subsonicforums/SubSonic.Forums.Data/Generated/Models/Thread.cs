using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the Thread class.
	/// </summary>
	[Serializable]
	public partial class ThreadCollection : ActiveList<Thread, ThreadCollection> 
	{	   
		public ThreadCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_Thread table.
	/// </summary>
	[Serializable]
	public partial class Thread : ActiveRecord<Thread>
	{
		#region .ctors and Default Settings
		
		public Thread()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public Thread(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public Thread(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public Thread(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_Thread", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
				colvarThreadID.ColumnName = "ThreadID";
				colvarThreadID.DataType = DbType.Int32;
				colvarThreadID.MaxLength = 0;
				colvarThreadID.AutoIncrement = true;
				colvarThreadID.IsNullable = false;
				colvarThreadID.IsPrimaryKey = true;
				colvarThreadID.IsForeignKey = false;
				colvarThreadID.IsReadOnly = false;
				colvarThreadID.DefaultSetting = @"";
				colvarThreadID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarThreadID);
				
				TableSchema.TableColumn colvarThreadTypeID = new TableSchema.TableColumn(schema);
				colvarThreadTypeID.ColumnName = "ThreadTypeID";
				colvarThreadTypeID.DataType = DbType.Int32;
				colvarThreadTypeID.MaxLength = 0;
				colvarThreadTypeID.AutoIncrement = false;
				colvarThreadTypeID.IsNullable = false;
				colvarThreadTypeID.IsPrimaryKey = false;
				colvarThreadTypeID.IsForeignKey = true;
				colvarThreadTypeID.IsReadOnly = false;
				
						colvarThreadTypeID.DefaultSetting = @"((1))";
				
					colvarThreadTypeID.ForeignKeyTableName = "SS_ThreadType";
				schema.Columns.Add(colvarThreadTypeID);
				
				TableSchema.TableColumn colvarSubject = new TableSchema.TableColumn(schema);
				colvarSubject.ColumnName = "Subject";
				colvarSubject.DataType = DbType.String;
				colvarSubject.MaxLength = 250;
				colvarSubject.AutoIncrement = false;
				colvarSubject.IsNullable = false;
				colvarSubject.IsPrimaryKey = false;
				colvarSubject.IsForeignKey = false;
				colvarSubject.IsReadOnly = false;
				colvarSubject.DefaultSetting = @"";
				colvarSubject.ForeignKeyTableName = "";
				schema.Columns.Add(colvarSubject);
				
				TableSchema.TableColumn colvarForumID = new TableSchema.TableColumn(schema);
				colvarForumID.ColumnName = "ForumID";
				colvarForumID.DataType = DbType.Int32;
				colvarForumID.MaxLength = 0;
				colvarForumID.AutoIncrement = false;
				colvarForumID.IsNullable = false;
				colvarForumID.IsPrimaryKey = false;
				colvarForumID.IsForeignKey = true;
				colvarForumID.IsReadOnly = false;
				colvarForumID.DefaultSetting = @"";
				
					colvarForumID.ForeignKeyTableName = "SS_Forum";
				schema.Columns.Add(colvarForumID);
				
				TableSchema.TableColumn colvarResolution = new TableSchema.TableColumn(schema);
				colvarResolution.ColumnName = "Resolution";
				colvarResolution.DataType = DbType.String;
				colvarResolution.MaxLength = 50;
				colvarResolution.AutoIncrement = false;
				colvarResolution.IsNullable = false;
				colvarResolution.IsPrimaryKey = false;
				colvarResolution.IsForeignKey = false;
				colvarResolution.IsReadOnly = false;
				
						colvarResolution.DefaultSetting = @"(N'Open')";
				colvarResolution.ForeignKeyTableName = "";
				schema.Columns.Add(colvarResolution);
				
				TableSchema.TableColumn colvarStartPostID = new TableSchema.TableColumn(schema);
				colvarStartPostID.ColumnName = "StartPostID";
				colvarStartPostID.DataType = DbType.Int32;
				colvarStartPostID.MaxLength = 0;
				colvarStartPostID.AutoIncrement = false;
				colvarStartPostID.IsNullable = false;
				colvarStartPostID.IsPrimaryKey = false;
				colvarStartPostID.IsForeignKey = false;
				colvarStartPostID.IsReadOnly = false;
				
						colvarStartPostID.DefaultSetting = @"((0))";
				colvarStartPostID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarStartPostID);
				
				TableSchema.TableColumn colvarThreadUrl = new TableSchema.TableColumn(schema);
				colvarThreadUrl.ColumnName = "ThreadUrl";
				colvarThreadUrl.DataType = DbType.String;
				colvarThreadUrl.MaxLength = 50;
				colvarThreadUrl.AutoIncrement = false;
				colvarThreadUrl.IsNullable = false;
				colvarThreadUrl.IsPrimaryKey = false;
				colvarThreadUrl.IsForeignKey = false;
				colvarThreadUrl.IsReadOnly = false;
				
						colvarThreadUrl.DefaultSetting = @"('')";
				colvarThreadUrl.ForeignKeyTableName = "";
				schema.Columns.Add(colvarThreadUrl);
				
				TableSchema.TableColumn colvarViews = new TableSchema.TableColumn(schema);
				colvarViews.ColumnName = "Views";
				colvarViews.DataType = DbType.Int32;
				colvarViews.MaxLength = 0;
				colvarViews.AutoIncrement = false;
				colvarViews.IsNullable = false;
				colvarViews.IsPrimaryKey = false;
				colvarViews.IsForeignKey = false;
				colvarViews.IsReadOnly = false;
				
						colvarViews.DefaultSetting = @"((0))";
				colvarViews.ForeignKeyTableName = "";
				schema.Columns.Add(colvarViews);
				
				TableSchema.TableColumn colvarTotalReplies = new TableSchema.TableColumn(schema);
				colvarTotalReplies.ColumnName = "TotalReplies";
				colvarTotalReplies.DataType = DbType.Int32;
				colvarTotalReplies.MaxLength = 0;
				colvarTotalReplies.AutoIncrement = false;
				colvarTotalReplies.IsNullable = false;
				colvarTotalReplies.IsPrimaryKey = false;
				colvarTotalReplies.IsForeignKey = false;
				colvarTotalReplies.IsReadOnly = false;
				
						colvarTotalReplies.DefaultSetting = @"((0))";
				colvarTotalReplies.ForeignKeyTableName = "";
				schema.Columns.Add(colvarTotalReplies);
				
				TableSchema.TableColumn colvarLastViewDate = new TableSchema.TableColumn(schema);
				colvarLastViewDate.ColumnName = "LastViewDate";
				colvarLastViewDate.DataType = DbType.DateTime;
				colvarLastViewDate.MaxLength = 0;
				colvarLastViewDate.AutoIncrement = false;
				colvarLastViewDate.IsNullable = true;
				colvarLastViewDate.IsPrimaryKey = false;
				colvarLastViewDate.IsForeignKey = false;
				colvarLastViewDate.IsReadOnly = false;
				colvarLastViewDate.DefaultSetting = @"";
				colvarLastViewDate.ForeignKeyTableName = "";
				schema.Columns.Add(colvarLastViewDate);
				
				TableSchema.TableColumn colvarLastReplyAuthor = new TableSchema.TableColumn(schema);
				colvarLastReplyAuthor.ColumnName = "LastReplyAuthor";
				colvarLastReplyAuthor.DataType = DbType.String;
				colvarLastReplyAuthor.MaxLength = 50;
				colvarLastReplyAuthor.AutoIncrement = false;
				colvarLastReplyAuthor.IsNullable = true;
				colvarLastReplyAuthor.IsPrimaryKey = false;
				colvarLastReplyAuthor.IsForeignKey = false;
				colvarLastReplyAuthor.IsReadOnly = false;
				colvarLastReplyAuthor.DefaultSetting = @"";
				colvarLastReplyAuthor.ForeignKeyTableName = "";
				schema.Columns.Add(colvarLastReplyAuthor);
				
				TableSchema.TableColumn colvarLastReplyDate = new TableSchema.TableColumn(schema);
				colvarLastReplyDate.ColumnName = "LastReplyDate";
				colvarLastReplyDate.DataType = DbType.DateTime;
				colvarLastReplyDate.MaxLength = 0;
				colvarLastReplyDate.AutoIncrement = false;
				colvarLastReplyDate.IsNullable = true;
				colvarLastReplyDate.IsPrimaryKey = false;
				colvarLastReplyDate.IsForeignKey = false;
				colvarLastReplyDate.IsReadOnly = false;
				colvarLastReplyDate.DefaultSetting = @"";
				colvarLastReplyDate.ForeignKeyTableName = "";
				schema.Columns.Add(colvarLastReplyDate);
				
				TableSchema.TableColumn colvarCreatedBy = new TableSchema.TableColumn(schema);
				colvarCreatedBy.ColumnName = "CreatedBy";
				colvarCreatedBy.DataType = DbType.String;
				colvarCreatedBy.MaxLength = 50;
				colvarCreatedBy.AutoIncrement = false;
				colvarCreatedBy.IsNullable = true;
				colvarCreatedBy.IsPrimaryKey = false;
				colvarCreatedBy.IsForeignKey = false;
				colvarCreatedBy.IsReadOnly = false;
				colvarCreatedBy.DefaultSetting = @"";
				colvarCreatedBy.ForeignKeyTableName = "";
				schema.Columns.Add(colvarCreatedBy);
				
				TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
				colvarCreatedOn.ColumnName = "CreatedOn";
				colvarCreatedOn.DataType = DbType.DateTime;
				colvarCreatedOn.MaxLength = 0;
				colvarCreatedOn.AutoIncrement = false;
				colvarCreatedOn.IsNullable = false;
				colvarCreatedOn.IsPrimaryKey = false;
				colvarCreatedOn.IsForeignKey = false;
				colvarCreatedOn.IsReadOnly = false;
				
						colvarCreatedOn.DefaultSetting = @"(getdate())";
				colvarCreatedOn.ForeignKeyTableName = "";
				schema.Columns.Add(colvarCreatedOn);
				
				TableSchema.TableColumn colvarModifiedBy = new TableSchema.TableColumn(schema);
				colvarModifiedBy.ColumnName = "ModifiedBy";
				colvarModifiedBy.DataType = DbType.String;
				colvarModifiedBy.MaxLength = 50;
				colvarModifiedBy.AutoIncrement = false;
				colvarModifiedBy.IsNullable = true;
				colvarModifiedBy.IsPrimaryKey = false;
				colvarModifiedBy.IsForeignKey = false;
				colvarModifiedBy.IsReadOnly = false;
				colvarModifiedBy.DefaultSetting = @"";
				colvarModifiedBy.ForeignKeyTableName = "";
				schema.Columns.Add(colvarModifiedBy);
				
				TableSchema.TableColumn colvarModifiedOn = new TableSchema.TableColumn(schema);
				colvarModifiedOn.ColumnName = "ModifiedOn";
				colvarModifiedOn.DataType = DbType.DateTime;
				colvarModifiedOn.MaxLength = 0;
				colvarModifiedOn.AutoIncrement = false;
				colvarModifiedOn.IsNullable = false;
				colvarModifiedOn.IsPrimaryKey = false;
				colvarModifiedOn.IsForeignKey = false;
				colvarModifiedOn.IsReadOnly = false;
				
						colvarModifiedOn.DefaultSetting = @"(getdate())";
				colvarModifiedOn.ForeignKeyTableName = "";
				schema.Columns.Add(colvarModifiedOn);
				
				TableSchema.TableColumn colvarDeleted = new TableSchema.TableColumn(schema);
				colvarDeleted.ColumnName = "Deleted";
				colvarDeleted.DataType = DbType.Boolean;
				colvarDeleted.MaxLength = 0;
				colvarDeleted.AutoIncrement = false;
				colvarDeleted.IsNullable = false;
				colvarDeleted.IsPrimaryKey = false;
				colvarDeleted.IsForeignKey = false;
				colvarDeleted.IsReadOnly = false;
				
						colvarDeleted.DefaultSetting = @"((0))";
				colvarDeleted.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDeleted);
				
				TableSchema.TableColumn colvarIsLocked = new TableSchema.TableColumn(schema);
				colvarIsLocked.ColumnName = "IsLocked";
				colvarIsLocked.DataType = DbType.Boolean;
				colvarIsLocked.MaxLength = 0;
				colvarIsLocked.AutoIncrement = false;
				colvarIsLocked.IsNullable = false;
				colvarIsLocked.IsPrimaryKey = false;
				colvarIsLocked.IsForeignKey = false;
				colvarIsLocked.IsReadOnly = false;
				
						colvarIsLocked.DefaultSetting = @"((0))";
				colvarIsLocked.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsLocked);
				
				TableSchema.TableColumn colvarIsStickied = new TableSchema.TableColumn(schema);
				colvarIsStickied.ColumnName = "IsStickied";
				colvarIsStickied.DataType = DbType.Boolean;
				colvarIsStickied.MaxLength = 0;
				colvarIsStickied.AutoIncrement = false;
				colvarIsStickied.IsNullable = false;
				colvarIsStickied.IsPrimaryKey = false;
				colvarIsStickied.IsForeignKey = false;
				colvarIsStickied.IsReadOnly = false;
				
						colvarIsStickied.DefaultSetting = @"((0))";
				colvarIsStickied.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsStickied);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_Thread",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("ThreadID")]
		public int ThreadID 
		{
			get { return GetColumnValue<int>("ThreadID"); }

			set { SetColumnValue("ThreadID", value); }

		}

		  
		[XmlAttribute("ThreadTypeID")]
		public int ThreadTypeID 
		{
			get { return GetColumnValue<int>("ThreadTypeID"); }

			set { SetColumnValue("ThreadTypeID", value); }

		}

		  
		[XmlAttribute("Subject")]
		public string Subject 
		{
			get { return GetColumnValue<string>("Subject"); }

			set { SetColumnValue("Subject", value); }

		}

		  
		[XmlAttribute("ForumID")]
		public int ForumID 
		{
			get { return GetColumnValue<int>("ForumID"); }

			set { SetColumnValue("ForumID", value); }

		}

		  
		[XmlAttribute("Resolution")]
		public string Resolution 
		{
			get { return GetColumnValue<string>("Resolution"); }

			set { SetColumnValue("Resolution", value); }

		}

		  
		[XmlAttribute("StartPostID")]
		public int StartPostID 
		{
			get { return GetColumnValue<int>("StartPostID"); }

			set { SetColumnValue("StartPostID", value); }

		}

		  
		[XmlAttribute("ThreadUrl")]
		public string ThreadUrl 
		{
			get { return GetColumnValue<string>("ThreadUrl"); }

			set { SetColumnValue("ThreadUrl", value); }

		}

		  
		[XmlAttribute("Views")]
		public int Views 
		{
			get { return GetColumnValue<int>("Views"); }

			set { SetColumnValue("Views", value); }

		}

		  
		[XmlAttribute("TotalReplies")]
		public int TotalReplies 
		{
			get { return GetColumnValue<int>("TotalReplies"); }

			set { SetColumnValue("TotalReplies", value); }

		}

		  
		[XmlAttribute("LastViewDate")]
		public DateTime? LastViewDate 
		{
			get { return GetColumnValue<DateTime?>("LastViewDate"); }

			set { SetColumnValue("LastViewDate", value); }

		}

		  
		[XmlAttribute("LastReplyAuthor")]
		public string LastReplyAuthor 
		{
			get { return GetColumnValue<string>("LastReplyAuthor"); }

			set { SetColumnValue("LastReplyAuthor", value); }

		}

		  
		[XmlAttribute("LastReplyDate")]
		public DateTime? LastReplyDate 
		{
			get { return GetColumnValue<DateTime?>("LastReplyDate"); }

			set { SetColumnValue("LastReplyDate", value); }

		}

		  
		[XmlAttribute("CreatedBy")]
		public string CreatedBy 
		{
			get { return GetColumnValue<string>("CreatedBy"); }

			set { SetColumnValue("CreatedBy", value); }

		}

		  
		[XmlAttribute("CreatedOn")]
		public DateTime CreatedOn 
		{
			get { return GetColumnValue<DateTime>("CreatedOn"); }

			set { SetColumnValue("CreatedOn", value); }

		}

		  
		[XmlAttribute("ModifiedBy")]
		public string ModifiedBy 
		{
			get { return GetColumnValue<string>("ModifiedBy"); }

			set { SetColumnValue("ModifiedBy", value); }

		}

		  
		[XmlAttribute("ModifiedOn")]
		public DateTime ModifiedOn 
		{
			get { return GetColumnValue<DateTime>("ModifiedOn"); }

			set { SetColumnValue("ModifiedOn", value); }

		}

		  
		[XmlAttribute("Deleted")]
		public bool Deleted 
		{
			get { return GetColumnValue<bool>("Deleted"); }

			set { SetColumnValue("Deleted", value); }

		}

		  
		[XmlAttribute("IsLocked")]
		public bool IsLocked 
		{
			get { return GetColumnValue<bool>("IsLocked"); }

			set { SetColumnValue("IsLocked", value); }

		}

		  
		[XmlAttribute("IsStickied")]
		public bool IsStickied 
		{
			get { return GetColumnValue<bool>("IsStickied"); }

			set { SetColumnValue("IsStickied", value); }

		}

		
		#endregion
		
		
		#region PrimaryKey Methods
		
		public SubSonic.Forums.PostCollection PostRecords()
		{
			return new SubSonic.Forums.PostCollection().Where(Post.Columns.ThreadID, ThreadID).Load();
		}

		public SubSonic.Forums.UserWatchedThreadCollection UserWatchedThreadRecords()
		{
			return new SubSonic.Forums.UserWatchedThreadCollection().Where(UserWatchedThread.Columns.ThreadID, ThreadID).Load();
		}

		#endregion
		
			
		
		#region ForeignKey Properties
		
		/// <summary>
		/// Returns a Forum ActiveRecord object related to this Thread
		/// 
		/// </summary>
		public SubSonic.Forums.Forum Forum
		{
			get { return SubSonic.Forums.Forum.FetchByID(this.ForumID); }

			set { SetColumnValue("ForumID", value.ForumID); }

		}

		
		
		/// <summary>
		/// Returns a ThreadType ActiveRecord object related to this Thread
		/// 
		/// </summary>
		public SubSonic.Forums.ThreadType ThreadType
		{
			get { return SubSonic.Forums.ThreadType.FetchByID(this.ThreadTypeID); }

			set { SetColumnValue("ThreadTypeID", value.ThreadTypeID); }

		}

		
		
		#endregion
		
		
		
		#region Many To Many Helpers
		
		 
		public SubSonic.Forums.UserProfileCollection GetUserProfileCollection() { return Thread.GetUserProfileCollection(this.ThreadID); }

		public static SubSonic.Forums.UserProfileCollection GetUserProfileCollection(int varThreadID)
		{
			SubSonic.QueryCommand cmd = new SubSonic.QueryCommand(
				"SELECT * FROM SS_UserProfile INNER JOIN SS_User_WatchedThread ON "+
				"SS_UserProfile.UserName=SS_User_WatchedThread.UserName WHERE SS_User_WatchedThread.ThreadID=@ThreadID", Thread.Schema.Provider.Name);
			
			cmd.AddParameter("@ThreadID", varThreadID, DbType.Int32);
			IDataReader rdr = SubSonic.DataService.GetReader(cmd);
			UserProfileCollection coll = new UserProfileCollection();
			coll.LoadAndCloseReader(rdr);
			return coll;
		}

		
		public static void SaveUserProfileMap(int varThreadID, UserProfileCollection items)
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_WatchedThread WHERE ThreadID=@ThreadID", Thread.Schema.Provider.Name);
			cmdDel.AddParameter("@ThreadID", varThreadID);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (UserProfile item in items)
			{
				UserWatchedThread varUserWatchedThread = new UserWatchedThread();
				varUserWatchedThread.SetColumnValue("ThreadID", varThreadID);
				varUserWatchedThread.SetColumnValue("UserName", item.GetPrimaryKeyValue());
				varUserWatchedThread.Save();
			}

		}

		public static void SaveUserProfileMap(int varThreadID, System.Web.UI.WebControls.ListItemCollection itemList) 
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			 QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_WatchedThread WHERE ThreadID=@ThreadID", Thread.Schema.Provider.Name);
			cmdDel.AddParameter("@ThreadID", varThreadID);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (System.Web.UI.WebControls.ListItem l in itemList) 
			{
				if (l.Selected) 
				{
					UserWatchedThread varUserWatchedThread = new UserWatchedThread();
					varUserWatchedThread.SetColumnValue("ThreadID", varThreadID);
					varUserWatchedThread.SetColumnValue("UserName", l.Value);
					varUserWatchedThread.Save();
				}

			}

		}

		public static void SaveUserProfileMap(int varThreadID , int[] itemList) 
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			 QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_WatchedThread WHERE ThreadID=@ThreadID", Thread.Schema.Provider.Name);
			cmdDel.AddParameter("@ThreadID", varThreadID);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (int item in itemList) 
			{
				UserWatchedThread varUserWatchedThread = new UserWatchedThread();
				varUserWatchedThread.SetColumnValue("ThreadID", varThreadID);
				varUserWatchedThread.SetColumnValue("UserName", item);
				varUserWatchedThread.Save();
			}

		}

		
		public static void DeleteUserProfileMap(int varThreadID) 
		{
			QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_WatchedThread WHERE ThreadID=@ThreadID", Thread.Schema.Provider.Name);
			cmdDel.AddParameter("@ThreadID", varThreadID);
			DataService.ExecuteQuery(cmdDel);
		}

		
		#endregion
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(int varThreadTypeID,string varSubject,int varForumID,string varResolution,int varStartPostID,string varThreadUrl,int varViews,int varTotalReplies,DateTime? varLastViewDate,string varLastReplyAuthor,DateTime? varLastReplyDate,string varCreatedBy,DateTime varCreatedOn,string varModifiedBy,DateTime varModifiedOn,bool varDeleted,bool varIsLocked,bool varIsStickied)
		{
			Thread item = new Thread();
			
			item.ThreadTypeID = varThreadTypeID;
			
			item.Subject = varSubject;
			
			item.ForumID = varForumID;
			
			item.Resolution = varResolution;
			
			item.StartPostID = varStartPostID;
			
			item.ThreadUrl = varThreadUrl;
			
			item.Views = varViews;
			
			item.TotalReplies = varTotalReplies;
			
			item.LastViewDate = varLastViewDate;
			
			item.LastReplyAuthor = varLastReplyAuthor;
			
			item.LastReplyDate = varLastReplyDate;
			
			item.CreatedBy = varCreatedBy;
			
			item.CreatedOn = varCreatedOn;
			
			item.ModifiedBy = varModifiedBy;
			
			item.ModifiedOn = varModifiedOn;
			
			item.Deleted = varDeleted;
			
			item.IsLocked = varIsLocked;
			
			item.IsStickied = varIsStickied;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varThreadID,int varThreadTypeID,string varSubject,int varForumID,string varResolution,int varStartPostID,string varThreadUrl,int varViews,int varTotalReplies,DateTime? varLastViewDate,string varLastReplyAuthor,DateTime? varLastReplyDate,string varCreatedBy,DateTime varCreatedOn,string varModifiedBy,DateTime varModifiedOn,bool varDeleted,bool varIsLocked,bool varIsStickied)
		{
			Thread item = new Thread();
			
				item.ThreadID = varThreadID;
				
				item.ThreadTypeID = varThreadTypeID;
				
				item.Subject = varSubject;
				
				item.ForumID = varForumID;
				
				item.Resolution = varResolution;
				
				item.StartPostID = varStartPostID;
				
				item.ThreadUrl = varThreadUrl;
				
				item.Views = varViews;
				
				item.TotalReplies = varTotalReplies;
				
				item.LastViewDate = varLastViewDate;
				
				item.LastReplyAuthor = varLastReplyAuthor;
				
				item.LastReplyDate = varLastReplyDate;
				
				item.CreatedBy = varCreatedBy;
				
				item.CreatedOn = varCreatedOn;
				
				item.ModifiedBy = varModifiedBy;
				
				item.ModifiedOn = varModifiedOn;
				
				item.Deleted = varDeleted;
				
				item.IsLocked = varIsLocked;
				
				item.IsStickied = varIsStickied;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string ThreadID = @"ThreadID";
			 public static string ThreadTypeID = @"ThreadTypeID";
			 public static string Subject = @"Subject";
			 public static string ForumID = @"ForumID";
			 public static string Resolution = @"Resolution";
			 public static string StartPostID = @"StartPostID";
			 public static string ThreadUrl = @"ThreadUrl";
			 public static string Views = @"Views";
			 public static string TotalReplies = @"TotalReplies";
			 public static string LastViewDate = @"LastViewDate";
			 public static string LastReplyAuthor = @"LastReplyAuthor";
			 public static string LastReplyDate = @"LastReplyDate";
			 public static string CreatedBy = @"CreatedBy";
			 public static string CreatedOn = @"CreatedOn";
			 public static string ModifiedBy = @"ModifiedBy";
			 public static string ModifiedOn = @"ModifiedOn";
			 public static string Deleted = @"Deleted";
			 public static string IsLocked = @"IsLocked";
			 public static string IsStickied = @"IsStickied";
						
		}

		#endregion
	}

}

