using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ImportForum class.
    /// </summary>
    [Serializable]
    public partial class ImportForumCollection : ReadOnlyList<ImportForum, ImportForumCollection>
    {        
        public ImportForumCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the IMPORT_Forums view.
    /// </summary>
    [Serializable]
    public partial class ImportForum : ReadOnlyRecord<ImportForum> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("IMPORT_Forums", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarForumID = new TableSchema.TableColumn(schema);
                colvarForumID.ColumnName = "ForumID";
                colvarForumID.DataType = DbType.Int32;
                colvarForumID.MaxLength = 0;
                colvarForumID.AutoIncrement = false;
                colvarForumID.IsNullable = false;
                colvarForumID.IsPrimaryKey = false;
                colvarForumID.IsForeignKey = false;
                colvarForumID.IsReadOnly = false;
                
                schema.Columns.Add(colvarForumID);
                
                TableSchema.TableColumn colvarForumName = new TableSchema.TableColumn(schema);
                colvarForumName.ColumnName = "ForumName";
                colvarForumName.DataType = DbType.String;
                colvarForumName.MaxLength = 256;
                colvarForumName.AutoIncrement = false;
                colvarForumName.IsNullable = true;
                colvarForumName.IsPrimaryKey = false;
                colvarForumName.IsForeignKey = false;
                colvarForumName.IsReadOnly = false;
                
                schema.Columns.Add(colvarForumName);
                
                TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
                colvarDescription.ColumnName = "Description";
                colvarDescription.DataType = DbType.String;
                colvarDescription.MaxLength = 1000;
                colvarDescription.AutoIncrement = false;
                colvarDescription.IsNullable = true;
                colvarDescription.IsPrimaryKey = false;
                colvarDescription.IsForeignKey = false;
                colvarDescription.IsReadOnly = false;
                
                schema.Columns.Add(colvarDescription);
                
                TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
                colvarCreatedOn.ColumnName = "CreatedOn";
                colvarCreatedOn.DataType = DbType.DateTime;
                colvarCreatedOn.MaxLength = 0;
                colvarCreatedOn.AutoIncrement = false;
                colvarCreatedOn.IsNullable = false;
                colvarCreatedOn.IsPrimaryKey = false;
                colvarCreatedOn.IsForeignKey = false;
                colvarCreatedOn.IsReadOnly = false;
                
                schema.Columns.Add(colvarCreatedOn);
                
                TableSchema.TableColumn colvarModifiedOn = new TableSchema.TableColumn(schema);
                colvarModifiedOn.ColumnName = "ModifiedOn";
                colvarModifiedOn.DataType = DbType.DateTime;
                colvarModifiedOn.MaxLength = 0;
                colvarModifiedOn.AutoIncrement = false;
                colvarModifiedOn.IsNullable = false;
                colvarModifiedOn.IsPrimaryKey = false;
                colvarModifiedOn.IsForeignKey = false;
                colvarModifiedOn.IsReadOnly = false;
                
                schema.Columns.Add(colvarModifiedOn);
                
                TableSchema.TableColumn colvarGroupID = new TableSchema.TableColumn(schema);
                colvarGroupID.ColumnName = "GroupID";
                colvarGroupID.DataType = DbType.Int32;
                colvarGroupID.MaxLength = 0;
                colvarGroupID.AutoIncrement = false;
                colvarGroupID.IsNullable = false;
                colvarGroupID.IsPrimaryKey = false;
                colvarGroupID.IsForeignKey = false;
                colvarGroupID.IsReadOnly = false;
                
                schema.Columns.Add(colvarGroupID);
                
                TableSchema.TableColumn colvarForumUrl = new TableSchema.TableColumn(schema);
                colvarForumUrl.ColumnName = "ForumUrl";
                colvarForumUrl.DataType = DbType.String;
                colvarForumUrl.MaxLength = 1;
                colvarForumUrl.AutoIncrement = false;
                colvarForumUrl.IsNullable = false;
                colvarForumUrl.IsPrimaryKey = false;
                colvarForumUrl.IsForeignKey = false;
                colvarForumUrl.IsReadOnly = false;
                
                schema.Columns.Add(colvarForumUrl);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("IMPORT_Forums",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ImportForum()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ImportForum(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ImportForum(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ImportForum(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("ForumID")]
        public int ForumID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ForumID");
		    }

            set 
		    {
			    SetColumnValue("ForumID", value);
            }

        }

	      
        [XmlAttribute("ForumName")]
        public string ForumName 
	    {
		    get
		    {
			    return GetColumnValue<string>("ForumName");
		    }

            set 
		    {
			    SetColumnValue("ForumName", value);
            }

        }

	      
        [XmlAttribute("Description")]
        public string Description 
	    {
		    get
		    {
			    return GetColumnValue<string>("Description");
		    }

            set 
		    {
			    SetColumnValue("Description", value);
            }

        }

	      
        [XmlAttribute("CreatedOn")]
        public DateTime CreatedOn 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("CreatedOn");
		    }

            set 
		    {
			    SetColumnValue("CreatedOn", value);
            }

        }

	      
        [XmlAttribute("ModifiedOn")]
        public DateTime ModifiedOn 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("ModifiedOn");
		    }

            set 
		    {
			    SetColumnValue("ModifiedOn", value);
            }

        }

	      
        [XmlAttribute("GroupID")]
        public int GroupID 
	    {
		    get
		    {
			    return GetColumnValue<int>("GroupID");
		    }

            set 
		    {
			    SetColumnValue("GroupID", value);
            }

        }

	      
        [XmlAttribute("ForumUrl")]
        public string ForumUrl 
	    {
		    get
		    {
			    return GetColumnValue<string>("ForumUrl");
		    }

            set 
		    {
			    SetColumnValue("ForumUrl", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string ForumID = @"ForumID";
            
            public static string ForumName = @"ForumName";
            
            public static string Description = @"Description";
            
            public static string CreatedOn = @"CreatedOn";
            
            public static string ModifiedOn = @"ModifiedOn";
            
            public static string GroupID = @"GroupID";
            
            public static string ForumUrl = @"ForumUrl";
            
	    }

	    #endregion
    }

}

