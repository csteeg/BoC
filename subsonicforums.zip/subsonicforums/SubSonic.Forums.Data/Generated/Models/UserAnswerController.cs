using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_User_Answer
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class UserAnswerController
    {
        // Preload our schema..
        UserAnswer thisSchemaLoad = new UserAnswer();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public UserAnswerCollection FetchAll()
        {
            UserAnswerCollection coll = new UserAnswerCollection();
            Query qry = new Query(UserAnswer.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public UserAnswerCollection FetchByID(object AnswerID)
        {
            UserAnswerCollection coll = new UserAnswerCollection().Where("AnswerID", AnswerID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public UserAnswerCollection FetchByQuery(Query qry)
        {
            UserAnswerCollection coll = new UserAnswerCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object AnswerID)
        {
            return (UserAnswer.Delete(AnswerID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object AnswerID)
        {
            return (UserAnswer.Destroy(AnswerID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(int PostID,int ThreadTypeResponseID,DateTime CreatedOn,string CreatedBy,int Props)
	    {
		    UserAnswer item = new UserAnswer();
		    
            item.PostID = PostID;
            
            item.ThreadTypeResponseID = ThreadTypeResponseID;
            
            item.CreatedOn = CreatedOn;
            
            item.CreatedBy = CreatedBy;
            
            item.Props = Props;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int AnswerID,int PostID,int ThreadTypeResponseID,DateTime CreatedOn,string CreatedBy,int Props)
	    {
		    UserAnswer item = new UserAnswer();
		    
				item.AnswerID = AnswerID;
				
				item.PostID = PostID;
				
				item.ThreadTypeResponseID = ThreadTypeResponseID;
				
				item.CreatedOn = CreatedOn;
				
				item.CreatedBy = CreatedBy;
				
				item.Props = Props;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

