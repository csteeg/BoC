using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the UserWatchedThread class.
	/// </summary>
	[Serializable]
	public partial class UserWatchedThreadCollection : ActiveList<UserWatchedThread, UserWatchedThreadCollection> 
	{	   
		public UserWatchedThreadCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_User_WatchedThread table.
	/// </summary>
	[Serializable]
	public partial class UserWatchedThread : ActiveRecord<UserWatchedThread>
	{
		#region .ctors and Default Settings
		
		public UserWatchedThread()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public UserWatchedThread(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public UserWatchedThread(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public UserWatchedThread(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_User_WatchedThread", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
				colvarUserName.ColumnName = "UserName";
				colvarUserName.DataType = DbType.String;
				colvarUserName.MaxLength = 50;
				colvarUserName.AutoIncrement = false;
				colvarUserName.IsNullable = false;
				colvarUserName.IsPrimaryKey = true;
				colvarUserName.IsForeignKey = true;
				colvarUserName.IsReadOnly = false;
				colvarUserName.DefaultSetting = @"";
				
					colvarUserName.ForeignKeyTableName = "SS_UserProfile";
				schema.Columns.Add(colvarUserName);
				
				TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
				colvarThreadID.ColumnName = "ThreadID";
				colvarThreadID.DataType = DbType.Int32;
				colvarThreadID.MaxLength = 0;
				colvarThreadID.AutoIncrement = false;
				colvarThreadID.IsNullable = false;
				colvarThreadID.IsPrimaryKey = true;
				colvarThreadID.IsForeignKey = true;
				colvarThreadID.IsReadOnly = false;
				colvarThreadID.DefaultSetting = @"";
				
					colvarThreadID.ForeignKeyTableName = "SS_Thread";
				schema.Columns.Add(colvarThreadID);
				
				TableSchema.TableColumn colvarThreadUrl = new TableSchema.TableColumn(schema);
				colvarThreadUrl.ColumnName = "ThreadUrl";
				colvarThreadUrl.DataType = DbType.String;
				colvarThreadUrl.MaxLength = 50;
				colvarThreadUrl.AutoIncrement = false;
				colvarThreadUrl.IsNullable = false;
				colvarThreadUrl.IsPrimaryKey = false;
				colvarThreadUrl.IsForeignKey = false;
				colvarThreadUrl.IsReadOnly = false;
				colvarThreadUrl.DefaultSetting = @"";
				colvarThreadUrl.ForeignKeyTableName = "";
				schema.Columns.Add(colvarThreadUrl);
				
				TableSchema.TableColumn colvarEmailNotify = new TableSchema.TableColumn(schema);
				colvarEmailNotify.ColumnName = "EmailNotify";
				colvarEmailNotify.DataType = DbType.Boolean;
				colvarEmailNotify.MaxLength = 0;
				colvarEmailNotify.AutoIncrement = false;
				colvarEmailNotify.IsNullable = false;
				colvarEmailNotify.IsPrimaryKey = false;
				colvarEmailNotify.IsForeignKey = false;
				colvarEmailNotify.IsReadOnly = false;
				
						colvarEmailNotify.DefaultSetting = @"((1))";
				colvarEmailNotify.ForeignKeyTableName = "";
				schema.Columns.Add(colvarEmailNotify);
				
				TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
				colvarCreatedOn.ColumnName = "CreatedOn";
				colvarCreatedOn.DataType = DbType.DateTime;
				colvarCreatedOn.MaxLength = 0;
				colvarCreatedOn.AutoIncrement = false;
				colvarCreatedOn.IsNullable = true;
				colvarCreatedOn.IsPrimaryKey = false;
				colvarCreatedOn.IsForeignKey = false;
				colvarCreatedOn.IsReadOnly = false;
				
						colvarCreatedOn.DefaultSetting = @"(getdate())";
				colvarCreatedOn.ForeignKeyTableName = "";
				schema.Columns.Add(colvarCreatedOn);
				
				TableSchema.TableColumn colvarAnswerOnly = new TableSchema.TableColumn(schema);
				colvarAnswerOnly.ColumnName = "AnswerOnly";
				colvarAnswerOnly.DataType = DbType.Boolean;
				colvarAnswerOnly.MaxLength = 0;
				colvarAnswerOnly.AutoIncrement = false;
				colvarAnswerOnly.IsNullable = false;
				colvarAnswerOnly.IsPrimaryKey = false;
				colvarAnswerOnly.IsForeignKey = false;
				colvarAnswerOnly.IsReadOnly = false;
				
						colvarAnswerOnly.DefaultSetting = @"((0))";
				colvarAnswerOnly.ForeignKeyTableName = "";
				schema.Columns.Add(colvarAnswerOnly);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_User_WatchedThread",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("UserName")]
		public string UserName 
		{
			get { return GetColumnValue<string>("UserName"); }

			set { SetColumnValue("UserName", value); }

		}

		  
		[XmlAttribute("ThreadID")]
		public int ThreadID 
		{
			get { return GetColumnValue<int>("ThreadID"); }

			set { SetColumnValue("ThreadID", value); }

		}

		  
		[XmlAttribute("ThreadUrl")]
		public string ThreadUrl 
		{
			get { return GetColumnValue<string>("ThreadUrl"); }

			set { SetColumnValue("ThreadUrl", value); }

		}

		  
		[XmlAttribute("EmailNotify")]
		public bool EmailNotify 
		{
			get { return GetColumnValue<bool>("EmailNotify"); }

			set { SetColumnValue("EmailNotify", value); }

		}

		  
		[XmlAttribute("CreatedOn")]
		public DateTime? CreatedOn 
		{
			get { return GetColumnValue<DateTime?>("CreatedOn"); }

			set { SetColumnValue("CreatedOn", value); }

		}

		  
		[XmlAttribute("AnswerOnly")]
		public bool AnswerOnly 
		{
			get { return GetColumnValue<bool>("AnswerOnly"); }

			set { SetColumnValue("AnswerOnly", value); }

		}

		
		#endregion
		
		
			
		
		#region ForeignKey Properties
		
		/// <summary>
		/// Returns a Thread ActiveRecord object related to this UserWatchedThread
		/// 
		/// </summary>
		public SubSonic.Forums.Thread Thread
		{
			get { return SubSonic.Forums.Thread.FetchByID(this.ThreadID); }

			set { SetColumnValue("ThreadID", value.ThreadID); }

		}

		
		
		/// <summary>
		/// Returns a UserProfile ActiveRecord object related to this UserWatchedThread
		/// 
		/// </summary>
		public SubSonic.Forums.UserProfile UserProfile
		{
			get { return SubSonic.Forums.UserProfile.FetchByID(this.UserName); }

			set { SetColumnValue("UserName", value.UserName); }

		}

		
		
		#endregion
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varUserName,int varThreadID,string varThreadUrl,bool varEmailNotify,DateTime? varCreatedOn,bool varAnswerOnly)
		{
			UserWatchedThread item = new UserWatchedThread();
			
			item.UserName = varUserName;
			
			item.ThreadID = varThreadID;
			
			item.ThreadUrl = varThreadUrl;
			
			item.EmailNotify = varEmailNotify;
			
			item.CreatedOn = varCreatedOn;
			
			item.AnswerOnly = varAnswerOnly;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(string varUserName,int varThreadID,string varThreadUrl,bool varEmailNotify,DateTime? varCreatedOn,bool varAnswerOnly)
		{
			UserWatchedThread item = new UserWatchedThread();
			
				item.UserName = varUserName;
				
				item.ThreadID = varThreadID;
				
				item.ThreadUrl = varThreadUrl;
				
				item.EmailNotify = varEmailNotify;
				
				item.CreatedOn = varCreatedOn;
				
				item.AnswerOnly = varAnswerOnly;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string UserName = @"UserName";
			 public static string ThreadID = @"ThreadID";
			 public static string ThreadUrl = @"ThreadUrl";
			 public static string EmailNotify = @"EmailNotify";
			 public static string CreatedOn = @"CreatedOn";
			 public static string AnswerOnly = @"AnswerOnly";
						
		}

		#endregion
	}

}

