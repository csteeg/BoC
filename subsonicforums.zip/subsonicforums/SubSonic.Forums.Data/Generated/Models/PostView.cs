using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the PostView class.
    /// </summary>
    [Serializable]
    public partial class PostViewCollection : ReadOnlyList<PostView, PostViewCollection>
    {        
        public PostViewCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the SS_PostView view.
    /// </summary>
    [Serializable]
    public partial class PostView : ReadOnlyRecord<PostView> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("SS_PostView", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
                colvarThreadID.ColumnName = "ThreadID";
                colvarThreadID.DataType = DbType.Int32;
                colvarThreadID.MaxLength = 0;
                colvarThreadID.AutoIncrement = false;
                colvarThreadID.IsNullable = false;
                colvarThreadID.IsPrimaryKey = false;
                colvarThreadID.IsForeignKey = false;
                colvarThreadID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadID);
                
                TableSchema.TableColumn colvarSubject = new TableSchema.TableColumn(schema);
                colvarSubject.ColumnName = "Subject";
                colvarSubject.DataType = DbType.String;
                colvarSubject.MaxLength = 250;
                colvarSubject.AutoIncrement = false;
                colvarSubject.IsNullable = false;
                colvarSubject.IsPrimaryKey = false;
                colvarSubject.IsForeignKey = false;
                colvarSubject.IsReadOnly = false;
                
                schema.Columns.Add(colvarSubject);
                
                TableSchema.TableColumn colvarPostType = new TableSchema.TableColumn(schema);
                colvarPostType.ColumnName = "PostType";
                colvarPostType.DataType = DbType.String;
                colvarPostType.MaxLength = 50;
                colvarPostType.AutoIncrement = false;
                colvarPostType.IsNullable = false;
                colvarPostType.IsPrimaryKey = false;
                colvarPostType.IsForeignKey = false;
                colvarPostType.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostType);
                
                TableSchema.TableColumn colvarPostTypeID = new TableSchema.TableColumn(schema);
                colvarPostTypeID.ColumnName = "PostTypeID";
                colvarPostTypeID.DataType = DbType.Int32;
                colvarPostTypeID.MaxLength = 0;
                colvarPostTypeID.AutoIncrement = false;
                colvarPostTypeID.IsNullable = false;
                colvarPostTypeID.IsPrimaryKey = false;
                colvarPostTypeID.IsForeignKey = false;
                colvarPostTypeID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostTypeID);
                
                TableSchema.TableColumn colvarPostGUID = new TableSchema.TableColumn(schema);
                colvarPostGUID.ColumnName = "PostGUID";
                colvarPostGUID.DataType = DbType.Guid;
                colvarPostGUID.MaxLength = 0;
                colvarPostGUID.AutoIncrement = false;
                colvarPostGUID.IsNullable = false;
                colvarPostGUID.IsPrimaryKey = false;
                colvarPostGUID.IsForeignKey = false;
                colvarPostGUID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostGUID);
                
                TableSchema.TableColumn colvarFormattedPostText = new TableSchema.TableColumn(schema);
                colvarFormattedPostText.ColumnName = "FormattedPostText";
                colvarFormattedPostText.DataType = DbType.String;
                colvarFormattedPostText.MaxLength = -1;
                colvarFormattedPostText.AutoIncrement = false;
                colvarFormattedPostText.IsNullable = true;
                colvarFormattedPostText.IsPrimaryKey = false;
                colvarFormattedPostText.IsForeignKey = false;
                colvarFormattedPostText.IsReadOnly = false;
                
                schema.Columns.Add(colvarFormattedPostText);
                
                TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
                colvarCreatedOn.ColumnName = "CreatedOn";
                colvarCreatedOn.DataType = DbType.DateTime;
                colvarCreatedOn.MaxLength = 0;
                colvarCreatedOn.AutoIncrement = false;
                colvarCreatedOn.IsNullable = false;
                colvarCreatedOn.IsPrimaryKey = false;
                colvarCreatedOn.IsForeignKey = false;
                colvarCreatedOn.IsReadOnly = false;
                
                schema.Columns.Add(colvarCreatedOn);
                
                TableSchema.TableColumn colvarCreatedBy = new TableSchema.TableColumn(schema);
                colvarCreatedBy.ColumnName = "CreatedBy";
                colvarCreatedBy.DataType = DbType.String;
                colvarCreatedBy.MaxLength = 50;
                colvarCreatedBy.AutoIncrement = false;
                colvarCreatedBy.IsNullable = true;
                colvarCreatedBy.IsPrimaryKey = false;
                colvarCreatedBy.IsForeignKey = false;
                colvarCreatedBy.IsReadOnly = false;
                
                schema.Columns.Add(colvarCreatedBy);
                
                TableSchema.TableColumn colvarPostID = new TableSchema.TableColumn(schema);
                colvarPostID.ColumnName = "PostID";
                colvarPostID.DataType = DbType.Int32;
                colvarPostID.MaxLength = 0;
                colvarPostID.AutoIncrement = false;
                colvarPostID.IsNullable = false;
                colvarPostID.IsPrimaryKey = false;
                colvarPostID.IsForeignKey = false;
                colvarPostID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostID);
                
                TableSchema.TableColumn colvarDeleted = new TableSchema.TableColumn(schema);
                colvarDeleted.ColumnName = "Deleted";
                colvarDeleted.DataType = DbType.Boolean;
                colvarDeleted.MaxLength = 0;
                colvarDeleted.AutoIncrement = false;
                colvarDeleted.IsNullable = false;
                colvarDeleted.IsPrimaryKey = false;
                colvarDeleted.IsForeignKey = false;
                colvarDeleted.IsReadOnly = false;
                
                schema.Columns.Add(colvarDeleted);
                
                TableSchema.TableColumn colvarSignature = new TableSchema.TableColumn(schema);
                colvarSignature.ColumnName = "Signature";
                colvarSignature.DataType = DbType.String;
                colvarSignature.MaxLength = 150;
                colvarSignature.AutoIncrement = false;
                colvarSignature.IsNullable = true;
                colvarSignature.IsPrimaryKey = false;
                colvarSignature.IsForeignKey = false;
                colvarSignature.IsReadOnly = false;
                
                schema.Columns.Add(colvarSignature);
                
                TableSchema.TableColumn colvarPostDesignation = new TableSchema.TableColumn(schema);
                colvarPostDesignation.ColumnName = "PostDesignation";
                colvarPostDesignation.DataType = DbType.String;
                colvarPostDesignation.MaxLength = 50;
                colvarPostDesignation.AutoIncrement = false;
                colvarPostDesignation.IsNullable = true;
                colvarPostDesignation.IsPrimaryKey = false;
                colvarPostDesignation.IsForeignKey = false;
                colvarPostDesignation.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostDesignation);
                
                TableSchema.TableColumn colvarResponse = new TableSchema.TableColumn(schema);
                colvarResponse.ColumnName = "Response";
                colvarResponse.DataType = DbType.String;
                colvarResponse.MaxLength = 50;
                colvarResponse.AutoIncrement = false;
                colvarResponse.IsNullable = true;
                colvarResponse.IsPrimaryKey = false;
                colvarResponse.IsForeignKey = false;
                colvarResponse.IsReadOnly = false;
                
                schema.Columns.Add(colvarResponse);
                
                TableSchema.TableColumn colvarAuthorEmail = new TableSchema.TableColumn(schema);
                colvarAuthorEmail.ColumnName = "AuthorEmail";
                colvarAuthorEmail.DataType = DbType.String;
                colvarAuthorEmail.MaxLength = 50;
                colvarAuthorEmail.AutoIncrement = false;
                colvarAuthorEmail.IsNullable = false;
                colvarAuthorEmail.IsPrimaryKey = false;
                colvarAuthorEmail.IsForeignKey = false;
                colvarAuthorEmail.IsReadOnly = false;
                
                schema.Columns.Add(colvarAuthorEmail);
                
                TableSchema.TableColumn colvarProps = new TableSchema.TableColumn(schema);
                colvarProps.ColumnName = "Props";
                colvarProps.DataType = DbType.Int32;
                colvarProps.MaxLength = 0;
                colvarProps.AutoIncrement = false;
                colvarProps.IsNullable = false;
                colvarProps.IsPrimaryKey = false;
                colvarProps.IsForeignKey = false;
                colvarProps.IsReadOnly = false;
                
                schema.Columns.Add(colvarProps);
                
                TableSchema.TableColumn colvarPostText = new TableSchema.TableColumn(schema);
                colvarPostText.ColumnName = "PostText";
                colvarPostText.DataType = DbType.String;
                colvarPostText.MaxLength = -1;
                colvarPostText.AutoIncrement = false;
                colvarPostText.IsNullable = false;
                colvarPostText.IsPrimaryKey = false;
                colvarPostText.IsForeignKey = false;
                colvarPostText.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostText);
                
                TableSchema.TableColumn colvarUserRoles = new TableSchema.TableColumn(schema);
                colvarUserRoles.ColumnName = "UserRoles";
                colvarUserRoles.DataType = DbType.String;
                colvarUserRoles.MaxLength = 250;
                colvarUserRoles.AutoIncrement = false;
                colvarUserRoles.IsNullable = true;
                colvarUserRoles.IsPrimaryKey = false;
                colvarUserRoles.IsForeignKey = false;
                colvarUserRoles.IsReadOnly = false;
                
                schema.Columns.Add(colvarUserRoles);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("SS_PostView",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public PostView()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public PostView(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public PostView(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public PostView(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("ThreadID")]
        public int ThreadID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ThreadID");
		    }

            set 
		    {
			    SetColumnValue("ThreadID", value);
            }

        }

	      
        [XmlAttribute("Subject")]
        public string Subject 
	    {
		    get
		    {
			    return GetColumnValue<string>("Subject");
		    }

            set 
		    {
			    SetColumnValue("Subject", value);
            }

        }

	      
        [XmlAttribute("PostType")]
        public string PostType 
	    {
		    get
		    {
			    return GetColumnValue<string>("PostType");
		    }

            set 
		    {
			    SetColumnValue("PostType", value);
            }

        }

	      
        [XmlAttribute("PostTypeID")]
        public int PostTypeID 
	    {
		    get
		    {
			    return GetColumnValue<int>("PostTypeID");
		    }

            set 
		    {
			    SetColumnValue("PostTypeID", value);
            }

        }

	      
        [XmlAttribute("PostGUID")]
        public Guid PostGUID 
	    {
		    get
		    {
			    return GetColumnValue<Guid>("PostGUID");
		    }

            set 
		    {
			    SetColumnValue("PostGUID", value);
            }

        }

	      
        [XmlAttribute("FormattedPostText")]
        public string FormattedPostText 
	    {
		    get
		    {
			    return GetColumnValue<string>("FormattedPostText");
		    }

            set 
		    {
			    SetColumnValue("FormattedPostText", value);
            }

        }

	      
        [XmlAttribute("CreatedOn")]
        public DateTime CreatedOn 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("CreatedOn");
		    }

            set 
		    {
			    SetColumnValue("CreatedOn", value);
            }

        }

	      
        [XmlAttribute("CreatedBy")]
        public string CreatedBy 
	    {
		    get
		    {
			    return GetColumnValue<string>("CreatedBy");
		    }

            set 
		    {
			    SetColumnValue("CreatedBy", value);
            }

        }

	      
        [XmlAttribute("PostID")]
        public int PostID 
	    {
		    get
		    {
			    return GetColumnValue<int>("PostID");
		    }

            set 
		    {
			    SetColumnValue("PostID", value);
            }

        }

	      
        [XmlAttribute("Deleted")]
        public bool Deleted 
	    {
		    get
		    {
			    return GetColumnValue<bool>("Deleted");
		    }

            set 
		    {
			    SetColumnValue("Deleted", value);
            }

        }

	      
        [XmlAttribute("Signature")]
        public string Signature 
	    {
		    get
		    {
			    return GetColumnValue<string>("Signature");
		    }

            set 
		    {
			    SetColumnValue("Signature", value);
            }

        }

	      
        [XmlAttribute("PostDesignation")]
        public string PostDesignation 
	    {
		    get
		    {
			    return GetColumnValue<string>("PostDesignation");
		    }

            set 
		    {
			    SetColumnValue("PostDesignation", value);
            }

        }

	      
        [XmlAttribute("Response")]
        public string Response 
	    {
		    get
		    {
			    return GetColumnValue<string>("Response");
		    }

            set 
		    {
			    SetColumnValue("Response", value);
            }

        }

	      
        [XmlAttribute("AuthorEmail")]
        public string AuthorEmail 
	    {
		    get
		    {
			    return GetColumnValue<string>("AuthorEmail");
		    }

            set 
		    {
			    SetColumnValue("AuthorEmail", value);
            }

        }

	      
        [XmlAttribute("Props")]
        public int Props 
	    {
		    get
		    {
			    return GetColumnValue<int>("Props");
		    }

            set 
		    {
			    SetColumnValue("Props", value);
            }

        }

	      
        [XmlAttribute("PostText")]
        public string PostText 
	    {
		    get
		    {
			    return GetColumnValue<string>("PostText");
		    }

            set 
		    {
			    SetColumnValue("PostText", value);
            }

        }

	      
        [XmlAttribute("UserRoles")]
        public string UserRoles 
	    {
		    get
		    {
			    return GetColumnValue<string>("UserRoles");
		    }

            set 
		    {
			    SetColumnValue("UserRoles", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string ThreadID = @"ThreadID";
            
            public static string Subject = @"Subject";
            
            public static string PostType = @"PostType";
            
            public static string PostTypeID = @"PostTypeID";
            
            public static string PostGUID = @"PostGUID";
            
            public static string FormattedPostText = @"FormattedPostText";
            
            public static string CreatedOn = @"CreatedOn";
            
            public static string CreatedBy = @"CreatedBy";
            
            public static string PostID = @"PostID";
            
            public static string Deleted = @"Deleted";
            
            public static string Signature = @"Signature";
            
            public static string PostDesignation = @"PostDesignation";
            
            public static string Response = @"Response";
            
            public static string AuthorEmail = @"AuthorEmail";
            
            public static string Props = @"Props";
            
            public static string PostText = @"PostText";
            
            public static string UserRoles = @"UserRoles";
            
	    }

	    #endregion
    }

}

