using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the ForumRole class.
	/// </summary>
	[Serializable]
	public partial class ForumRoleCollection : ActiveList<ForumRole, ForumRoleCollection> 
	{	   
		public ForumRoleCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_ForumRole table.
	/// </summary>
	[Serializable]
	public partial class ForumRole : ActiveRecord<ForumRole>
	{
		#region .ctors and Default Settings
		
		public ForumRole()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public ForumRole(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public ForumRole(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public ForumRole(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_ForumRole", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarRoleID = new TableSchema.TableColumn(schema);
				colvarRoleID.ColumnName = "RoleID";
				colvarRoleID.DataType = DbType.Int32;
				colvarRoleID.MaxLength = 0;
				colvarRoleID.AutoIncrement = true;
				colvarRoleID.IsNullable = false;
				colvarRoleID.IsPrimaryKey = true;
				colvarRoleID.IsForeignKey = false;
				colvarRoleID.IsReadOnly = false;
				colvarRoleID.DefaultSetting = @"";
				colvarRoleID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarRoleID);
				
				TableSchema.TableColumn colvarRoleName = new TableSchema.TableColumn(schema);
				colvarRoleName.ColumnName = "RoleName";
				colvarRoleName.DataType = DbType.String;
				colvarRoleName.MaxLength = 50;
				colvarRoleName.AutoIncrement = false;
				colvarRoleName.IsNullable = true;
				colvarRoleName.IsPrimaryKey = false;
				colvarRoleName.IsForeignKey = false;
				colvarRoleName.IsReadOnly = false;
				colvarRoleName.DefaultSetting = @"";
				colvarRoleName.ForeignKeyTableName = "";
				schema.Columns.Add(colvarRoleName);
				
				TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
				colvarDescription.ColumnName = "Description";
				colvarDescription.DataType = DbType.String;
				colvarDescription.MaxLength = 500;
				colvarDescription.AutoIncrement = false;
				colvarDescription.IsNullable = true;
				colvarDescription.IsPrimaryKey = false;
				colvarDescription.IsForeignKey = false;
				colvarDescription.IsReadOnly = false;
				colvarDescription.DefaultSetting = @"";
				colvarDescription.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDescription);
				
				TableSchema.TableColumn colvarIcon = new TableSchema.TableColumn(schema);
				colvarIcon.ColumnName = "Icon";
				colvarIcon.DataType = DbType.String;
				colvarIcon.MaxLength = 50;
				colvarIcon.AutoIncrement = false;
				colvarIcon.IsNullable = true;
				colvarIcon.IsPrimaryKey = false;
				colvarIcon.IsForeignKey = false;
				colvarIcon.IsReadOnly = false;
				colvarIcon.DefaultSetting = @"";
				colvarIcon.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIcon);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_ForumRole",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("RoleID")]
		public int RoleID 
		{
			get { return GetColumnValue<int>("RoleID"); }

			set { SetColumnValue("RoleID", value); }

		}

		  
		[XmlAttribute("RoleName")]
		public string RoleName 
		{
			get { return GetColumnValue<string>("RoleName"); }

			set { SetColumnValue("RoleName", value); }

		}

		  
		[XmlAttribute("Description")]
		public string Description 
		{
			get { return GetColumnValue<string>("Description"); }

			set { SetColumnValue("Description", value); }

		}

		  
		[XmlAttribute("Icon")]
		public string Icon 
		{
			get { return GetColumnValue<string>("Icon"); }

			set { SetColumnValue("Icon", value); }

		}

		
		#endregion
		
		
		#region PrimaryKey Methods
		
		public SubSonic.Forums.UserForumRoleCollection UserForumRoleRecords()
		{
			return new SubSonic.Forums.UserForumRoleCollection().Where(UserForumRole.Columns.RoleID, RoleID).Load();
		}

		#endregion
		
			
		
		//no foreign key tables defined (0)
		
		
		
		#region Many To Many Helpers
		
		 
		public SubSonic.Forums.UserProfileCollection GetUserProfileCollection() { return ForumRole.GetUserProfileCollection(this.RoleID); }

		public static SubSonic.Forums.UserProfileCollection GetUserProfileCollection(int varRoleID)
		{
			SubSonic.QueryCommand cmd = new SubSonic.QueryCommand(
				"SELECT * FROM SS_UserProfile INNER JOIN SS_User_ForumRole ON "+
				"SS_UserProfile.UserName=SS_User_ForumRole.userName WHERE SS_User_ForumRole.roleID=@roleID", ForumRole.Schema.Provider.Name);
			
			cmd.AddParameter("@roleID", varRoleID, DbType.Int32);
			IDataReader rdr = SubSonic.DataService.GetReader(cmd);
			UserProfileCollection coll = new UserProfileCollection();
			coll.LoadAndCloseReader(rdr);
			return coll;
		}

		
		public static void SaveUserProfileMap(int varRoleID, UserProfileCollection items)
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_ForumRole WHERE roleID=@roleID", ForumRole.Schema.Provider.Name);
			cmdDel.AddParameter("@roleID", varRoleID);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (UserProfile item in items)
			{
				UserForumRole varUserForumRole = new UserForumRole();
				varUserForumRole.SetColumnValue("roleID", varRoleID);
				varUserForumRole.SetColumnValue("userName", item.GetPrimaryKeyValue());
				varUserForumRole.Save();
			}

		}

		public static void SaveUserProfileMap(int varRoleID, System.Web.UI.WebControls.ListItemCollection itemList) 
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			 QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_ForumRole WHERE roleID=@roleID", ForumRole.Schema.Provider.Name);
			cmdDel.AddParameter("@roleID", varRoleID);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (System.Web.UI.WebControls.ListItem l in itemList) 
			{
				if (l.Selected) 
				{
					UserForumRole varUserForumRole = new UserForumRole();
					varUserForumRole.SetColumnValue("roleID", varRoleID);
					varUserForumRole.SetColumnValue("userName", l.Value);
					varUserForumRole.Save();
				}

			}

		}

		public static void SaveUserProfileMap(int varRoleID , int[] itemList) 
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			 QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_ForumRole WHERE roleID=@roleID", ForumRole.Schema.Provider.Name);
			cmdDel.AddParameter("@roleID", varRoleID);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (int item in itemList) 
			{
				UserForumRole varUserForumRole = new UserForumRole();
				varUserForumRole.SetColumnValue("roleID", varRoleID);
				varUserForumRole.SetColumnValue("userName", item);
				varUserForumRole.Save();
			}

		}

		
		public static void DeleteUserProfileMap(int varRoleID) 
		{
			QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_ForumRole WHERE roleID=@roleID", ForumRole.Schema.Provider.Name);
			cmdDel.AddParameter("@roleID", varRoleID);
			DataService.ExecuteQuery(cmdDel);
		}

		
		#endregion
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varRoleName,string varDescription,string varIcon)
		{
			ForumRole item = new ForumRole();
			
			item.RoleName = varRoleName;
			
			item.Description = varDescription;
			
			item.Icon = varIcon;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varRoleID,string varRoleName,string varDescription,string varIcon)
		{
			ForumRole item = new ForumRole();
			
				item.RoleID = varRoleID;
				
				item.RoleName = varRoleName;
				
				item.Description = varDescription;
				
				item.Icon = varIcon;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string RoleID = @"RoleID";
			 public static string RoleName = @"RoleName";
			 public static string Description = @"Description";
			 public static string Icon = @"Icon";
						
		}

		#endregion
	}

}

