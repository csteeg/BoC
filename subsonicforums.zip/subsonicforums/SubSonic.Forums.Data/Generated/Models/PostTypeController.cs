using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_PostType
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class PostTypeController
    {
        // Preload our schema..
        PostType thisSchemaLoad = new PostType();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public PostTypeCollection FetchAll()
        {
            PostTypeCollection coll = new PostTypeCollection();
            Query qry = new Query(PostType.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public PostTypeCollection FetchByID(object PostTypeID)
        {
            PostTypeCollection coll = new PostTypeCollection().Where("PostTypeID", PostTypeID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public PostTypeCollection FetchByQuery(Query qry)
        {
            PostTypeCollection coll = new PostTypeCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object PostTypeID)
        {
            return (PostType.Delete(PostTypeID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object PostTypeID)
        {
            return (PostType.Destroy(PostTypeID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string Description,bool IsResponse,int ListOrder)
	    {
		    PostType item = new PostType();
		    
            item.Description = Description;
            
            item.IsResponse = IsResponse;
            
            item.ListOrder = ListOrder;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int PostTypeID,string Description,bool IsResponse,int ListOrder)
	    {
		    PostType item = new PostType();
		    
				item.PostTypeID = PostTypeID;
				
				item.Description = Description;
				
				item.IsResponse = IsResponse;
				
				item.ListOrder = ListOrder;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

