using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_ForumRole
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class ForumRoleController
    {
        // Preload our schema..
        ForumRole thisSchemaLoad = new ForumRole();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public ForumRoleCollection FetchAll()
        {
            ForumRoleCollection coll = new ForumRoleCollection();
            Query qry = new Query(ForumRole.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public ForumRoleCollection FetchByID(object RoleID)
        {
            ForumRoleCollection coll = new ForumRoleCollection().Where("RoleID", RoleID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public ForumRoleCollection FetchByQuery(Query qry)
        {
            ForumRoleCollection coll = new ForumRoleCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object RoleID)
        {
            return (ForumRole.Delete(RoleID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object RoleID)
        {
            return (ForumRole.Destroy(RoleID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string RoleName,string Description,string Icon)
	    {
		    ForumRole item = new ForumRole();
		    
            item.RoleName = RoleName;
            
            item.Description = Description;
            
            item.Icon = Icon;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int RoleID,string RoleName,string Description,string Icon)
	    {
		    ForumRole item = new ForumRole();
		    
				item.RoleID = RoleID;
				
				item.RoleName = RoleName;
				
				item.Description = Description;
				
				item.Icon = Icon;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

