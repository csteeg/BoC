using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the UserReadThread class.
	/// </summary>
	[Serializable]
	public partial class UserReadThreadCollection : ActiveList<UserReadThread, UserReadThreadCollection> 
	{	   
		public UserReadThreadCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_User_ReadThread table.
	/// </summary>
	[Serializable]
	public partial class UserReadThread : ActiveRecord<UserReadThread>
	{
		#region .ctors and Default Settings
		
		public UserReadThread()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public UserReadThread(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public UserReadThread(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public UserReadThread(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_User_ReadThread", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarReadID = new TableSchema.TableColumn(schema);
				colvarReadID.ColumnName = "ReadID";
				colvarReadID.DataType = DbType.Int32;
				colvarReadID.MaxLength = 0;
				colvarReadID.AutoIncrement = true;
				colvarReadID.IsNullable = false;
				colvarReadID.IsPrimaryKey = true;
				colvarReadID.IsForeignKey = false;
				colvarReadID.IsReadOnly = false;
				colvarReadID.DefaultSetting = @"";
				colvarReadID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarReadID);
				
				TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
				colvarUserName.ColumnName = "UserName";
				colvarUserName.DataType = DbType.String;
				colvarUserName.MaxLength = 50;
				colvarUserName.AutoIncrement = false;
				colvarUserName.IsNullable = false;
				colvarUserName.IsPrimaryKey = false;
				colvarUserName.IsForeignKey = true;
				colvarUserName.IsReadOnly = false;
				colvarUserName.DefaultSetting = @"";
				
					colvarUserName.ForeignKeyTableName = "SS_UserProfile";
				schema.Columns.Add(colvarUserName);
				
				TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
				colvarThreadID.ColumnName = "ThreadID";
				colvarThreadID.DataType = DbType.Int32;
				colvarThreadID.MaxLength = 0;
				colvarThreadID.AutoIncrement = false;
				colvarThreadID.IsNullable = false;
				colvarThreadID.IsPrimaryKey = false;
				colvarThreadID.IsForeignKey = false;
				colvarThreadID.IsReadOnly = false;
				colvarThreadID.DefaultSetting = @"";
				colvarThreadID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarThreadID);
				
				TableSchema.TableColumn colvarReadDate = new TableSchema.TableColumn(schema);
				colvarReadDate.ColumnName = "ReadDate";
				colvarReadDate.DataType = DbType.DateTime;
				colvarReadDate.MaxLength = 0;
				colvarReadDate.AutoIncrement = false;
				colvarReadDate.IsNullable = false;
				colvarReadDate.IsPrimaryKey = false;
				colvarReadDate.IsForeignKey = false;
				colvarReadDate.IsReadOnly = false;
				
						colvarReadDate.DefaultSetting = @"(getdate())";
				colvarReadDate.ForeignKeyTableName = "";
				schema.Columns.Add(colvarReadDate);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_User_ReadThread",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("ReadID")]
		public int ReadID 
		{
			get { return GetColumnValue<int>("ReadID"); }

			set { SetColumnValue("ReadID", value); }

		}

		  
		[XmlAttribute("UserName")]
		public string UserName 
		{
			get { return GetColumnValue<string>("UserName"); }

			set { SetColumnValue("UserName", value); }

		}

		  
		[XmlAttribute("ThreadID")]
		public int ThreadID 
		{
			get { return GetColumnValue<int>("ThreadID"); }

			set { SetColumnValue("ThreadID", value); }

		}

		  
		[XmlAttribute("ReadDate")]
		public DateTime ReadDate 
		{
			get { return GetColumnValue<DateTime>("ReadDate"); }

			set { SetColumnValue("ReadDate", value); }

		}

		
		#endregion
		
		
			
		
		#region ForeignKey Properties
		
		/// <summary>
		/// Returns a UserProfile ActiveRecord object related to this UserReadThread
		/// 
		/// </summary>
		public SubSonic.Forums.UserProfile UserProfile
		{
			get { return SubSonic.Forums.UserProfile.FetchByID(this.UserName); }

			set { SetColumnValue("UserName", value.UserName); }

		}

		
		
		#endregion
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varUserName,int varThreadID,DateTime varReadDate)
		{
			UserReadThread item = new UserReadThread();
			
			item.UserName = varUserName;
			
			item.ThreadID = varThreadID;
			
			item.ReadDate = varReadDate;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varReadID,string varUserName,int varThreadID,DateTime varReadDate)
		{
			UserReadThread item = new UserReadThread();
			
				item.ReadID = varReadID;
				
				item.UserName = varUserName;
				
				item.ThreadID = varThreadID;
				
				item.ReadDate = varReadDate;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string ReadID = @"ReadID";
			 public static string UserName = @"UserName";
			 public static string ThreadID = @"ThreadID";
			 public static string ReadDate = @"ReadDate";
						
		}

		#endregion
	}

}

