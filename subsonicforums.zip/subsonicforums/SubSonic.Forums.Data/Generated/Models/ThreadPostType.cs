using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ThreadPostType class.
    /// </summary>
    [Serializable]
    public partial class ThreadPostTypeCollection : ReadOnlyList<ThreadPostType, ThreadPostTypeCollection>
    {        
        public ThreadPostTypeCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the SS_ThreadPostType view.
    /// </summary>
    [Serializable]
    public partial class ThreadPostType : ReadOnlyRecord<ThreadPostType> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("SS_ThreadPostType", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
                colvarThreadID.ColumnName = "ThreadID";
                colvarThreadID.DataType = DbType.Int32;
                colvarThreadID.MaxLength = 0;
                colvarThreadID.AutoIncrement = false;
                colvarThreadID.IsNullable = false;
                colvarThreadID.IsPrimaryKey = false;
                colvarThreadID.IsForeignKey = false;
                colvarThreadID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadID);
                
                TableSchema.TableColumn colvarPostType = new TableSchema.TableColumn(schema);
                colvarPostType.ColumnName = "PostType";
                colvarPostType.DataType = DbType.String;
                colvarPostType.MaxLength = 50;
                colvarPostType.AutoIncrement = false;
                colvarPostType.IsNullable = false;
                colvarPostType.IsPrimaryKey = false;
                colvarPostType.IsForeignKey = false;
                colvarPostType.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostType);
                
                TableSchema.TableColumn colvarSubject = new TableSchema.TableColumn(schema);
                colvarSubject.ColumnName = "Subject";
                colvarSubject.DataType = DbType.String;
                colvarSubject.MaxLength = 250;
                colvarSubject.AutoIncrement = false;
                colvarSubject.IsNullable = false;
                colvarSubject.IsPrimaryKey = false;
                colvarSubject.IsForeignKey = false;
                colvarSubject.IsReadOnly = false;
                
                schema.Columns.Add(colvarSubject);
                
                TableSchema.TableColumn colvarThreadUrl = new TableSchema.TableColumn(schema);
                colvarThreadUrl.ColumnName = "ThreadUrl";
                colvarThreadUrl.DataType = DbType.String;
                colvarThreadUrl.MaxLength = 50;
                colvarThreadUrl.AutoIncrement = false;
                colvarThreadUrl.IsNullable = false;
                colvarThreadUrl.IsPrimaryKey = false;
                colvarThreadUrl.IsForeignKey = false;
                colvarThreadUrl.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadUrl);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("SS_ThreadPostType",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ThreadPostType()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ThreadPostType(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ThreadPostType(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ThreadPostType(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("ThreadID")]
        public int ThreadID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ThreadID");
		    }

            set 
		    {
			    SetColumnValue("ThreadID", value);
            }

        }

	      
        [XmlAttribute("PostType")]
        public string PostType 
	    {
		    get
		    {
			    return GetColumnValue<string>("PostType");
		    }

            set 
		    {
			    SetColumnValue("PostType", value);
            }

        }

	      
        [XmlAttribute("Subject")]
        public string Subject 
	    {
		    get
		    {
			    return GetColumnValue<string>("Subject");
		    }

            set 
		    {
			    SetColumnValue("Subject", value);
            }

        }

	      
        [XmlAttribute("ThreadUrl")]
        public string ThreadUrl 
	    {
		    get
		    {
			    return GetColumnValue<string>("ThreadUrl");
		    }

            set 
		    {
			    SetColumnValue("ThreadUrl", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string ThreadID = @"ThreadID";
            
            public static string PostType = @"PostType";
            
            public static string Subject = @"Subject";
            
            public static string ThreadUrl = @"ThreadUrl";
            
	    }

	    #endregion
    }

}

