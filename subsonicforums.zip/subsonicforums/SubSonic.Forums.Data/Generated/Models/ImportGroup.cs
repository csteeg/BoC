using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ImportGroup class.
    /// </summary>
    [Serializable]
    public partial class ImportGroupCollection : ReadOnlyList<ImportGroup, ImportGroupCollection>
    {        
        public ImportGroupCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the IMPORT_Groups view.
    /// </summary>
    [Serializable]
    public partial class ImportGroup : ReadOnlyRecord<ImportGroup> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("IMPORT_Groups", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarGroupID = new TableSchema.TableColumn(schema);
                colvarGroupID.ColumnName = "GroupID";
                colvarGroupID.DataType = DbType.Int32;
                colvarGroupID.MaxLength = 0;
                colvarGroupID.AutoIncrement = false;
                colvarGroupID.IsNullable = false;
                colvarGroupID.IsPrimaryKey = false;
                colvarGroupID.IsForeignKey = false;
                colvarGroupID.IsReadOnly = false;
                
                schema.Columns.Add(colvarGroupID);
                
                TableSchema.TableColumn colvarGroupName = new TableSchema.TableColumn(schema);
                colvarGroupName.ColumnName = "GroupName";
                colvarGroupName.DataType = DbType.String;
                colvarGroupName.MaxLength = 256;
                colvarGroupName.AutoIncrement = false;
                colvarGroupName.IsNullable = true;
                colvarGroupName.IsPrimaryKey = false;
                colvarGroupName.IsForeignKey = false;
                colvarGroupName.IsReadOnly = false;
                
                schema.Columns.Add(colvarGroupName);
                
                TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
                colvarDescription.ColumnName = "Description";
                colvarDescription.DataType = DbType.String;
                colvarDescription.MaxLength = 1000;
                colvarDescription.AutoIncrement = false;
                colvarDescription.IsNullable = false;
                colvarDescription.IsPrimaryKey = false;
                colvarDescription.IsForeignKey = false;
                colvarDescription.IsReadOnly = false;
                
                schema.Columns.Add(colvarDescription);
                
                TableSchema.TableColumn colvarListOrder = new TableSchema.TableColumn(schema);
                colvarListOrder.ColumnName = "ListOrder";
                colvarListOrder.DataType = DbType.Int32;
                colvarListOrder.MaxLength = 0;
                colvarListOrder.AutoIncrement = false;
                colvarListOrder.IsNullable = false;
                colvarListOrder.IsPrimaryKey = false;
                colvarListOrder.IsForeignKey = false;
                colvarListOrder.IsReadOnly = false;
                
                schema.Columns.Add(colvarListOrder);
                
                TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
                colvarCreatedOn.ColumnName = "CreatedOn";
                colvarCreatedOn.DataType = DbType.DateTime;
                colvarCreatedOn.MaxLength = 0;
                colvarCreatedOn.AutoIncrement = false;
                colvarCreatedOn.IsNullable = false;
                colvarCreatedOn.IsPrimaryKey = false;
                colvarCreatedOn.IsForeignKey = false;
                colvarCreatedOn.IsReadOnly = false;
                
                schema.Columns.Add(colvarCreatedOn);
                
                TableSchema.TableColumn colvarModifiedOn = new TableSchema.TableColumn(schema);
                colvarModifiedOn.ColumnName = "ModifiedOn";
                colvarModifiedOn.DataType = DbType.DateTime;
                colvarModifiedOn.MaxLength = 0;
                colvarModifiedOn.AutoIncrement = false;
                colvarModifiedOn.IsNullable = false;
                colvarModifiedOn.IsPrimaryKey = false;
                colvarModifiedOn.IsForeignKey = false;
                colvarModifiedOn.IsReadOnly = false;
                
                schema.Columns.Add(colvarModifiedOn);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("IMPORT_Groups",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ImportGroup()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ImportGroup(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ImportGroup(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ImportGroup(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("GroupID")]
        public int GroupID 
	    {
		    get
		    {
			    return GetColumnValue<int>("GroupID");
		    }

            set 
		    {
			    SetColumnValue("GroupID", value);
            }

        }

	      
        [XmlAttribute("GroupName")]
        public string GroupName 
	    {
		    get
		    {
			    return GetColumnValue<string>("GroupName");
		    }

            set 
		    {
			    SetColumnValue("GroupName", value);
            }

        }

	      
        [XmlAttribute("Description")]
        public string Description 
	    {
		    get
		    {
			    return GetColumnValue<string>("Description");
		    }

            set 
		    {
			    SetColumnValue("Description", value);
            }

        }

	      
        [XmlAttribute("ListOrder")]
        public int ListOrder 
	    {
		    get
		    {
			    return GetColumnValue<int>("ListOrder");
		    }

            set 
		    {
			    SetColumnValue("ListOrder", value);
            }

        }

	      
        [XmlAttribute("CreatedOn")]
        public DateTime CreatedOn 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("CreatedOn");
		    }

            set 
		    {
			    SetColumnValue("CreatedOn", value);
            }

        }

	      
        [XmlAttribute("ModifiedOn")]
        public DateTime ModifiedOn 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("ModifiedOn");
		    }

            set 
		    {
			    SetColumnValue("ModifiedOn", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string GroupID = @"GroupID";
            
            public static string GroupName = @"GroupName";
            
            public static string Description = @"Description";
            
            public static string ListOrder = @"ListOrder";
            
            public static string CreatedOn = @"CreatedOn";
            
            public static string ModifiedOn = @"ModifiedOn";
            
	    }

	    #endregion
    }

}

