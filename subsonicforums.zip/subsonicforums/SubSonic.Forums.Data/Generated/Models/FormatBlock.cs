using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the FormatBlock class.
	/// </summary>
	[Serializable]
	public partial class FormatBlockCollection : ActiveList<FormatBlock, FormatBlockCollection> 
	{	   
		public FormatBlockCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_FormatBlock table.
	/// </summary>
	[Serializable]
	public partial class FormatBlock : ActiveRecord<FormatBlock>
	{
		#region .ctors and Default Settings
		
		public FormatBlock()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public FormatBlock(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public FormatBlock(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public FormatBlock(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_FormatBlock", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarFormatID = new TableSchema.TableColumn(schema);
				colvarFormatID.ColumnName = "FormatID";
				colvarFormatID.DataType = DbType.Int32;
				colvarFormatID.MaxLength = 0;
				colvarFormatID.AutoIncrement = true;
				colvarFormatID.IsNullable = false;
				colvarFormatID.IsPrimaryKey = true;
				colvarFormatID.IsForeignKey = false;
				colvarFormatID.IsReadOnly = false;
				colvarFormatID.DefaultSetting = @"";
				colvarFormatID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarFormatID);
				
				TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
				colvarDescription.ColumnName = "Description";
				colvarDescription.DataType = DbType.String;
				colvarDescription.MaxLength = 50;
				colvarDescription.AutoIncrement = false;
				colvarDescription.IsNullable = false;
				colvarDescription.IsPrimaryKey = false;
				colvarDescription.IsForeignKey = false;
				colvarDescription.IsReadOnly = false;
				colvarDescription.DefaultSetting = @"";
				colvarDescription.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDescription);
				
				TableSchema.TableColumn colvarDefinition = new TableSchema.TableColumn(schema);
				colvarDefinition.ColumnName = "Definition";
				colvarDefinition.DataType = DbType.String;
				colvarDefinition.MaxLength = 50;
				colvarDefinition.AutoIncrement = false;
				colvarDefinition.IsNullable = false;
				colvarDefinition.IsPrimaryKey = false;
				colvarDefinition.IsForeignKey = false;
				colvarDefinition.IsReadOnly = false;
				colvarDefinition.DefaultSetting = @"";
				colvarDefinition.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDefinition);
				
				TableSchema.TableColumn colvarStartTag = new TableSchema.TableColumn(schema);
				colvarStartTag.ColumnName = "StartTag";
				colvarStartTag.DataType = DbType.String;
				colvarStartTag.MaxLength = 50;
				colvarStartTag.AutoIncrement = false;
				colvarStartTag.IsNullable = false;
				colvarStartTag.IsPrimaryKey = false;
				colvarStartTag.IsForeignKey = false;
				colvarStartTag.IsReadOnly = false;
				colvarStartTag.DefaultSetting = @"";
				colvarStartTag.ForeignKeyTableName = "";
				schema.Columns.Add(colvarStartTag);
				
				TableSchema.TableColumn colvarEndTag = new TableSchema.TableColumn(schema);
				colvarEndTag.ColumnName = "EndTag";
				colvarEndTag.DataType = DbType.String;
				colvarEndTag.MaxLength = 50;
				colvarEndTag.AutoIncrement = false;
				colvarEndTag.IsNullable = true;
				colvarEndTag.IsPrimaryKey = false;
				colvarEndTag.IsForeignKey = false;
				colvarEndTag.IsReadOnly = false;
				colvarEndTag.DefaultSetting = @"";
				colvarEndTag.ForeignKeyTableName = "";
				schema.Columns.Add(colvarEndTag);
				
				TableSchema.TableColumn colvarReplacement = new TableSchema.TableColumn(schema);
				colvarReplacement.ColumnName = "Replacement";
				colvarReplacement.DataType = DbType.String;
				colvarReplacement.MaxLength = 500;
				colvarReplacement.AutoIncrement = false;
				colvarReplacement.IsNullable = true;
				colvarReplacement.IsPrimaryKey = false;
				colvarReplacement.IsForeignKey = false;
				colvarReplacement.IsReadOnly = false;
				colvarReplacement.DefaultSetting = @"";
				colvarReplacement.ForeignKeyTableName = "";
				schema.Columns.Add(colvarReplacement);
				
				TableSchema.TableColumn colvarStartBlockWith = new TableSchema.TableColumn(schema);
				colvarStartBlockWith.ColumnName = "StartBlockWith";
				colvarStartBlockWith.DataType = DbType.String;
				colvarStartBlockWith.MaxLength = 50;
				colvarStartBlockWith.AutoIncrement = false;
				colvarStartBlockWith.IsNullable = true;
				colvarStartBlockWith.IsPrimaryKey = false;
				colvarStartBlockWith.IsForeignKey = false;
				colvarStartBlockWith.IsReadOnly = false;
				colvarStartBlockWith.DefaultSetting = @"";
				colvarStartBlockWith.ForeignKeyTableName = "";
				schema.Columns.Add(colvarStartBlockWith);
				
				TableSchema.TableColumn colvarEndBlockWith = new TableSchema.TableColumn(schema);
				colvarEndBlockWith.ColumnName = "EndBlockWith";
				colvarEndBlockWith.DataType = DbType.String;
				colvarEndBlockWith.MaxLength = 50;
				colvarEndBlockWith.AutoIncrement = false;
				colvarEndBlockWith.IsNullable = true;
				colvarEndBlockWith.IsPrimaryKey = false;
				colvarEndBlockWith.IsForeignKey = false;
				colvarEndBlockWith.IsReadOnly = false;
				colvarEndBlockWith.DefaultSetting = @"";
				colvarEndBlockWith.ForeignKeyTableName = "";
				schema.Columns.Add(colvarEndBlockWith);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_FormatBlock",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("FormatID")]
		public int FormatID 
		{
			get { return GetColumnValue<int>("FormatID"); }

			set { SetColumnValue("FormatID", value); }

		}

		  
		[XmlAttribute("Description")]
		public string Description 
		{
			get { return GetColumnValue<string>("Description"); }

			set { SetColumnValue("Description", value); }

		}

		  
		[XmlAttribute("Definition")]
		public string Definition 
		{
			get { return GetColumnValue<string>("Definition"); }

			set { SetColumnValue("Definition", value); }

		}

		  
		[XmlAttribute("StartTag")]
		public string StartTag 
		{
			get { return GetColumnValue<string>("StartTag"); }

			set { SetColumnValue("StartTag", value); }

		}

		  
		[XmlAttribute("EndTag")]
		public string EndTag 
		{
			get { return GetColumnValue<string>("EndTag"); }

			set { SetColumnValue("EndTag", value); }

		}

		  
		[XmlAttribute("Replacement")]
		public string Replacement 
		{
			get { return GetColumnValue<string>("Replacement"); }

			set { SetColumnValue("Replacement", value); }

		}

		  
		[XmlAttribute("StartBlockWith")]
		public string StartBlockWith 
		{
			get { return GetColumnValue<string>("StartBlockWith"); }

			set { SetColumnValue("StartBlockWith", value); }

		}

		  
		[XmlAttribute("EndBlockWith")]
		public string EndBlockWith 
		{
			get { return GetColumnValue<string>("EndBlockWith"); }

			set { SetColumnValue("EndBlockWith", value); }

		}

		
		#endregion
		
		
			
		
		//no foreign key tables defined (0)
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varDescription,string varDefinition,string varStartTag,string varEndTag,string varReplacement,string varStartBlockWith,string varEndBlockWith)
		{
			FormatBlock item = new FormatBlock();
			
			item.Description = varDescription;
			
			item.Definition = varDefinition;
			
			item.StartTag = varStartTag;
			
			item.EndTag = varEndTag;
			
			item.Replacement = varReplacement;
			
			item.StartBlockWith = varStartBlockWith;
			
			item.EndBlockWith = varEndBlockWith;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varFormatID,string varDescription,string varDefinition,string varStartTag,string varEndTag,string varReplacement,string varStartBlockWith,string varEndBlockWith)
		{
			FormatBlock item = new FormatBlock();
			
				item.FormatID = varFormatID;
				
				item.Description = varDescription;
				
				item.Definition = varDefinition;
				
				item.StartTag = varStartTag;
				
				item.EndTag = varEndTag;
				
				item.Replacement = varReplacement;
				
				item.StartBlockWith = varStartBlockWith;
				
				item.EndBlockWith = varEndBlockWith;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string FormatID = @"FormatID";
			 public static string Description = @"Description";
			 public static string Definition = @"Definition";
			 public static string StartTag = @"StartTag";
			 public static string EndTag = @"EndTag";
			 public static string Replacement = @"Replacement";
			 public static string StartBlockWith = @"StartBlockWith";
			 public static string EndBlockWith = @"EndBlockWith";
						
		}

		#endregion
	}

}

