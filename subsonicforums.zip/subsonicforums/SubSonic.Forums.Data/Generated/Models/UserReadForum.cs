using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the UserReadForum class.
    /// </summary>
    [Serializable]
    public partial class UserReadForumCollection : ReadOnlyList<UserReadForum, UserReadForumCollection>
    {        
        public UserReadForumCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the SS_UserReadForums view.
    /// </summary>
    [Serializable]
    public partial class UserReadForum : ReadOnlyRecord<UserReadForum> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("SS_UserReadForums", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarReadID = new TableSchema.TableColumn(schema);
                colvarReadID.ColumnName = "ReadID";
                colvarReadID.DataType = DbType.Int32;
                colvarReadID.MaxLength = 0;
                colvarReadID.AutoIncrement = false;
                colvarReadID.IsNullable = false;
                colvarReadID.IsPrimaryKey = false;
                colvarReadID.IsForeignKey = false;
                colvarReadID.IsReadOnly = false;
                
                schema.Columns.Add(colvarReadID);
                
                TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
                colvarUserName.ColumnName = "UserName";
                colvarUserName.DataType = DbType.String;
                colvarUserName.MaxLength = 50;
                colvarUserName.AutoIncrement = false;
                colvarUserName.IsNullable = false;
                colvarUserName.IsPrimaryKey = false;
                colvarUserName.IsForeignKey = false;
                colvarUserName.IsReadOnly = false;
                
                schema.Columns.Add(colvarUserName);
                
                TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
                colvarThreadID.ColumnName = "ThreadID";
                colvarThreadID.DataType = DbType.Int32;
                colvarThreadID.MaxLength = 0;
                colvarThreadID.AutoIncrement = false;
                colvarThreadID.IsNullable = false;
                colvarThreadID.IsPrimaryKey = false;
                colvarThreadID.IsForeignKey = false;
                colvarThreadID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadID);
                
                TableSchema.TableColumn colvarForumID = new TableSchema.TableColumn(schema);
                colvarForumID.ColumnName = "ForumID";
                colvarForumID.DataType = DbType.Int32;
                colvarForumID.MaxLength = 0;
                colvarForumID.AutoIncrement = false;
                colvarForumID.IsNullable = false;
                colvarForumID.IsPrimaryKey = false;
                colvarForumID.IsForeignKey = false;
                colvarForumID.IsReadOnly = false;
                
                schema.Columns.Add(colvarForumID);
                
                TableSchema.TableColumn colvarReadDate = new TableSchema.TableColumn(schema);
                colvarReadDate.ColumnName = "ReadDate";
                colvarReadDate.DataType = DbType.DateTime;
                colvarReadDate.MaxLength = 0;
                colvarReadDate.AutoIncrement = false;
                colvarReadDate.IsNullable = false;
                colvarReadDate.IsPrimaryKey = false;
                colvarReadDate.IsForeignKey = false;
                colvarReadDate.IsReadOnly = false;
                
                schema.Columns.Add(colvarReadDate);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("SS_UserReadForums",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public UserReadForum()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public UserReadForum(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public UserReadForum(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public UserReadForum(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("ReadID")]
        public int ReadID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ReadID");
		    }

            set 
		    {
			    SetColumnValue("ReadID", value);
            }

        }

	      
        [XmlAttribute("UserName")]
        public string UserName 
	    {
		    get
		    {
			    return GetColumnValue<string>("UserName");
		    }

            set 
		    {
			    SetColumnValue("UserName", value);
            }

        }

	      
        [XmlAttribute("ThreadID")]
        public int ThreadID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ThreadID");
		    }

            set 
		    {
			    SetColumnValue("ThreadID", value);
            }

        }

	      
        [XmlAttribute("ForumID")]
        public int ForumID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ForumID");
		    }

            set 
		    {
			    SetColumnValue("ForumID", value);
            }

        }

	      
        [XmlAttribute("ReadDate")]
        public DateTime ReadDate 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("ReadDate");
		    }

            set 
		    {
			    SetColumnValue("ReadDate", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string ReadID = @"ReadID";
            
            public static string UserName = @"UserName";
            
            public static string ThreadID = @"ThreadID";
            
            public static string ForumID = @"ForumID";
            
            public static string ReadDate = @"ReadDate";
            
	    }

	    #endregion
    }

}

