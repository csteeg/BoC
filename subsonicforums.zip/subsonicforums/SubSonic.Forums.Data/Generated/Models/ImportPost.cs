using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ImportPost class.
    /// </summary>
    [Serializable]
    public partial class ImportPostCollection : ReadOnlyList<ImportPost, ImportPostCollection>
    {        
        public ImportPostCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the IMPORT_Posts view.
    /// </summary>
    [Serializable]
    public partial class ImportPost : ReadOnlyRecord<ImportPost> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("IMPORT_Posts", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarPostID = new TableSchema.TableColumn(schema);
                colvarPostID.ColumnName = "PostID";
                colvarPostID.DataType = DbType.Int32;
                colvarPostID.MaxLength = 0;
                colvarPostID.AutoIncrement = false;
                colvarPostID.IsNullable = false;
                colvarPostID.IsPrimaryKey = false;
                colvarPostID.IsForeignKey = false;
                colvarPostID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostID);
                
                TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
                colvarThreadID.ColumnName = "ThreadID";
                colvarThreadID.DataType = DbType.Int32;
                colvarThreadID.MaxLength = 0;
                colvarThreadID.AutoIncrement = false;
                colvarThreadID.IsNullable = false;
                colvarThreadID.IsPrimaryKey = false;
                colvarThreadID.IsForeignKey = false;
                colvarThreadID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadID);
                
                TableSchema.TableColumn colvarSubject = new TableSchema.TableColumn(schema);
                colvarSubject.ColumnName = "Subject";
                colvarSubject.DataType = DbType.String;
                colvarSubject.MaxLength = 256;
                colvarSubject.AutoIncrement = false;
                colvarSubject.IsNullable = true;
                colvarSubject.IsPrimaryKey = false;
                colvarSubject.IsForeignKey = false;
                colvarSubject.IsReadOnly = false;
                
                schema.Columns.Add(colvarSubject);
                
                TableSchema.TableColumn colvarPostGuid = new TableSchema.TableColumn(schema);
                colvarPostGuid.ColumnName = "PostGuid";
                colvarPostGuid.DataType = DbType.Guid;
                colvarPostGuid.MaxLength = 0;
                colvarPostGuid.AutoIncrement = false;
                colvarPostGuid.IsNullable = true;
                colvarPostGuid.IsPrimaryKey = false;
                colvarPostGuid.IsForeignKey = false;
                colvarPostGuid.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostGuid);
                
                TableSchema.TableColumn colvarPostTypeID = new TableSchema.TableColumn(schema);
                colvarPostTypeID.ColumnName = "PostTypeID";
                colvarPostTypeID.DataType = DbType.Int32;
                colvarPostTypeID.MaxLength = 0;
                colvarPostTypeID.AutoIncrement = false;
                colvarPostTypeID.IsNullable = false;
                colvarPostTypeID.IsPrimaryKey = false;
                colvarPostTypeID.IsForeignKey = false;
                colvarPostTypeID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostTypeID);
                
                TableSchema.TableColumn colvarPostText = new TableSchema.TableColumn(schema);
                colvarPostText.ColumnName = "PostText";
                colvarPostText.DataType = DbType.String;
                colvarPostText.MaxLength = 1073741823;
                colvarPostText.AutoIncrement = false;
                colvarPostText.IsNullable = true;
                colvarPostText.IsPrimaryKey = false;
                colvarPostText.IsForeignKey = false;
                colvarPostText.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostText);
                
                TableSchema.TableColumn colvarFormattedPostText = new TableSchema.TableColumn(schema);
                colvarFormattedPostText.ColumnName = "FormattedPostText";
                colvarFormattedPostText.DataType = DbType.String;
                colvarFormattedPostText.MaxLength = 1073741823;
                colvarFormattedPostText.AutoIncrement = false;
                colvarFormattedPostText.IsNullable = true;
                colvarFormattedPostText.IsPrimaryKey = false;
                colvarFormattedPostText.IsForeignKey = false;
                colvarFormattedPostText.IsReadOnly = false;
                
                schema.Columns.Add(colvarFormattedPostText);
                
                TableSchema.TableColumn colvarIPAddress = new TableSchema.TableColumn(schema);
                colvarIPAddress.ColumnName = "IPAddress";
                colvarIPAddress.DataType = DbType.String;
                colvarIPAddress.MaxLength = 32;
                colvarIPAddress.AutoIncrement = false;
                colvarIPAddress.IsNullable = true;
                colvarIPAddress.IsPrimaryKey = false;
                colvarIPAddress.IsForeignKey = false;
                colvarIPAddress.IsReadOnly = false;
                
                schema.Columns.Add(colvarIPAddress);
                
                TableSchema.TableColumn colvarPostViewStatusID = new TableSchema.TableColumn(schema);
                colvarPostViewStatusID.ColumnName = "PostViewStatusID";
                colvarPostViewStatusID.DataType = DbType.Int32;
                colvarPostViewStatusID.MaxLength = 0;
                colvarPostViewStatusID.AutoIncrement = false;
                colvarPostViewStatusID.IsNullable = false;
                colvarPostViewStatusID.IsPrimaryKey = false;
                colvarPostViewStatusID.IsForeignKey = false;
                colvarPostViewStatusID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostViewStatusID);
                
                TableSchema.TableColumn colvarPostAdminStatusID = new TableSchema.TableColumn(schema);
                colvarPostAdminStatusID.ColumnName = "PostAdminStatusID";
                colvarPostAdminStatusID.DataType = DbType.Int32;
                colvarPostAdminStatusID.MaxLength = 0;
                colvarPostAdminStatusID.AutoIncrement = false;
                colvarPostAdminStatusID.IsNullable = false;
                colvarPostAdminStatusID.IsPrimaryKey = false;
                colvarPostAdminStatusID.IsForeignKey = false;
                colvarPostAdminStatusID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostAdminStatusID);
                
                TableSchema.TableColumn colvarAuthorEmail = new TableSchema.TableColumn(schema);
                colvarAuthorEmail.ColumnName = "AuthorEmail";
                colvarAuthorEmail.DataType = DbType.String;
                colvarAuthorEmail.MaxLength = 256;
                colvarAuthorEmail.AutoIncrement = false;
                colvarAuthorEmail.IsNullable = false;
                colvarAuthorEmail.IsPrimaryKey = false;
                colvarAuthorEmail.IsForeignKey = false;
                colvarAuthorEmail.IsReadOnly = false;
                
                schema.Columns.Add(colvarAuthorEmail);
                
                TableSchema.TableColumn colvarCreatedBy = new TableSchema.TableColumn(schema);
                colvarCreatedBy.ColumnName = "CreatedBy";
                colvarCreatedBy.DataType = DbType.String;
                colvarCreatedBy.MaxLength = 64;
                colvarCreatedBy.AutoIncrement = false;
                colvarCreatedBy.IsNullable = true;
                colvarCreatedBy.IsPrimaryKey = false;
                colvarCreatedBy.IsForeignKey = false;
                colvarCreatedBy.IsReadOnly = false;
                
                schema.Columns.Add(colvarCreatedBy);
                
                TableSchema.TableColumn colvarModifiedBy = new TableSchema.TableColumn(schema);
                colvarModifiedBy.ColumnName = "ModifiedBy";
                colvarModifiedBy.DataType = DbType.String;
                colvarModifiedBy.MaxLength = 64;
                colvarModifiedBy.AutoIncrement = false;
                colvarModifiedBy.IsNullable = true;
                colvarModifiedBy.IsPrimaryKey = false;
                colvarModifiedBy.IsForeignKey = false;
                colvarModifiedBy.IsReadOnly = false;
                
                schema.Columns.Add(colvarModifiedBy);
                
                TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
                colvarCreatedOn.ColumnName = "CreatedOn";
                colvarCreatedOn.DataType = DbType.DateTime;
                colvarCreatedOn.MaxLength = 0;
                colvarCreatedOn.AutoIncrement = false;
                colvarCreatedOn.IsNullable = false;
                colvarCreatedOn.IsPrimaryKey = false;
                colvarCreatedOn.IsForeignKey = false;
                colvarCreatedOn.IsReadOnly = false;
                
                schema.Columns.Add(colvarCreatedOn);
                
                TableSchema.TableColumn colvarModifiedOn = new TableSchema.TableColumn(schema);
                colvarModifiedOn.ColumnName = "ModifiedOn";
                colvarModifiedOn.DataType = DbType.DateTime;
                colvarModifiedOn.MaxLength = 0;
                colvarModifiedOn.AutoIncrement = false;
                colvarModifiedOn.IsNullable = false;
                colvarModifiedOn.IsPrimaryKey = false;
                colvarModifiedOn.IsForeignKey = false;
                colvarModifiedOn.IsReadOnly = false;
                
                schema.Columns.Add(colvarModifiedOn);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("IMPORT_Posts",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ImportPost()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ImportPost(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ImportPost(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ImportPost(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("PostID")]
        public int PostID 
	    {
		    get
		    {
			    return GetColumnValue<int>("PostID");
		    }

            set 
		    {
			    SetColumnValue("PostID", value);
            }

        }

	      
        [XmlAttribute("ThreadID")]
        public int ThreadID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ThreadID");
		    }

            set 
		    {
			    SetColumnValue("ThreadID", value);
            }

        }

	      
        [XmlAttribute("Subject")]
        public string Subject 
	    {
		    get
		    {
			    return GetColumnValue<string>("Subject");
		    }

            set 
		    {
			    SetColumnValue("Subject", value);
            }

        }

	      
        [XmlAttribute("PostGuid")]
        public Guid? PostGuid 
	    {
		    get
		    {
			    return GetColumnValue<Guid?>("PostGuid");
		    }

            set 
		    {
			    SetColumnValue("PostGuid", value);
            }

        }

	      
        [XmlAttribute("PostTypeID")]
        public int PostTypeID 
	    {
		    get
		    {
			    return GetColumnValue<int>("PostTypeID");
		    }

            set 
		    {
			    SetColumnValue("PostTypeID", value);
            }

        }

	      
        [XmlAttribute("PostText")]
        public string PostText 
	    {
		    get
		    {
			    return GetColumnValue<string>("PostText");
		    }

            set 
		    {
			    SetColumnValue("PostText", value);
            }

        }

	      
        [XmlAttribute("FormattedPostText")]
        public string FormattedPostText 
	    {
		    get
		    {
			    return GetColumnValue<string>("FormattedPostText");
		    }

            set 
		    {
			    SetColumnValue("FormattedPostText", value);
            }

        }

	      
        [XmlAttribute("IPAddress")]
        public string IPAddress 
	    {
		    get
		    {
			    return GetColumnValue<string>("IPAddress");
		    }

            set 
		    {
			    SetColumnValue("IPAddress", value);
            }

        }

	      
        [XmlAttribute("PostViewStatusID")]
        public int PostViewStatusID 
	    {
		    get
		    {
			    return GetColumnValue<int>("PostViewStatusID");
		    }

            set 
		    {
			    SetColumnValue("PostViewStatusID", value);
            }

        }

	      
        [XmlAttribute("PostAdminStatusID")]
        public int PostAdminStatusID 
	    {
		    get
		    {
			    return GetColumnValue<int>("PostAdminStatusID");
		    }

            set 
		    {
			    SetColumnValue("PostAdminStatusID", value);
            }

        }

	      
        [XmlAttribute("AuthorEmail")]
        public string AuthorEmail 
	    {
		    get
		    {
			    return GetColumnValue<string>("AuthorEmail");
		    }

            set 
		    {
			    SetColumnValue("AuthorEmail", value);
            }

        }

	      
        [XmlAttribute("CreatedBy")]
        public string CreatedBy 
	    {
		    get
		    {
			    return GetColumnValue<string>("CreatedBy");
		    }

            set 
		    {
			    SetColumnValue("CreatedBy", value);
            }

        }

	      
        [XmlAttribute("ModifiedBy")]
        public string ModifiedBy 
	    {
		    get
		    {
			    return GetColumnValue<string>("ModifiedBy");
		    }

            set 
		    {
			    SetColumnValue("ModifiedBy", value);
            }

        }

	      
        [XmlAttribute("CreatedOn")]
        public DateTime CreatedOn 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("CreatedOn");
		    }

            set 
		    {
			    SetColumnValue("CreatedOn", value);
            }

        }

	      
        [XmlAttribute("ModifiedOn")]
        public DateTime ModifiedOn 
	    {
		    get
		    {
			    return GetColumnValue<DateTime>("ModifiedOn");
		    }

            set 
		    {
			    SetColumnValue("ModifiedOn", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string PostID = @"PostID";
            
            public static string ThreadID = @"ThreadID";
            
            public static string Subject = @"Subject";
            
            public static string PostGuid = @"PostGuid";
            
            public static string PostTypeID = @"PostTypeID";
            
            public static string PostText = @"PostText";
            
            public static string FormattedPostText = @"FormattedPostText";
            
            public static string IPAddress = @"IPAddress";
            
            public static string PostViewStatusID = @"PostViewStatusID";
            
            public static string PostAdminStatusID = @"PostAdminStatusID";
            
            public static string AuthorEmail = @"AuthorEmail";
            
            public static string CreatedBy = @"CreatedBy";
            
            public static string ModifiedBy = @"ModifiedBy";
            
            public static string CreatedOn = @"CreatedOn";
            
            public static string ModifiedOn = @"ModifiedOn";
            
	    }

	    #endregion
    }

}

