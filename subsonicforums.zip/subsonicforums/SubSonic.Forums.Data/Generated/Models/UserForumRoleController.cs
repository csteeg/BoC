using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_User_ForumRole
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class UserForumRoleController
    {
        // Preload our schema..
        UserForumRole thisSchemaLoad = new UserForumRole();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public UserForumRoleCollection FetchAll()
        {
            UserForumRoleCollection coll = new UserForumRoleCollection();
            Query qry = new Query(UserForumRole.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public UserForumRoleCollection FetchByID(object UserName)
        {
            UserForumRoleCollection coll = new UserForumRoleCollection().Where("userName", UserName).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public UserForumRoleCollection FetchByQuery(Query qry)
        {
            UserForumRoleCollection coll = new UserForumRoleCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object UserName)
        {
            return (UserForumRole.Delete(UserName) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object UserName)
        {
            return (UserForumRole.Destroy(UserName) == 1);
        }

        
        
        
        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(string UserName,int RoleID)
        {
            Query qry = new Query(UserForumRole.Schema);
            qry.QueryType = QueryType.Delete;
            qry.AddWhere("UserName", UserName).AND("RoleID", RoleID);
            qry.Execute();
            return (true);
        }
        
       
    	
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string UserName,int RoleID)
	    {
		    UserForumRole item = new UserForumRole();
		    
            item.UserName = UserName;
            
            item.RoleID = RoleID;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(string UserName,int RoleID)
	    {
		    UserForumRole item = new UserForumRole();
		    
				item.UserName = UserName;
				
				item.RoleID = RoleID;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

