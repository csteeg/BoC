using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_User_WatchedThread
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class UserWatchedThreadController
    {
        // Preload our schema..
        UserWatchedThread thisSchemaLoad = new UserWatchedThread();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public UserWatchedThreadCollection FetchAll()
        {
            UserWatchedThreadCollection coll = new UserWatchedThreadCollection();
            Query qry = new Query(UserWatchedThread.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public UserWatchedThreadCollection FetchByID(object UserName)
        {
            UserWatchedThreadCollection coll = new UserWatchedThreadCollection().Where("UserName", UserName).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public UserWatchedThreadCollection FetchByQuery(Query qry)
        {
            UserWatchedThreadCollection coll = new UserWatchedThreadCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object UserName)
        {
            return (UserWatchedThread.Delete(UserName) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object UserName)
        {
            return (UserWatchedThread.Destroy(UserName) == 1);
        }

        
        
        
        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(string UserName,int ThreadID)
        {
            Query qry = new Query(UserWatchedThread.Schema);
            qry.QueryType = QueryType.Delete;
            qry.AddWhere("UserName", UserName).AND("ThreadID", ThreadID);
            qry.Execute();
            return (true);
        }
        
       
    	
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string UserName,int ThreadID,string ThreadUrl,bool EmailNotify,DateTime? CreatedOn,bool AnswerOnly)
	    {
		    UserWatchedThread item = new UserWatchedThread();
		    
            item.UserName = UserName;
            
            item.ThreadID = ThreadID;
            
            item.ThreadUrl = ThreadUrl;
            
            item.EmailNotify = EmailNotify;
            
            item.CreatedOn = CreatedOn;
            
            item.AnswerOnly = AnswerOnly;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(string UserName,int ThreadID,string ThreadUrl,bool EmailNotify,DateTime? CreatedOn,bool AnswerOnly)
	    {
		    UserWatchedThread item = new UserWatchedThread();
		    
				item.UserName = UserName;
				
				item.ThreadID = ThreadID;
				
				item.ThreadUrl = ThreadUrl;
				
				item.EmailNotify = EmailNotify;
				
				item.CreatedOn = CreatedOn;
				
				item.AnswerOnly = AnswerOnly;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

