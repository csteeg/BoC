using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_Post
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class PostController
    {
        // Preload our schema..
        Post thisSchemaLoad = new Post();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public PostCollection FetchAll()
        {
            PostCollection coll = new PostCollection();
            Query qry = new Query(Post.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public PostCollection FetchByID(object PostID)
        {
            PostCollection coll = new PostCollection().Where("PostID", PostID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public PostCollection FetchByQuery(Query qry)
        {
            PostCollection coll = new PostCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object PostID)
        {
            return (Post.Delete(PostID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object PostID)
        {
            return (Post.Destroy(PostID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string Subject,int ThreadID,Guid PostGUID,int PostTypeID,string PostText,string FormattedPostText,string ModeratorMessage,string IPAddress,string AuthorEmail,string CreatedBy,DateTime CreatedOn,string ModifiedBy,DateTime ModifiedOn,bool Deleted,bool IsAnswer)
	    {
		    Post item = new Post();
		    
            item.Subject = Subject;
            
            item.ThreadID = ThreadID;
            
            item.PostGUID = PostGUID;
            
            item.PostTypeID = PostTypeID;
            
            item.PostText = PostText;
            
            item.FormattedPostText = FormattedPostText;
            
            item.ModeratorMessage = ModeratorMessage;
            
            item.IPAddress = IPAddress;
            
            item.AuthorEmail = AuthorEmail;
            
            item.CreatedBy = CreatedBy;
            
            item.CreatedOn = CreatedOn;
            
            item.ModifiedBy = ModifiedBy;
            
            item.ModifiedOn = ModifiedOn;
            
            item.Deleted = Deleted;
            
            item.IsAnswer = IsAnswer;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int PostID,string Subject,int ThreadID,Guid PostGUID,int PostTypeID,string PostText,string FormattedPostText,string ModeratorMessage,string IPAddress,string AuthorEmail,string CreatedBy,DateTime CreatedOn,string ModifiedBy,DateTime ModifiedOn,bool Deleted,bool IsAnswer)
	    {
		    Post item = new Post();
		    
				item.PostID = PostID;
				
				item.Subject = Subject;
				
				item.ThreadID = ThreadID;
				
				item.PostGUID = PostGUID;
				
				item.PostTypeID = PostTypeID;
				
				item.PostText = PostText;
				
				item.FormattedPostText = FormattedPostText;
				
				item.ModeratorMessage = ModeratorMessage;
				
				item.IPAddress = IPAddress;
				
				item.AuthorEmail = AuthorEmail;
				
				item.CreatedBy = CreatedBy;
				
				item.CreatedOn = CreatedOn;
				
				item.ModifiedBy = ModifiedBy;
				
				item.ModifiedOn = ModifiedOn;
				
				item.Deleted = Deleted;
				
				item.IsAnswer = IsAnswer;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

