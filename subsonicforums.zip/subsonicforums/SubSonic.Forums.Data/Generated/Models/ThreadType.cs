using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the ThreadType class.
	/// </summary>
	[Serializable]
	public partial class ThreadTypeCollection : ActiveList<ThreadType, ThreadTypeCollection> 
	{	   
		public ThreadTypeCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_ThreadType table.
	/// </summary>
	[Serializable]
	public partial class ThreadType : ActiveRecord<ThreadType>
	{
		#region .ctors and Default Settings
		
		public ThreadType()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public ThreadType(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public ThreadType(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public ThreadType(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_ThreadType", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarThreadTypeID = new TableSchema.TableColumn(schema);
				colvarThreadTypeID.ColumnName = "ThreadTypeID";
				colvarThreadTypeID.DataType = DbType.Int32;
				colvarThreadTypeID.MaxLength = 0;
				colvarThreadTypeID.AutoIncrement = true;
				colvarThreadTypeID.IsNullable = false;
				colvarThreadTypeID.IsPrimaryKey = true;
				colvarThreadTypeID.IsForeignKey = false;
				colvarThreadTypeID.IsReadOnly = false;
				colvarThreadTypeID.DefaultSetting = @"";
				colvarThreadTypeID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarThreadTypeID);
				
				TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
				colvarDescription.ColumnName = "Description";
				colvarDescription.DataType = DbType.String;
				colvarDescription.MaxLength = 50;
				colvarDescription.AutoIncrement = false;
				colvarDescription.IsNullable = true;
				colvarDescription.IsPrimaryKey = false;
				colvarDescription.IsForeignKey = false;
				colvarDescription.IsReadOnly = false;
				colvarDescription.DefaultSetting = @"";
				colvarDescription.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDescription);
				
				TableSchema.TableColumn colvarListOrder = new TableSchema.TableColumn(schema);
				colvarListOrder.ColumnName = "ListOrder";
				colvarListOrder.DataType = DbType.Int32;
				colvarListOrder.MaxLength = 0;
				colvarListOrder.AutoIncrement = false;
				colvarListOrder.IsNullable = false;
				colvarListOrder.IsPrimaryKey = false;
				colvarListOrder.IsForeignKey = false;
				colvarListOrder.IsReadOnly = false;
				
						colvarListOrder.DefaultSetting = @"((0))";
				colvarListOrder.ForeignKeyTableName = "";
				schema.Columns.Add(colvarListOrder);
				
				TableSchema.TableColumn colvarIcon = new TableSchema.TableColumn(schema);
				colvarIcon.ColumnName = "Icon";
				colvarIcon.DataType = DbType.String;
				colvarIcon.MaxLength = 50;
				colvarIcon.AutoIncrement = false;
				colvarIcon.IsNullable = true;
				colvarIcon.IsPrimaryKey = false;
				colvarIcon.IsForeignKey = false;
				colvarIcon.IsReadOnly = false;
				colvarIcon.DefaultSetting = @"";
				colvarIcon.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIcon);
				
				TableSchema.TableColumn colvarCssClass = new TableSchema.TableColumn(schema);
				colvarCssClass.ColumnName = "CssClass";
				colvarCssClass.DataType = DbType.String;
				colvarCssClass.MaxLength = 50;
				colvarCssClass.AutoIncrement = false;
				colvarCssClass.IsNullable = true;
				colvarCssClass.IsPrimaryKey = false;
				colvarCssClass.IsForeignKey = false;
				colvarCssClass.IsReadOnly = false;
				colvarCssClass.DefaultSetting = @"";
				colvarCssClass.ForeignKeyTableName = "";
				schema.Columns.Add(colvarCssClass);
				
				TableSchema.TableColumn colvarAuthorCanDesignateAnswer = new TableSchema.TableColumn(schema);
				colvarAuthorCanDesignateAnswer.ColumnName = "AuthorCanDesignateAnswer";
				colvarAuthorCanDesignateAnswer.DataType = DbType.Boolean;
				colvarAuthorCanDesignateAnswer.MaxLength = 0;
				colvarAuthorCanDesignateAnswer.AutoIncrement = false;
				colvarAuthorCanDesignateAnswer.IsNullable = false;
				colvarAuthorCanDesignateAnswer.IsPrimaryKey = false;
				colvarAuthorCanDesignateAnswer.IsForeignKey = false;
				colvarAuthorCanDesignateAnswer.IsReadOnly = false;
				
						colvarAuthorCanDesignateAnswer.DefaultSetting = @"((0))";
				colvarAuthorCanDesignateAnswer.ForeignKeyTableName = "";
				schema.Columns.Add(colvarAuthorCanDesignateAnswer);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_ThreadType",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("ThreadTypeID")]
		public int ThreadTypeID 
		{
			get { return GetColumnValue<int>("ThreadTypeID"); }

			set { SetColumnValue("ThreadTypeID", value); }

		}

		  
		[XmlAttribute("Description")]
		public string Description 
		{
			get { return GetColumnValue<string>("Description"); }

			set { SetColumnValue("Description", value); }

		}

		  
		[XmlAttribute("ListOrder")]
		public int ListOrder 
		{
			get { return GetColumnValue<int>("ListOrder"); }

			set { SetColumnValue("ListOrder", value); }

		}

		  
		[XmlAttribute("Icon")]
		public string Icon 
		{
			get { return GetColumnValue<string>("Icon"); }

			set { SetColumnValue("Icon", value); }

		}

		  
		[XmlAttribute("CssClass")]
		public string CssClass 
		{
			get { return GetColumnValue<string>("CssClass"); }

			set { SetColumnValue("CssClass", value); }

		}

		  
		[XmlAttribute("AuthorCanDesignateAnswer")]
		public bool AuthorCanDesignateAnswer 
		{
			get { return GetColumnValue<bool>("AuthorCanDesignateAnswer"); }

			set { SetColumnValue("AuthorCanDesignateAnswer", value); }

		}

		
		#endregion
		
		
		#region PrimaryKey Methods
		
		public SubSonic.Forums.ThreadTypeResponseCollection ThreadTypeResponseRecords()
		{
			return new SubSonic.Forums.ThreadTypeResponseCollection().Where(ThreadTypeResponse.Columns.ThreadTypeID, ThreadTypeID).Load();
		}

		public SubSonic.Forums.ThreadCollection ThreadRecords()
		{
			return new SubSonic.Forums.ThreadCollection().Where(Thread.Columns.ThreadTypeID, ThreadTypeID).Load();
		}

		#endregion
		
			
		
		//no foreign key tables defined (0)
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varDescription,int varListOrder,string varIcon,string varCssClass,bool varAuthorCanDesignateAnswer)
		{
			ThreadType item = new ThreadType();
			
			item.Description = varDescription;
			
			item.ListOrder = varListOrder;
			
			item.Icon = varIcon;
			
			item.CssClass = varCssClass;
			
			item.AuthorCanDesignateAnswer = varAuthorCanDesignateAnswer;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varThreadTypeID,string varDescription,int varListOrder,string varIcon,string varCssClass,bool varAuthorCanDesignateAnswer)
		{
			ThreadType item = new ThreadType();
			
				item.ThreadTypeID = varThreadTypeID;
				
				item.Description = varDescription;
				
				item.ListOrder = varListOrder;
				
				item.Icon = varIcon;
				
				item.CssClass = varCssClass;
				
				item.AuthorCanDesignateAnswer = varAuthorCanDesignateAnswer;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string ThreadTypeID = @"ThreadTypeID";
			 public static string Description = @"Description";
			 public static string ListOrder = @"ListOrder";
			 public static string Icon = @"Icon";
			 public static string CssClass = @"CssClass";
			 public static string AuthorCanDesignateAnswer = @"AuthorCanDesignateAnswer";
						
		}

		#endregion
	}

}

