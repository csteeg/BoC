using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the UserForumRole class.
	/// </summary>
	[Serializable]
	public partial class UserForumRoleCollection : ActiveList<UserForumRole, UserForumRoleCollection> 
	{	   
		public UserForumRoleCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_User_ForumRole table.
	/// </summary>
	[Serializable]
	public partial class UserForumRole : ActiveRecord<UserForumRole>
	{
		#region .ctors and Default Settings
		
		public UserForumRole()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public UserForumRole(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public UserForumRole(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public UserForumRole(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_User_ForumRole", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
				colvarUserName.ColumnName = "userName";
				colvarUserName.DataType = DbType.String;
				colvarUserName.MaxLength = 50;
				colvarUserName.AutoIncrement = false;
				colvarUserName.IsNullable = false;
				colvarUserName.IsPrimaryKey = true;
				colvarUserName.IsForeignKey = true;
				colvarUserName.IsReadOnly = false;
				colvarUserName.DefaultSetting = @"";
				
					colvarUserName.ForeignKeyTableName = "SS_UserProfile";
				schema.Columns.Add(colvarUserName);
				
				TableSchema.TableColumn colvarRoleID = new TableSchema.TableColumn(schema);
				colvarRoleID.ColumnName = "roleID";
				colvarRoleID.DataType = DbType.Int32;
				colvarRoleID.MaxLength = 0;
				colvarRoleID.AutoIncrement = false;
				colvarRoleID.IsNullable = false;
				colvarRoleID.IsPrimaryKey = true;
				colvarRoleID.IsForeignKey = true;
				colvarRoleID.IsReadOnly = false;
				colvarRoleID.DefaultSetting = @"";
				
					colvarRoleID.ForeignKeyTableName = "SS_ForumRole";
				schema.Columns.Add(colvarRoleID);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_User_ForumRole",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("UserName")]
		public string UserName 
		{
			get { return GetColumnValue<string>("userName"); }

			set { SetColumnValue("userName", value); }

		}

		  
		[XmlAttribute("RoleID")]
		public int RoleID 
		{
			get { return GetColumnValue<int>("roleID"); }

			set { SetColumnValue("roleID", value); }

		}

		
		#endregion
		
		
			
		
		#region ForeignKey Properties
		
		/// <summary>
		/// Returns a ForumRole ActiveRecord object related to this UserForumRole
		/// 
		/// </summary>
		public SubSonic.Forums.ForumRole ForumRole
		{
			get { return SubSonic.Forums.ForumRole.FetchByID(this.RoleID); }

			set { SetColumnValue("roleID", value.RoleID); }

		}

		
		
		/// <summary>
		/// Returns a UserProfile ActiveRecord object related to this UserForumRole
		/// 
		/// </summary>
		public SubSonic.Forums.UserProfile UserProfile
		{
			get { return SubSonic.Forums.UserProfile.FetchByID(this.UserName); }

			set { SetColumnValue("userName", value.UserName); }

		}

		
		
		#endregion
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varUserName,int varRoleID)
		{
			UserForumRole item = new UserForumRole();
			
			item.UserName = varUserName;
			
			item.RoleID = varRoleID;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(string varUserName,int varRoleID)
		{
			UserForumRole item = new UserForumRole();
			
				item.UserName = varUserName;
				
				item.RoleID = varRoleID;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string UserName = @"userName";
			 public static string RoleID = @"roleID";
						
		}

		#endregion
	}

}

