using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ThreadResponse class.
    /// </summary>
    [Serializable]
    public partial class ThreadResponseCollection : ReadOnlyList<ThreadResponse, ThreadResponseCollection>
    {        
        public ThreadResponseCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the SS_ThreadResponses view.
    /// </summary>
    [Serializable]
    public partial class ThreadResponse : ReadOnlyRecord<ThreadResponse> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("SS_ThreadResponses", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
                colvarThreadID.ColumnName = "ThreadID";
                colvarThreadID.DataType = DbType.Int32;
                colvarThreadID.MaxLength = 0;
                colvarThreadID.AutoIncrement = false;
                colvarThreadID.IsNullable = false;
                colvarThreadID.IsPrimaryKey = false;
                colvarThreadID.IsForeignKey = false;
                colvarThreadID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadID);
                
                TableSchema.TableColumn colvarThreadTypeResponseID = new TableSchema.TableColumn(schema);
                colvarThreadTypeResponseID.ColumnName = "ThreadTypeResponseID";
                colvarThreadTypeResponseID.DataType = DbType.Int32;
                colvarThreadTypeResponseID.MaxLength = 0;
                colvarThreadTypeResponseID.AutoIncrement = false;
                colvarThreadTypeResponseID.IsNullable = false;
                colvarThreadTypeResponseID.IsPrimaryKey = false;
                colvarThreadTypeResponseID.IsForeignKey = false;
                colvarThreadTypeResponseID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadTypeResponseID);
                
                TableSchema.TableColumn colvarThreadTypeID = new TableSchema.TableColumn(schema);
                colvarThreadTypeID.ColumnName = "ThreadTypeID";
                colvarThreadTypeID.DataType = DbType.Int32;
                colvarThreadTypeID.MaxLength = 0;
                colvarThreadTypeID.AutoIncrement = false;
                colvarThreadTypeID.IsNullable = true;
                colvarThreadTypeID.IsPrimaryKey = false;
                colvarThreadTypeID.IsForeignKey = false;
                colvarThreadTypeID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadTypeID);
                
                TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
                colvarDescription.ColumnName = "Description";
                colvarDescription.DataType = DbType.String;
                colvarDescription.MaxLength = 50;
                colvarDescription.AutoIncrement = false;
                colvarDescription.IsNullable = true;
                colvarDescription.IsPrimaryKey = false;
                colvarDescription.IsForeignKey = false;
                colvarDescription.IsReadOnly = false;
                
                schema.Columns.Add(colvarDescription);
                
                TableSchema.TableColumn colvarPostDesignation = new TableSchema.TableColumn(schema);
                colvarPostDesignation.ColumnName = "PostDesignation";
                colvarPostDesignation.DataType = DbType.String;
                colvarPostDesignation.MaxLength = 50;
                colvarPostDesignation.AutoIncrement = false;
                colvarPostDesignation.IsNullable = true;
                colvarPostDesignation.IsPrimaryKey = false;
                colvarPostDesignation.IsForeignKey = false;
                colvarPostDesignation.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostDesignation);
                
                TableSchema.TableColumn colvarIsSearchable = new TableSchema.TableColumn(schema);
                colvarIsSearchable.ColumnName = "IsSearchable";
                colvarIsSearchable.DataType = DbType.Boolean;
                colvarIsSearchable.MaxLength = 0;
                colvarIsSearchable.AutoIncrement = false;
                colvarIsSearchable.IsNullable = false;
                colvarIsSearchable.IsPrimaryKey = false;
                colvarIsSearchable.IsForeignKey = false;
                colvarIsSearchable.IsReadOnly = false;
                
                schema.Columns.Add(colvarIsSearchable);
                
                TableSchema.TableColumn colvarIsDefault = new TableSchema.TableColumn(schema);
                colvarIsDefault.ColumnName = "IsDefault";
                colvarIsDefault.DataType = DbType.Boolean;
                colvarIsDefault.MaxLength = 0;
                colvarIsDefault.AutoIncrement = false;
                colvarIsDefault.IsNullable = false;
                colvarIsDefault.IsPrimaryKey = false;
                colvarIsDefault.IsForeignKey = false;
                colvarIsDefault.IsReadOnly = false;
                
                schema.Columns.Add(colvarIsDefault);
                
                TableSchema.TableColumn colvarResponseAuthor = new TableSchema.TableColumn(schema);
                colvarResponseAuthor.ColumnName = "ResponseAuthor";
                colvarResponseAuthor.DataType = DbType.String;
                colvarResponseAuthor.MaxLength = 50;
                colvarResponseAuthor.AutoIncrement = false;
                colvarResponseAuthor.IsNullable = true;
                colvarResponseAuthor.IsPrimaryKey = false;
                colvarResponseAuthor.IsForeignKey = false;
                colvarResponseAuthor.IsReadOnly = false;
                
                schema.Columns.Add(colvarResponseAuthor);
                
                TableSchema.TableColumn colvarSubject = new TableSchema.TableColumn(schema);
                colvarSubject.ColumnName = "Subject";
                colvarSubject.DataType = DbType.String;
                colvarSubject.MaxLength = 250;
                colvarSubject.AutoIncrement = false;
                colvarSubject.IsNullable = false;
                colvarSubject.IsPrimaryKey = false;
                colvarSubject.IsForeignKey = false;
                colvarSubject.IsReadOnly = false;
                
                schema.Columns.Add(colvarSubject);
                
                TableSchema.TableColumn colvarPostID = new TableSchema.TableColumn(schema);
                colvarPostID.ColumnName = "PostID";
                colvarPostID.DataType = DbType.Int32;
                colvarPostID.MaxLength = 0;
                colvarPostID.AutoIncrement = false;
                colvarPostID.IsNullable = false;
                colvarPostID.IsPrimaryKey = false;
                colvarPostID.IsForeignKey = false;
                colvarPostID.IsReadOnly = false;
                
                schema.Columns.Add(colvarPostID);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("SS_ThreadResponses",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ThreadResponse()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ThreadResponse(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ThreadResponse(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ThreadResponse(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("ThreadID")]
        public int ThreadID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ThreadID");
		    }

            set 
		    {
			    SetColumnValue("ThreadID", value);
            }

        }

	      
        [XmlAttribute("ThreadTypeResponseID")]
        public int ThreadTypeResponseID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ThreadTypeResponseID");
		    }

            set 
		    {
			    SetColumnValue("ThreadTypeResponseID", value);
            }

        }

	      
        [XmlAttribute("ThreadTypeID")]
        public int? ThreadTypeID 
	    {
		    get
		    {
			    return GetColumnValue<int?>("ThreadTypeID");
		    }

            set 
		    {
			    SetColumnValue("ThreadTypeID", value);
            }

        }

	      
        [XmlAttribute("Description")]
        public string Description 
	    {
		    get
		    {
			    return GetColumnValue<string>("Description");
		    }

            set 
		    {
			    SetColumnValue("Description", value);
            }

        }

	      
        [XmlAttribute("PostDesignation")]
        public string PostDesignation 
	    {
		    get
		    {
			    return GetColumnValue<string>("PostDesignation");
		    }

            set 
		    {
			    SetColumnValue("PostDesignation", value);
            }

        }

	      
        [XmlAttribute("IsSearchable")]
        public bool IsSearchable 
	    {
		    get
		    {
			    return GetColumnValue<bool>("IsSearchable");
		    }

            set 
		    {
			    SetColumnValue("IsSearchable", value);
            }

        }

	      
        [XmlAttribute("IsDefault")]
        public bool IsDefault 
	    {
		    get
		    {
			    return GetColumnValue<bool>("IsDefault");
		    }

            set 
		    {
			    SetColumnValue("IsDefault", value);
            }

        }

	      
        [XmlAttribute("ResponseAuthor")]
        public string ResponseAuthor 
	    {
		    get
		    {
			    return GetColumnValue<string>("ResponseAuthor");
		    }

            set 
		    {
			    SetColumnValue("ResponseAuthor", value);
            }

        }

	      
        [XmlAttribute("Subject")]
        public string Subject 
	    {
		    get
		    {
			    return GetColumnValue<string>("Subject");
		    }

            set 
		    {
			    SetColumnValue("Subject", value);
            }

        }

	      
        [XmlAttribute("PostID")]
        public int PostID 
	    {
		    get
		    {
			    return GetColumnValue<int>("PostID");
		    }

            set 
		    {
			    SetColumnValue("PostID", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string ThreadID = @"ThreadID";
            
            public static string ThreadTypeResponseID = @"ThreadTypeResponseID";
            
            public static string ThreadTypeID = @"ThreadTypeID";
            
            public static string Description = @"Description";
            
            public static string PostDesignation = @"PostDesignation";
            
            public static string IsSearchable = @"IsSearchable";
            
            public static string IsDefault = @"IsDefault";
            
            public static string ResponseAuthor = @"ResponseAuthor";
            
            public static string Subject = @"Subject";
            
            public static string PostID = @"PostID";
            
	    }

	    #endregion
    }

}

