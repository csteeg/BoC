using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the CmsPage class.
	/// </summary>
	[Serializable]
	public partial class CmsPageCollection : ActiveList<CmsPage, CmsPageCollection> 
	{	   
		public CmsPageCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the CMS_Page table.
	/// </summary>
	[Serializable]
	public partial class CmsPage : ActiveRecord<CmsPage>
	{
		#region .ctors and Default Settings
		
		public CmsPage()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public CmsPage(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public CmsPage(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public CmsPage(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("CMS_Page", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarPageID = new TableSchema.TableColumn(schema);
				colvarPageID.ColumnName = "PageID";
				colvarPageID.DataType = DbType.Int32;
				colvarPageID.MaxLength = 0;
				colvarPageID.AutoIncrement = true;
				colvarPageID.IsNullable = false;
				colvarPageID.IsPrimaryKey = true;
				colvarPageID.IsForeignKey = false;
				colvarPageID.IsReadOnly = false;
				colvarPageID.DefaultSetting = @"";
				colvarPageID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarPageID);
				
				TableSchema.TableColumn colvarTitle = new TableSchema.TableColumn(schema);
				colvarTitle.ColumnName = "Title";
				colvarTitle.DataType = DbType.String;
				colvarTitle.MaxLength = 500;
				colvarTitle.AutoIncrement = false;
				colvarTitle.IsNullable = false;
				colvarTitle.IsPrimaryKey = false;
				colvarTitle.IsForeignKey = false;
				colvarTitle.IsReadOnly = false;
				colvarTitle.DefaultSetting = @"";
				colvarTitle.ForeignKeyTableName = "";
				schema.Columns.Add(colvarTitle);
				
				TableSchema.TableColumn colvarBody = new TableSchema.TableColumn(schema);
				colvarBody.ColumnName = "Body";
				colvarBody.DataType = DbType.String;
				colvarBody.MaxLength = -1;
				colvarBody.AutoIncrement = false;
				colvarBody.IsNullable = true;
				colvarBody.IsPrimaryKey = false;
				colvarBody.IsForeignKey = false;
				colvarBody.IsReadOnly = false;
				colvarBody.DefaultSetting = @"";
				colvarBody.ForeignKeyTableName = "";
				schema.Columns.Add(colvarBody);
				
				TableSchema.TableColumn colvarLocale = new TableSchema.TableColumn(schema);
				colvarLocale.ColumnName = "Locale";
				colvarLocale.DataType = DbType.AnsiStringFixedLength;
				colvarLocale.MaxLength = 5;
				colvarLocale.AutoIncrement = false;
				colvarLocale.IsNullable = false;
				colvarLocale.IsPrimaryKey = false;
				colvarLocale.IsForeignKey = false;
				colvarLocale.IsReadOnly = false;
				colvarLocale.DefaultSetting = @"";
				colvarLocale.ForeignKeyTableName = "";
				schema.Columns.Add(colvarLocale);
				
				TableSchema.TableColumn colvarParentID = new TableSchema.TableColumn(schema);
				colvarParentID.ColumnName = "ParentID";
				colvarParentID.DataType = DbType.Int32;
				colvarParentID.MaxLength = 0;
				colvarParentID.AutoIncrement = false;
				colvarParentID.IsNullable = true;
				colvarParentID.IsPrimaryKey = false;
				colvarParentID.IsForeignKey = false;
				colvarParentID.IsReadOnly = false;
				colvarParentID.DefaultSetting = @"";
				colvarParentID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarParentID);
				
				TableSchema.TableColumn colvarPageGuid = new TableSchema.TableColumn(schema);
				colvarPageGuid.ColumnName = "PageGuid";
				colvarPageGuid.DataType = DbType.Guid;
				colvarPageGuid.MaxLength = 0;
				colvarPageGuid.AutoIncrement = false;
				colvarPageGuid.IsNullable = false;
				colvarPageGuid.IsPrimaryKey = false;
				colvarPageGuid.IsForeignKey = false;
				colvarPageGuid.IsReadOnly = false;
				colvarPageGuid.DefaultSetting = @"";
				colvarPageGuid.ForeignKeyTableName = "";
				schema.Columns.Add(colvarPageGuid);
				
				TableSchema.TableColumn colvarMenuTitle = new TableSchema.TableColumn(schema);
				colvarMenuTitle.ColumnName = "MenuTitle";
				colvarMenuTitle.DataType = DbType.String;
				colvarMenuTitle.MaxLength = 50;
				colvarMenuTitle.AutoIncrement = false;
				colvarMenuTitle.IsNullable = false;
				colvarMenuTitle.IsPrimaryKey = false;
				colvarMenuTitle.IsForeignKey = false;
				colvarMenuTitle.IsReadOnly = false;
				colvarMenuTitle.DefaultSetting = @"";
				colvarMenuTitle.ForeignKeyTableName = "";
				schema.Columns.Add(colvarMenuTitle);
				
				TableSchema.TableColumn colvarRoles = new TableSchema.TableColumn(schema);
				colvarRoles.ColumnName = "Roles";
				colvarRoles.DataType = DbType.String;
				colvarRoles.MaxLength = 500;
				colvarRoles.AutoIncrement = false;
				colvarRoles.IsNullable = false;
				colvarRoles.IsPrimaryKey = false;
				colvarRoles.IsForeignKey = false;
				colvarRoles.IsReadOnly = false;
				colvarRoles.DefaultSetting = @"";
				colvarRoles.ForeignKeyTableName = "";
				schema.Columns.Add(colvarRoles);
				
				TableSchema.TableColumn colvarSummary = new TableSchema.TableColumn(schema);
				colvarSummary.ColumnName = "Summary";
				colvarSummary.DataType = DbType.String;
				colvarSummary.MaxLength = 500;
				colvarSummary.AutoIncrement = false;
				colvarSummary.IsNullable = true;
				colvarSummary.IsPrimaryKey = false;
				colvarSummary.IsForeignKey = false;
				colvarSummary.IsReadOnly = false;
				colvarSummary.DefaultSetting = @"";
				colvarSummary.ForeignKeyTableName = "";
				schema.Columns.Add(colvarSummary);
				
				TableSchema.TableColumn colvarPageUrl = new TableSchema.TableColumn(schema);
				colvarPageUrl.ColumnName = "PageUrl";
				colvarPageUrl.DataType = DbType.String;
				colvarPageUrl.MaxLength = 500;
				colvarPageUrl.AutoIncrement = false;
				colvarPageUrl.IsNullable = false;
				colvarPageUrl.IsPrimaryKey = false;
				colvarPageUrl.IsForeignKey = false;
				colvarPageUrl.IsReadOnly = false;
				colvarPageUrl.DefaultSetting = @"";
				colvarPageUrl.ForeignKeyTableName = "";
				schema.Columns.Add(colvarPageUrl);
				
				TableSchema.TableColumn colvarKeywords = new TableSchema.TableColumn(schema);
				colvarKeywords.ColumnName = "Keywords";
				colvarKeywords.DataType = DbType.String;
				colvarKeywords.MaxLength = 500;
				colvarKeywords.AutoIncrement = false;
				colvarKeywords.IsNullable = true;
				colvarKeywords.IsPrimaryKey = false;
				colvarKeywords.IsForeignKey = false;
				colvarKeywords.IsReadOnly = false;
				colvarKeywords.DefaultSetting = @"";
				colvarKeywords.ForeignKeyTableName = "";
				schema.Columns.Add(colvarKeywords);
				
				TableSchema.TableColumn colvarCreatedOn = new TableSchema.TableColumn(schema);
				colvarCreatedOn.ColumnName = "CreatedOn";
				colvarCreatedOn.DataType = DbType.DateTime;
				colvarCreatedOn.MaxLength = 0;
				colvarCreatedOn.AutoIncrement = false;
				colvarCreatedOn.IsNullable = false;
				colvarCreatedOn.IsPrimaryKey = false;
				colvarCreatedOn.IsForeignKey = false;
				colvarCreatedOn.IsReadOnly = false;
				colvarCreatedOn.DefaultSetting = @"";
				colvarCreatedOn.ForeignKeyTableName = "";
				schema.Columns.Add(colvarCreatedOn);
				
				TableSchema.TableColumn colvarCreatedBy = new TableSchema.TableColumn(schema);
				colvarCreatedBy.ColumnName = "CreatedBy";
				colvarCreatedBy.DataType = DbType.String;
				colvarCreatedBy.MaxLength = 50;
				colvarCreatedBy.AutoIncrement = false;
				colvarCreatedBy.IsNullable = true;
				colvarCreatedBy.IsPrimaryKey = false;
				colvarCreatedBy.IsForeignKey = false;
				colvarCreatedBy.IsReadOnly = false;
				colvarCreatedBy.DefaultSetting = @"";
				colvarCreatedBy.ForeignKeyTableName = "";
				schema.Columns.Add(colvarCreatedBy);
				
				TableSchema.TableColumn colvarModifiedOn = new TableSchema.TableColumn(schema);
				colvarModifiedOn.ColumnName = "ModifiedOn";
				colvarModifiedOn.DataType = DbType.DateTime;
				colvarModifiedOn.MaxLength = 0;
				colvarModifiedOn.AutoIncrement = false;
				colvarModifiedOn.IsNullable = false;
				colvarModifiedOn.IsPrimaryKey = false;
				colvarModifiedOn.IsForeignKey = false;
				colvarModifiedOn.IsReadOnly = false;
				colvarModifiedOn.DefaultSetting = @"";
				colvarModifiedOn.ForeignKeyTableName = "";
				schema.Columns.Add(colvarModifiedOn);
				
				TableSchema.TableColumn colvarModifiedBy = new TableSchema.TableColumn(schema);
				colvarModifiedBy.ColumnName = "ModifiedBy";
				colvarModifiedBy.DataType = DbType.String;
				colvarModifiedBy.MaxLength = 50;
				colvarModifiedBy.AutoIncrement = false;
				colvarModifiedBy.IsNullable = true;
				colvarModifiedBy.IsPrimaryKey = false;
				colvarModifiedBy.IsForeignKey = false;
				colvarModifiedBy.IsReadOnly = false;
				colvarModifiedBy.DefaultSetting = @"";
				colvarModifiedBy.ForeignKeyTableName = "";
				schema.Columns.Add(colvarModifiedBy);
				
				TableSchema.TableColumn colvarDeleted = new TableSchema.TableColumn(schema);
				colvarDeleted.ColumnName = "Deleted";
				colvarDeleted.DataType = DbType.Boolean;
				colvarDeleted.MaxLength = 0;
				colvarDeleted.AutoIncrement = false;
				colvarDeleted.IsNullable = false;
				colvarDeleted.IsPrimaryKey = false;
				colvarDeleted.IsForeignKey = false;
				colvarDeleted.IsReadOnly = false;
				colvarDeleted.DefaultSetting = @"";
				colvarDeleted.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDeleted);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("CMS_Page",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("PageID")]
		public int PageID 
		{
			get { return GetColumnValue<int>("PageID"); }

			set { SetColumnValue("PageID", value); }

		}

		  
		[XmlAttribute("Title")]
		public string Title 
		{
			get { return GetColumnValue<string>("Title"); }

			set { SetColumnValue("Title", value); }

		}

		  
		[XmlAttribute("Body")]
		public string Body 
		{
			get { return GetColumnValue<string>("Body"); }

			set { SetColumnValue("Body", value); }

		}

		  
		[XmlAttribute("Locale")]
		public string Locale 
		{
			get { return GetColumnValue<string>("Locale"); }

			set { SetColumnValue("Locale", value); }

		}

		  
		[XmlAttribute("ParentID")]
		public int? ParentID 
		{
			get { return GetColumnValue<int?>("ParentID"); }

			set { SetColumnValue("ParentID", value); }

		}

		  
		[XmlAttribute("PageGuid")]
		public Guid PageGuid 
		{
			get { return GetColumnValue<Guid>("PageGuid"); }

			set { SetColumnValue("PageGuid", value); }

		}

		  
		[XmlAttribute("MenuTitle")]
		public string MenuTitle 
		{
			get { return GetColumnValue<string>("MenuTitle"); }

			set { SetColumnValue("MenuTitle", value); }

		}

		  
		[XmlAttribute("Roles")]
		public string Roles 
		{
			get { return GetColumnValue<string>("Roles"); }

			set { SetColumnValue("Roles", value); }

		}

		  
		[XmlAttribute("Summary")]
		public string Summary 
		{
			get { return GetColumnValue<string>("Summary"); }

			set { SetColumnValue("Summary", value); }

		}

		  
		[XmlAttribute("PageUrl")]
		public string PageUrl 
		{
			get { return GetColumnValue<string>("PageUrl"); }

			set { SetColumnValue("PageUrl", value); }

		}

		  
		[XmlAttribute("Keywords")]
		public string Keywords 
		{
			get { return GetColumnValue<string>("Keywords"); }

			set { SetColumnValue("Keywords", value); }

		}

		  
		[XmlAttribute("CreatedOn")]
		public DateTime CreatedOn 
		{
			get { return GetColumnValue<DateTime>("CreatedOn"); }

			set { SetColumnValue("CreatedOn", value); }

		}

		  
		[XmlAttribute("CreatedBy")]
		public string CreatedBy 
		{
			get { return GetColumnValue<string>("CreatedBy"); }

			set { SetColumnValue("CreatedBy", value); }

		}

		  
		[XmlAttribute("ModifiedOn")]
		public DateTime ModifiedOn 
		{
			get { return GetColumnValue<DateTime>("ModifiedOn"); }

			set { SetColumnValue("ModifiedOn", value); }

		}

		  
		[XmlAttribute("ModifiedBy")]
		public string ModifiedBy 
		{
			get { return GetColumnValue<string>("ModifiedBy"); }

			set { SetColumnValue("ModifiedBy", value); }

		}

		  
		[XmlAttribute("Deleted")]
		public bool Deleted 
		{
			get { return GetColumnValue<bool>("Deleted"); }

			set { SetColumnValue("Deleted", value); }

		}

		
		#endregion
		
		
			
		
		//no foreign key tables defined (0)
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varTitle,string varBody,string varLocale,int? varParentID,Guid varPageGuid,string varMenuTitle,string varRoles,string varSummary,string varPageUrl,string varKeywords,DateTime varCreatedOn,string varCreatedBy,DateTime varModifiedOn,string varModifiedBy,bool varDeleted)
		{
			CmsPage item = new CmsPage();
			
			item.Title = varTitle;
			
			item.Body = varBody;
			
			item.Locale = varLocale;
			
			item.ParentID = varParentID;
			
			item.PageGuid = varPageGuid;
			
			item.MenuTitle = varMenuTitle;
			
			item.Roles = varRoles;
			
			item.Summary = varSummary;
			
			item.PageUrl = varPageUrl;
			
			item.Keywords = varKeywords;
			
			item.CreatedOn = varCreatedOn;
			
			item.CreatedBy = varCreatedBy;
			
			item.ModifiedOn = varModifiedOn;
			
			item.ModifiedBy = varModifiedBy;
			
			item.Deleted = varDeleted;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varPageID,string varTitle,string varBody,string varLocale,int? varParentID,Guid varPageGuid,string varMenuTitle,string varRoles,string varSummary,string varPageUrl,string varKeywords,DateTime varCreatedOn,string varCreatedBy,DateTime varModifiedOn,string varModifiedBy,bool varDeleted)
		{
			CmsPage item = new CmsPage();
			
				item.PageID = varPageID;
				
				item.Title = varTitle;
				
				item.Body = varBody;
				
				item.Locale = varLocale;
				
				item.ParentID = varParentID;
				
				item.PageGuid = varPageGuid;
				
				item.MenuTitle = varMenuTitle;
				
				item.Roles = varRoles;
				
				item.Summary = varSummary;
				
				item.PageUrl = varPageUrl;
				
				item.Keywords = varKeywords;
				
				item.CreatedOn = varCreatedOn;
				
				item.CreatedBy = varCreatedBy;
				
				item.ModifiedOn = varModifiedOn;
				
				item.ModifiedBy = varModifiedBy;
				
				item.Deleted = varDeleted;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string PageID = @"PageID";
			 public static string Title = @"Title";
			 public static string Body = @"Body";
			 public static string Locale = @"Locale";
			 public static string ParentID = @"ParentID";
			 public static string PageGuid = @"PageGuid";
			 public static string MenuTitle = @"MenuTitle";
			 public static string Roles = @"Roles";
			 public static string Summary = @"Summary";
			 public static string PageUrl = @"PageUrl";
			 public static string Keywords = @"Keywords";
			 public static string CreatedOn = @"CreatedOn";
			 public static string CreatedBy = @"CreatedBy";
			 public static string ModifiedOn = @"ModifiedOn";
			 public static string ModifiedBy = @"ModifiedBy";
			 public static string Deleted = @"Deleted";
						
		}

		#endregion
	}

}

