using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for CMS_Page
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class CmsPageController
    {
        // Preload our schema..
        CmsPage thisSchemaLoad = new CmsPage();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public CmsPageCollection FetchAll()
        {
            CmsPageCollection coll = new CmsPageCollection();
            Query qry = new Query(CmsPage.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public CmsPageCollection FetchByID(object PageID)
        {
            CmsPageCollection coll = new CmsPageCollection().Where("PageID", PageID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public CmsPageCollection FetchByQuery(Query qry)
        {
            CmsPageCollection coll = new CmsPageCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object PageID)
        {
            return (CmsPage.Delete(PageID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object PageID)
        {
            return (CmsPage.Destroy(PageID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string Title,string Body,string Locale,int? ParentID,Guid PageGuid,string MenuTitle,string Roles,string Summary,string PageUrl,string Keywords,DateTime CreatedOn,string CreatedBy,DateTime ModifiedOn,string ModifiedBy,bool Deleted)
	    {
		    CmsPage item = new CmsPage();
		    
            item.Title = Title;
            
            item.Body = Body;
            
            item.Locale = Locale;
            
            item.ParentID = ParentID;
            
            item.PageGuid = PageGuid;
            
            item.MenuTitle = MenuTitle;
            
            item.Roles = Roles;
            
            item.Summary = Summary;
            
            item.PageUrl = PageUrl;
            
            item.Keywords = Keywords;
            
            item.CreatedOn = CreatedOn;
            
            item.CreatedBy = CreatedBy;
            
            item.ModifiedOn = ModifiedOn;
            
            item.ModifiedBy = ModifiedBy;
            
            item.Deleted = Deleted;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int PageID,string Title,string Body,string Locale,int? ParentID,Guid PageGuid,string MenuTitle,string Roles,string Summary,string PageUrl,string Keywords,DateTime CreatedOn,string CreatedBy,DateTime ModifiedOn,string ModifiedBy,bool Deleted)
	    {
		    CmsPage item = new CmsPage();
		    
				item.PageID = PageID;
				
				item.Title = Title;
				
				item.Body = Body;
				
				item.Locale = Locale;
				
				item.ParentID = ParentID;
				
				item.PageGuid = PageGuid;
				
				item.MenuTitle = MenuTitle;
				
				item.Roles = Roles;
				
				item.Summary = Summary;
				
				item.PageUrl = PageUrl;
				
				item.Keywords = Keywords;
				
				item.CreatedOn = CreatedOn;
				
				item.CreatedBy = CreatedBy;
				
				item.ModifiedOn = ModifiedOn;
				
				item.ModifiedBy = ModifiedBy;
				
				item.Deleted = Deleted;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

