using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_Forum
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class ForumController
    {
        // Preload our schema..
        Forum thisSchemaLoad = new Forum();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public ForumCollection FetchAll()
        {
            ForumCollection coll = new ForumCollection();
            Query qry = new Query(Forum.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public ForumCollection FetchByID(object ForumID)
        {
            ForumCollection coll = new ForumCollection().Where("ForumID", ForumID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public ForumCollection FetchByQuery(Query qry)
        {
            ForumCollection coll = new ForumCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object ForumID)
        {
            return (Forum.Delete(ForumID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object ForumID)
        {
            return (Forum.Destroy(ForumID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string ForumName,string Description,string ForumUrl,int GroupID,string ListOrder,string CreatedBy,DateTime CreatedOn,string ModifiedBy,DateTime ModifiedOn,bool Deleted)
	    {
		    Forum item = new Forum();
		    
            item.ForumName = ForumName;
            
            item.Description = Description;
            
            item.ForumUrl = ForumUrl;
            
            item.GroupID = GroupID;
            
            item.ListOrder = ListOrder;
            
            item.CreatedBy = CreatedBy;
            
            item.CreatedOn = CreatedOn;
            
            item.ModifiedBy = ModifiedBy;
            
            item.ModifiedOn = ModifiedOn;
            
            item.Deleted = Deleted;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int ForumID,string ForumName,string Description,string ForumUrl,int GroupID,string ListOrder,string CreatedBy,DateTime CreatedOn,string ModifiedBy,DateTime ModifiedOn,bool Deleted)
	    {
		    Forum item = new Forum();
		    
				item.ForumID = ForumID;
				
				item.ForumName = ForumName;
				
				item.Description = Description;
				
				item.ForumUrl = ForumUrl;
				
				item.GroupID = GroupID;
				
				item.ListOrder = ListOrder;
				
				item.CreatedBy = CreatedBy;
				
				item.CreatedOn = CreatedOn;
				
				item.ModifiedBy = ModifiedBy;
				
				item.ModifiedOn = ModifiedOn;
				
				item.Deleted = Deleted;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

