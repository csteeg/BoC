using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the MailQueue class.
	/// </summary>
	[Serializable]
	public partial class MailQueueCollection : ActiveList<MailQueue, MailQueueCollection> 
	{	   
		public MailQueueCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_MailQueue table.
	/// </summary>
	[Serializable]
	public partial class MailQueue : ActiveRecord<MailQueue>
	{
		#region .ctors and Default Settings
		
		public MailQueue()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public MailQueue(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public MailQueue(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public MailQueue(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_MailQueue", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarMailerID = new TableSchema.TableColumn(schema);
				colvarMailerID.ColumnName = "MailerID";
				colvarMailerID.DataType = DbType.Int32;
				colvarMailerID.MaxLength = 0;
				colvarMailerID.AutoIncrement = true;
				colvarMailerID.IsNullable = false;
				colvarMailerID.IsPrimaryKey = true;
				colvarMailerID.IsForeignKey = false;
				colvarMailerID.IsReadOnly = false;
				colvarMailerID.DefaultSetting = @"";
				colvarMailerID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarMailerID);
				
				TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
				colvarUserName.ColumnName = "UserName";
				colvarUserName.DataType = DbType.String;
				colvarUserName.MaxLength = 50;
				colvarUserName.AutoIncrement = false;
				colvarUserName.IsNullable = false;
				colvarUserName.IsPrimaryKey = false;
				colvarUserName.IsForeignKey = false;
				colvarUserName.IsReadOnly = false;
				colvarUserName.DefaultSetting = @"";
				colvarUserName.ForeignKeyTableName = "";
				schema.Columns.Add(colvarUserName);
				
				TableSchema.TableColumn colvarEmail = new TableSchema.TableColumn(schema);
				colvarEmail.ColumnName = "Email";
				colvarEmail.DataType = DbType.String;
				colvarEmail.MaxLength = 50;
				colvarEmail.AutoIncrement = false;
				colvarEmail.IsNullable = false;
				colvarEmail.IsPrimaryKey = false;
				colvarEmail.IsForeignKey = false;
				colvarEmail.IsReadOnly = false;
				colvarEmail.DefaultSetting = @"";
				colvarEmail.ForeignKeyTableName = "";
				schema.Columns.Add(colvarEmail);
				
				TableSchema.TableColumn colvarSubject = new TableSchema.TableColumn(schema);
				colvarSubject.ColumnName = "Subject";
				colvarSubject.DataType = DbType.String;
				colvarSubject.MaxLength = 50;
				colvarSubject.AutoIncrement = false;
				colvarSubject.IsNullable = false;
				colvarSubject.IsPrimaryKey = false;
				colvarSubject.IsForeignKey = false;
				colvarSubject.IsReadOnly = false;
				colvarSubject.DefaultSetting = @"";
				colvarSubject.ForeignKeyTableName = "";
				schema.Columns.Add(colvarSubject);
				
				TableSchema.TableColumn colvarBody = new TableSchema.TableColumn(schema);
				colvarBody.ColumnName = "Body";
				colvarBody.DataType = DbType.String;
				colvarBody.MaxLength = 2500;
				colvarBody.AutoIncrement = false;
				colvarBody.IsNullable = false;
				colvarBody.IsPrimaryKey = false;
				colvarBody.IsForeignKey = false;
				colvarBody.IsReadOnly = false;
				colvarBody.DefaultSetting = @"";
				colvarBody.ForeignKeyTableName = "";
				schema.Columns.Add(colvarBody);
				
				TableSchema.TableColumn colvarIsHtml = new TableSchema.TableColumn(schema);
				colvarIsHtml.ColumnName = "IsHtml";
				colvarIsHtml.DataType = DbType.Boolean;
				colvarIsHtml.MaxLength = 0;
				colvarIsHtml.AutoIncrement = false;
				colvarIsHtml.IsNullable = false;
				colvarIsHtml.IsPrimaryKey = false;
				colvarIsHtml.IsForeignKey = false;
				colvarIsHtml.IsReadOnly = false;
				
						colvarIsHtml.DefaultSetting = @"((1))";
				colvarIsHtml.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsHtml);
				
				TableSchema.TableColumn colvarQueueDate = new TableSchema.TableColumn(schema);
				colvarQueueDate.ColumnName = "QueueDate";
				colvarQueueDate.DataType = DbType.DateTime;
				colvarQueueDate.MaxLength = 0;
				colvarQueueDate.AutoIncrement = false;
				colvarQueueDate.IsNullable = false;
				colvarQueueDate.IsPrimaryKey = false;
				colvarQueueDate.IsForeignKey = false;
				colvarQueueDate.IsReadOnly = false;
				
						colvarQueueDate.DefaultSetting = @"(getdate())";
				colvarQueueDate.ForeignKeyTableName = "";
				schema.Columns.Add(colvarQueueDate);
				
				TableSchema.TableColumn colvarSendDate = new TableSchema.TableColumn(schema);
				colvarSendDate.ColumnName = "SendDate";
				colvarSendDate.DataType = DbType.DateTime;
				colvarSendDate.MaxLength = 0;
				colvarSendDate.AutoIncrement = false;
				colvarSendDate.IsNullable = true;
				colvarSendDate.IsPrimaryKey = false;
				colvarSendDate.IsForeignKey = false;
				colvarSendDate.IsReadOnly = false;
				colvarSendDate.DefaultSetting = @"";
				colvarSendDate.ForeignKeyTableName = "";
				schema.Columns.Add(colvarSendDate);
				
				TableSchema.TableColumn colvarSMTPResponse = new TableSchema.TableColumn(schema);
				colvarSMTPResponse.ColumnName = "SMTPResponse";
				colvarSMTPResponse.DataType = DbType.String;
				colvarSMTPResponse.MaxLength = 500;
				colvarSMTPResponse.AutoIncrement = false;
				colvarSMTPResponse.IsNullable = true;
				colvarSMTPResponse.IsPrimaryKey = false;
				colvarSMTPResponse.IsForeignKey = false;
				colvarSMTPResponse.IsReadOnly = false;
				colvarSMTPResponse.DefaultSetting = @"";
				colvarSMTPResponse.ForeignKeyTableName = "";
				schema.Columns.Add(colvarSMTPResponse);
				
				TableSchema.TableColumn colvarWasSent = new TableSchema.TableColumn(schema);
				colvarWasSent.ColumnName = "WasSent";
				colvarWasSent.DataType = DbType.Boolean;
				colvarWasSent.MaxLength = 0;
				colvarWasSent.AutoIncrement = false;
				colvarWasSent.IsNullable = false;
				colvarWasSent.IsPrimaryKey = false;
				colvarWasSent.IsForeignKey = false;
				colvarWasSent.IsReadOnly = false;
				
						colvarWasSent.DefaultSetting = @"((0))";
				colvarWasSent.ForeignKeyTableName = "";
				schema.Columns.Add(colvarWasSent);
				
				TableSchema.TableColumn colvarRetryCount = new TableSchema.TableColumn(schema);
				colvarRetryCount.ColumnName = "RetryCount";
				colvarRetryCount.DataType = DbType.Int32;
				colvarRetryCount.MaxLength = 0;
				colvarRetryCount.AutoIncrement = false;
				colvarRetryCount.IsNullable = false;
				colvarRetryCount.IsPrimaryKey = false;
				colvarRetryCount.IsForeignKey = false;
				colvarRetryCount.IsReadOnly = false;
				
						colvarRetryCount.DefaultSetting = @"((5))";
				colvarRetryCount.ForeignKeyTableName = "";
				schema.Columns.Add(colvarRetryCount);
				
				TableSchema.TableColumn colvarShouldSend = new TableSchema.TableColumn(schema);
				colvarShouldSend.ColumnName = "ShouldSend";
				colvarShouldSend.DataType = DbType.Boolean;
				colvarShouldSend.MaxLength = 0;
				colvarShouldSend.AutoIncrement = false;
				colvarShouldSend.IsNullable = false;
				colvarShouldSend.IsPrimaryKey = false;
				colvarShouldSend.IsForeignKey = false;
				colvarShouldSend.IsReadOnly = false;
				
						colvarShouldSend.DefaultSetting = @"((1))";
				colvarShouldSend.ForeignKeyTableName = "";
				schema.Columns.Add(colvarShouldSend);
				
				TableSchema.TableColumn colvarLastTry = new TableSchema.TableColumn(schema);
				colvarLastTry.ColumnName = "LastTry";
				colvarLastTry.DataType = DbType.DateTime;
				colvarLastTry.MaxLength = 0;
				colvarLastTry.AutoIncrement = false;
				colvarLastTry.IsNullable = true;
				colvarLastTry.IsPrimaryKey = false;
				colvarLastTry.IsForeignKey = false;
				colvarLastTry.IsReadOnly = false;
				colvarLastTry.DefaultSetting = @"";
				colvarLastTry.ForeignKeyTableName = "";
				schema.Columns.Add(colvarLastTry);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_MailQueue",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("MailerID")]
		public int MailerID 
		{
			get { return GetColumnValue<int>("MailerID"); }

			set { SetColumnValue("MailerID", value); }

		}

		  
		[XmlAttribute("UserName")]
		public string UserName 
		{
			get { return GetColumnValue<string>("UserName"); }

			set { SetColumnValue("UserName", value); }

		}

		  
		[XmlAttribute("Email")]
		public string Email 
		{
			get { return GetColumnValue<string>("Email"); }

			set { SetColumnValue("Email", value); }

		}

		  
		[XmlAttribute("Subject")]
		public string Subject 
		{
			get { return GetColumnValue<string>("Subject"); }

			set { SetColumnValue("Subject", value); }

		}

		  
		[XmlAttribute("Body")]
		public string Body 
		{
			get { return GetColumnValue<string>("Body"); }

			set { SetColumnValue("Body", value); }

		}

		  
		[XmlAttribute("IsHtml")]
		public bool IsHtml 
		{
			get { return GetColumnValue<bool>("IsHtml"); }

			set { SetColumnValue("IsHtml", value); }

		}

		  
		[XmlAttribute("QueueDate")]
		public DateTime QueueDate 
		{
			get { return GetColumnValue<DateTime>("QueueDate"); }

			set { SetColumnValue("QueueDate", value); }

		}

		  
		[XmlAttribute("SendDate")]
		public DateTime? SendDate 
		{
			get { return GetColumnValue<DateTime?>("SendDate"); }

			set { SetColumnValue("SendDate", value); }

		}

		  
		[XmlAttribute("SMTPResponse")]
		public string SMTPResponse 
		{
			get { return GetColumnValue<string>("SMTPResponse"); }

			set { SetColumnValue("SMTPResponse", value); }

		}

		  
		[XmlAttribute("WasSent")]
		public bool WasSent 
		{
			get { return GetColumnValue<bool>("WasSent"); }

			set { SetColumnValue("WasSent", value); }

		}

		  
		[XmlAttribute("RetryCount")]
		public int RetryCount 
		{
			get { return GetColumnValue<int>("RetryCount"); }

			set { SetColumnValue("RetryCount", value); }

		}

		  
		[XmlAttribute("ShouldSend")]
		public bool ShouldSend 
		{
			get { return GetColumnValue<bool>("ShouldSend"); }

			set { SetColumnValue("ShouldSend", value); }

		}

		  
		[XmlAttribute("LastTry")]
		public DateTime? LastTry 
		{
			get { return GetColumnValue<DateTime?>("LastTry"); }

			set { SetColumnValue("LastTry", value); }

		}

		
		#endregion
		
		
			
		
		//no foreign key tables defined (0)
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varUserName,string varEmail,string varSubject,string varBody,bool varIsHtml,DateTime varQueueDate,DateTime? varSendDate,string varSMTPResponse,bool varWasSent,int varRetryCount,bool varShouldSend,DateTime? varLastTry)
		{
			MailQueue item = new MailQueue();
			
			item.UserName = varUserName;
			
			item.Email = varEmail;
			
			item.Subject = varSubject;
			
			item.Body = varBody;
			
			item.IsHtml = varIsHtml;
			
			item.QueueDate = varQueueDate;
			
			item.SendDate = varSendDate;
			
			item.SMTPResponse = varSMTPResponse;
			
			item.WasSent = varWasSent;
			
			item.RetryCount = varRetryCount;
			
			item.ShouldSend = varShouldSend;
			
			item.LastTry = varLastTry;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varMailerID,string varUserName,string varEmail,string varSubject,string varBody,bool varIsHtml,DateTime varQueueDate,DateTime? varSendDate,string varSMTPResponse,bool varWasSent,int varRetryCount,bool varShouldSend,DateTime? varLastTry)
		{
			MailQueue item = new MailQueue();
			
				item.MailerID = varMailerID;
				
				item.UserName = varUserName;
				
				item.Email = varEmail;
				
				item.Subject = varSubject;
				
				item.Body = varBody;
				
				item.IsHtml = varIsHtml;
				
				item.QueueDate = varQueueDate;
				
				item.SendDate = varSendDate;
				
				item.SMTPResponse = varSMTPResponse;
				
				item.WasSent = varWasSent;
				
				item.RetryCount = varRetryCount;
				
				item.ShouldSend = varShouldSend;
				
				item.LastTry = varLastTry;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string MailerID = @"MailerID";
			 public static string UserName = @"UserName";
			 public static string Email = @"Email";
			 public static string Subject = @"Subject";
			 public static string Body = @"Body";
			 public static string IsHtml = @"IsHtml";
			 public static string QueueDate = @"QueueDate";
			 public static string SendDate = @"SendDate";
			 public static string SMTPResponse = @"SMTPResponse";
			 public static string WasSent = @"WasSent";
			 public static string RetryCount = @"RetryCount";
			 public static string ShouldSend = @"ShouldSend";
			 public static string LastTry = @"LastTry";
						
		}

		#endregion
	}

}

