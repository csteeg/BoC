using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
    /// <summary>
    /// Controller class for SS_MailQueue
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class MailQueueController
    {
        // Preload our schema..
        MailQueue thisSchemaLoad = new MailQueue();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public MailQueueCollection FetchAll()
        {
            MailQueueCollection coll = new MailQueueCollection();
            Query qry = new Query(MailQueue.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public MailQueueCollection FetchByID(object MailerID)
        {
            MailQueueCollection coll = new MailQueueCollection().Where("MailerID", MailerID).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public MailQueueCollection FetchByQuery(Query qry)
        {
            MailQueueCollection coll = new MailQueueCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object MailerID)
        {
            return (MailQueue.Delete(MailerID) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object MailerID)
        {
            return (MailQueue.Destroy(MailerID) == 1);
        }

        
        
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string UserName,string Email,string Subject,string Body,bool IsHtml,DateTime QueueDate,DateTime? SendDate,string SMTPResponse,bool WasSent,int RetryCount,bool ShouldSend,DateTime? LastTry)
	    {
		    MailQueue item = new MailQueue();
		    
            item.UserName = UserName;
            
            item.Email = Email;
            
            item.Subject = Subject;
            
            item.Body = Body;
            
            item.IsHtml = IsHtml;
            
            item.QueueDate = QueueDate;
            
            item.SendDate = SendDate;
            
            item.SMTPResponse = SMTPResponse;
            
            item.WasSent = WasSent;
            
            item.RetryCount = RetryCount;
            
            item.ShouldSend = ShouldSend;
            
            item.LastTry = LastTry;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(int MailerID,string UserName,string Email,string Subject,string Body,bool IsHtml,DateTime QueueDate,DateTime? SendDate,string SMTPResponse,bool WasSent,int RetryCount,bool ShouldSend,DateTime? LastTry)
	    {
		    MailQueue item = new MailQueue();
		    
				item.MailerID = MailerID;
				
				item.UserName = UserName;
				
				item.Email = Email;
				
				item.Subject = Subject;
				
				item.Body = Body;
				
				item.IsHtml = IsHtml;
				
				item.QueueDate = QueueDate;
				
				item.SendDate = SendDate;
				
				item.SMTPResponse = SMTPResponse;
				
				item.WasSent = WasSent;
				
				item.RetryCount = RetryCount;
				
				item.ShouldSend = ShouldSend;
				
				item.LastTry = LastTry;
				
		    item.MarkOld();
		    item.Save(UserName);
	    }

    }

}

