using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the ApplicationLog class.
	/// </summary>
	[Serializable]
	public partial class ApplicationLogCollection : ActiveList<ApplicationLog, ApplicationLogCollection> 
	{	   
		public ApplicationLogCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_ApplicationLog table.
	/// </summary>
	[Serializable]
	public partial class ApplicationLog : ActiveRecord<ApplicationLog>
	{
		#region .ctors and Default Settings
		
		public ApplicationLog()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public ApplicationLog(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public ApplicationLog(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public ApplicationLog(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_ApplicationLog", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarLogID = new TableSchema.TableColumn(schema);
				colvarLogID.ColumnName = "LogID";
				colvarLogID.DataType = DbType.Int32;
				colvarLogID.MaxLength = 0;
				colvarLogID.AutoIncrement = true;
				colvarLogID.IsNullable = false;
				colvarLogID.IsPrimaryKey = true;
				colvarLogID.IsForeignKey = false;
				colvarLogID.IsReadOnly = false;
				colvarLogID.DefaultSetting = @"";
				colvarLogID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarLogID);
				
				TableSchema.TableColumn colvarContext = new TableSchema.TableColumn(schema);
				colvarContext.ColumnName = "Context";
				colvarContext.DataType = DbType.String;
				colvarContext.MaxLength = 50;
				colvarContext.AutoIncrement = false;
				colvarContext.IsNullable = false;
				colvarContext.IsPrimaryKey = false;
				colvarContext.IsForeignKey = false;
				colvarContext.IsReadOnly = false;
				colvarContext.DefaultSetting = @"";
				colvarContext.ForeignKeyTableName = "";
				schema.Columns.Add(colvarContext);
				
				TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
				colvarDescription.ColumnName = "Description";
				colvarDescription.DataType = DbType.String;
				colvarDescription.MaxLength = 1500;
				colvarDescription.AutoIncrement = false;
				colvarDescription.IsNullable = false;
				colvarDescription.IsPrimaryKey = false;
				colvarDescription.IsForeignKey = false;
				colvarDescription.IsReadOnly = false;
				colvarDescription.DefaultSetting = @"";
				colvarDescription.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDescription);
				
				TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
				colvarUserName.ColumnName = "UserName";
				colvarUserName.DataType = DbType.String;
				colvarUserName.MaxLength = 50;
				colvarUserName.AutoIncrement = false;
				colvarUserName.IsNullable = false;
				colvarUserName.IsPrimaryKey = false;
				colvarUserName.IsForeignKey = false;
				colvarUserName.IsReadOnly = false;
				colvarUserName.DefaultSetting = @"";
				colvarUserName.ForeignKeyTableName = "";
				schema.Columns.Add(colvarUserName);
				
				TableSchema.TableColumn colvarExtraInfo = new TableSchema.TableColumn(schema);
				colvarExtraInfo.ColumnName = "ExtraInfo";
				colvarExtraInfo.DataType = DbType.String;
				colvarExtraInfo.MaxLength = 2500;
				colvarExtraInfo.AutoIncrement = false;
				colvarExtraInfo.IsNullable = true;
				colvarExtraInfo.IsPrimaryKey = false;
				colvarExtraInfo.IsForeignKey = false;
				colvarExtraInfo.IsReadOnly = false;
				colvarExtraInfo.DefaultSetting = @"";
				colvarExtraInfo.ForeignKeyTableName = "";
				schema.Columns.Add(colvarExtraInfo);
				
				TableSchema.TableColumn colvarLogDate = new TableSchema.TableColumn(schema);
				colvarLogDate.ColumnName = "LogDate";
				colvarLogDate.DataType = DbType.DateTime;
				colvarLogDate.MaxLength = 0;
				colvarLogDate.AutoIncrement = false;
				colvarLogDate.IsNullable = false;
				colvarLogDate.IsPrimaryKey = false;
				colvarLogDate.IsForeignKey = false;
				colvarLogDate.IsReadOnly = false;
				
						colvarLogDate.DefaultSetting = @"(getdate())";
				colvarLogDate.ForeignKeyTableName = "";
				schema.Columns.Add(colvarLogDate);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_ApplicationLog",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("LogID")]
		public int LogID 
		{
			get { return GetColumnValue<int>("LogID"); }

			set { SetColumnValue("LogID", value); }

		}

		  
		[XmlAttribute("Context")]
		public string Context 
		{
			get { return GetColumnValue<string>("Context"); }

			set { SetColumnValue("Context", value); }

		}

		  
		[XmlAttribute("Description")]
		public string Description 
		{
			get { return GetColumnValue<string>("Description"); }

			set { SetColumnValue("Description", value); }

		}

		  
		[XmlAttribute("UserName")]
		public string UserName 
		{
			get { return GetColumnValue<string>("UserName"); }

			set { SetColumnValue("UserName", value); }

		}

		  
		[XmlAttribute("ExtraInfo")]
		public string ExtraInfo 
		{
			get { return GetColumnValue<string>("ExtraInfo"); }

			set { SetColumnValue("ExtraInfo", value); }

		}

		  
		[XmlAttribute("LogDate")]
		public DateTime LogDate 
		{
			get { return GetColumnValue<DateTime>("LogDate"); }

			set { SetColumnValue("LogDate", value); }

		}

		
		#endregion
		
		
			
		
		//no foreign key tables defined (0)
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varContext,string varDescription,string varUserName,string varExtraInfo,DateTime varLogDate)
		{
			ApplicationLog item = new ApplicationLog();
			
			item.Context = varContext;
			
			item.Description = varDescription;
			
			item.UserName = varUserName;
			
			item.ExtraInfo = varExtraInfo;
			
			item.LogDate = varLogDate;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varLogID,string varContext,string varDescription,string varUserName,string varExtraInfo,DateTime varLogDate)
		{
			ApplicationLog item = new ApplicationLog();
			
				item.LogID = varLogID;
				
				item.Context = varContext;
				
				item.Description = varDescription;
				
				item.UserName = varUserName;
				
				item.ExtraInfo = varExtraInfo;
				
				item.LogDate = varLogDate;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string LogID = @"LogID";
			 public static string Context = @"Context";
			 public static string Description = @"Description";
			 public static string UserName = @"UserName";
			 public static string ExtraInfo = @"ExtraInfo";
			 public static string LogDate = @"LogDate";
						
		}

		#endregion
	}

}

