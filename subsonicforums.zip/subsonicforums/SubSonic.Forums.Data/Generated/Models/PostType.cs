using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the PostType class.
	/// </summary>
	[Serializable]
	public partial class PostTypeCollection : ActiveList<PostType, PostTypeCollection> 
	{	   
		public PostTypeCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_PostType table.
	/// </summary>
	[Serializable]
	public partial class PostType : ActiveRecord<PostType>
	{
		#region .ctors and Default Settings
		
		public PostType()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public PostType(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public PostType(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public PostType(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_PostType", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarPostTypeID = new TableSchema.TableColumn(schema);
				colvarPostTypeID.ColumnName = "PostTypeID";
				colvarPostTypeID.DataType = DbType.Int32;
				colvarPostTypeID.MaxLength = 0;
				colvarPostTypeID.AutoIncrement = true;
				colvarPostTypeID.IsNullable = false;
				colvarPostTypeID.IsPrimaryKey = true;
				colvarPostTypeID.IsForeignKey = false;
				colvarPostTypeID.IsReadOnly = false;
				colvarPostTypeID.DefaultSetting = @"";
				colvarPostTypeID.ForeignKeyTableName = "";
				schema.Columns.Add(colvarPostTypeID);
				
				TableSchema.TableColumn colvarDescription = new TableSchema.TableColumn(schema);
				colvarDescription.ColumnName = "Description";
				colvarDescription.DataType = DbType.String;
				colvarDescription.MaxLength = 50;
				colvarDescription.AutoIncrement = false;
				colvarDescription.IsNullable = false;
				colvarDescription.IsPrimaryKey = false;
				colvarDescription.IsForeignKey = false;
				colvarDescription.IsReadOnly = false;
				colvarDescription.DefaultSetting = @"";
				colvarDescription.ForeignKeyTableName = "";
				schema.Columns.Add(colvarDescription);
				
				TableSchema.TableColumn colvarIsResponse = new TableSchema.TableColumn(schema);
				colvarIsResponse.ColumnName = "IsResponse";
				colvarIsResponse.DataType = DbType.Boolean;
				colvarIsResponse.MaxLength = 0;
				colvarIsResponse.AutoIncrement = false;
				colvarIsResponse.IsNullable = false;
				colvarIsResponse.IsPrimaryKey = false;
				colvarIsResponse.IsForeignKey = false;
				colvarIsResponse.IsReadOnly = false;
				
						colvarIsResponse.DefaultSetting = @"((1))";
				colvarIsResponse.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsResponse);
				
				TableSchema.TableColumn colvarListOrder = new TableSchema.TableColumn(schema);
				colvarListOrder.ColumnName = "ListOrder";
				colvarListOrder.DataType = DbType.Int32;
				colvarListOrder.MaxLength = 0;
				colvarListOrder.AutoIncrement = false;
				colvarListOrder.IsNullable = false;
				colvarListOrder.IsPrimaryKey = false;
				colvarListOrder.IsForeignKey = false;
				colvarListOrder.IsReadOnly = false;
				
						colvarListOrder.DefaultSetting = @"((0))";
				colvarListOrder.ForeignKeyTableName = "";
				schema.Columns.Add(colvarListOrder);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_PostType",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("PostTypeID")]
		public int PostTypeID 
		{
			get { return GetColumnValue<int>("PostTypeID"); }

			set { SetColumnValue("PostTypeID", value); }

		}

		  
		[XmlAttribute("Description")]
		public string Description 
		{
			get { return GetColumnValue<string>("Description"); }

			set { SetColumnValue("Description", value); }

		}

		  
		[XmlAttribute("IsResponse")]
		public bool IsResponse 
		{
			get { return GetColumnValue<bool>("IsResponse"); }

			set { SetColumnValue("IsResponse", value); }

		}

		  
		[XmlAttribute("ListOrder")]
		public int ListOrder 
		{
			get { return GetColumnValue<int>("ListOrder"); }

			set { SetColumnValue("ListOrder", value); }

		}

		
		#endregion
		
		
		#region PrimaryKey Methods
		
		public SubSonic.Forums.PostCollection PostRecords()
		{
			return new SubSonic.Forums.PostCollection().Where(Post.Columns.PostTypeID, PostTypeID).Load();
		}

		#endregion
		
			
		
		//no foreign key tables defined (0)
		
		
		
		//no ManyToMany tables defined (0)
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varDescription,bool varIsResponse,int varListOrder)
		{
			PostType item = new PostType();
			
			item.Description = varDescription;
			
			item.IsResponse = varIsResponse;
			
			item.ListOrder = varListOrder;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(int varPostTypeID,string varDescription,bool varIsResponse,int varListOrder)
		{
			PostType item = new PostType();
			
				item.PostTypeID = varPostTypeID;
				
				item.Description = varDescription;
				
				item.IsResponse = varIsResponse;
				
				item.ListOrder = varListOrder;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string PostTypeID = @"PostTypeID";
			 public static string Description = @"Description";
			 public static string IsResponse = @"IsResponse";
			 public static string ListOrder = @"ListOrder";
						
		}

		#endregion
	}

}

