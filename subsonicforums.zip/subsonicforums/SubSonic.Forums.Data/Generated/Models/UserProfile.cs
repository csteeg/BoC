using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	/// <summary>
	/// Strongly-typed collection for the UserProfile class.
	/// </summary>
	[Serializable]
	public partial class UserProfileCollection : ActiveList<UserProfile, UserProfileCollection> 
	{	   
		public UserProfileCollection() {}

	}

	/// <summary>
	/// This is an ActiveRecord class which wraps the SS_UserProfile table.
	/// </summary>
	[Serializable]
	public partial class UserProfile : ActiveRecord<UserProfile>
	{
		#region .ctors and Default Settings
		
		public UserProfile()
		{
		  SetSQLProps();
		  InitSetDefaults();
		  MarkNew();
		}

		
		private void InitSetDefaults() { SetDefaults(); }

		
		public UserProfile(bool useDatabaseDefaults)
		{
			SetSQLProps();
			if(useDatabaseDefaults)
				ForceDefaults();
			MarkNew();
		}

		public UserProfile(object keyID)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByKey(keyID);
		}

		 
		public UserProfile(string columnName, object columnValue)
		{
			SetSQLProps();
			InitSetDefaults();
			LoadByParam(columnName,columnValue);
		}

		
		protected static void SetSQLProps() { GetTableSchema(); }

		
		#endregion
		
		#region Schema and Query Accessor
		public static Query CreateQuery() { return new Query(Schema); }

		
		public static TableSchema.Table Schema
		{
			get
			{
				if (BaseSchema == null)
					SetSQLProps();
				return BaseSchema;
			}

		}

		
		private static void GetTableSchema() 
		{
			if(!IsSchemaInitialized)
			{
				//Schema declaration
				TableSchema.Table schema = new TableSchema.Table("SS_UserProfile", TableType.Table, DataService.GetInstance("Forums"));
				schema.Columns = new TableSchema.TableColumnCollection();
				schema.SchemaName = @"dbo";
				//columns
				
				TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
				colvarUserName.ColumnName = "UserName";
				colvarUserName.DataType = DbType.String;
				colvarUserName.MaxLength = 50;
				colvarUserName.AutoIncrement = false;
				colvarUserName.IsNullable = false;
				colvarUserName.IsPrimaryKey = true;
				colvarUserName.IsForeignKey = false;
				colvarUserName.IsReadOnly = false;
				colvarUserName.DefaultSetting = @"";
				colvarUserName.ForeignKeyTableName = "";
				schema.Columns.Add(colvarUserName);
				
				TableSchema.TableColumn colvarTotalPosts = new TableSchema.TableColumn(schema);
				colvarTotalPosts.ColumnName = "TotalPosts";
				colvarTotalPosts.DataType = DbType.Int32;
				colvarTotalPosts.MaxLength = 0;
				colvarTotalPosts.AutoIncrement = false;
				colvarTotalPosts.IsNullable = false;
				colvarTotalPosts.IsPrimaryKey = false;
				colvarTotalPosts.IsForeignKey = false;
				colvarTotalPosts.IsReadOnly = false;
				
						colvarTotalPosts.DefaultSetting = @"((0))";
				colvarTotalPosts.ForeignKeyTableName = "";
				schema.Columns.Add(colvarTotalPosts);
				
				TableSchema.TableColumn colvarMemberSince = new TableSchema.TableColumn(schema);
				colvarMemberSince.ColumnName = "MemberSince";
				colvarMemberSince.DataType = DbType.DateTime;
				colvarMemberSince.MaxLength = 0;
				colvarMemberSince.AutoIncrement = false;
				colvarMemberSince.IsNullable = false;
				colvarMemberSince.IsPrimaryKey = false;
				colvarMemberSince.IsForeignKey = false;
				colvarMemberSince.IsReadOnly = false;
				
						colvarMemberSince.DefaultSetting = @"(getdate())";
				colvarMemberSince.ForeignKeyTableName = "";
				schema.Columns.Add(colvarMemberSince);
				
				TableSchema.TableColumn colvarEmail = new TableSchema.TableColumn(schema);
				colvarEmail.ColumnName = "Email";
				colvarEmail.DataType = DbType.String;
				colvarEmail.MaxLength = 50;
				colvarEmail.AutoIncrement = false;
				colvarEmail.IsNullable = false;
				colvarEmail.IsPrimaryKey = false;
				colvarEmail.IsForeignKey = false;
				colvarEmail.IsReadOnly = false;
				colvarEmail.DefaultSetting = @"";
				colvarEmail.ForeignKeyTableName = "";
				schema.Columns.Add(colvarEmail);
				
				TableSchema.TableColumn colvarSignature = new TableSchema.TableColumn(schema);
				colvarSignature.ColumnName = "Signature";
				colvarSignature.DataType = DbType.String;
				colvarSignature.MaxLength = 150;
				colvarSignature.AutoIncrement = false;
				colvarSignature.IsNullable = true;
				colvarSignature.IsPrimaryKey = false;
				colvarSignature.IsForeignKey = false;
				colvarSignature.IsReadOnly = false;
				colvarSignature.DefaultSetting = @"";
				colvarSignature.ForeignKeyTableName = "";
				schema.Columns.Add(colvarSignature);
				
				TableSchema.TableColumn colvarProps = new TableSchema.TableColumn(schema);
				colvarProps.ColumnName = "Props";
				colvarProps.DataType = DbType.Int32;
				colvarProps.MaxLength = 0;
				colvarProps.AutoIncrement = false;
				colvarProps.IsNullable = false;
				colvarProps.IsPrimaryKey = false;
				colvarProps.IsForeignKey = false;
				colvarProps.IsReadOnly = false;
				
						colvarProps.DefaultSetting = @"((0))";
				colvarProps.ForeignKeyTableName = "";
				schema.Columns.Add(colvarProps);
				
				TableSchema.TableColumn colvarIsApproved = new TableSchema.TableColumn(schema);
				colvarIsApproved.ColumnName = "IsApproved";
				colvarIsApproved.DataType = DbType.Boolean;
				colvarIsApproved.MaxLength = 0;
				colvarIsApproved.AutoIncrement = false;
				colvarIsApproved.IsNullable = false;
				colvarIsApproved.IsPrimaryKey = false;
				colvarIsApproved.IsForeignKey = false;
				colvarIsApproved.IsReadOnly = false;
				
						colvarIsApproved.DefaultSetting = @"((1))";
				colvarIsApproved.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsApproved);
				
				TableSchema.TableColumn colvarIsModerated = new TableSchema.TableColumn(schema);
				colvarIsModerated.ColumnName = "IsModerated";
				colvarIsModerated.DataType = DbType.Boolean;
				colvarIsModerated.MaxLength = 0;
				colvarIsModerated.AutoIncrement = false;
				colvarIsModerated.IsNullable = false;
				colvarIsModerated.IsPrimaryKey = false;
				colvarIsModerated.IsForeignKey = false;
				colvarIsModerated.IsReadOnly = false;
				
						colvarIsModerated.DefaultSetting = @"((0))";
				colvarIsModerated.ForeignKeyTableName = "";
				schema.Columns.Add(colvarIsModerated);
				
				TableSchema.TableColumn colvarBio = new TableSchema.TableColumn(schema);
				colvarBio.ColumnName = "Bio";
				colvarBio.DataType = DbType.String;
				colvarBio.MaxLength = 2500;
				colvarBio.AutoIncrement = false;
				colvarBio.IsNullable = true;
				colvarBio.IsPrimaryKey = false;
				colvarBio.IsForeignKey = false;
				colvarBio.IsReadOnly = false;
				colvarBio.DefaultSetting = @"";
				colvarBio.ForeignKeyTableName = "";
				schema.Columns.Add(colvarBio);
				
				TableSchema.TableColumn colvarTimeZone = new TableSchema.TableColumn(schema);
				colvarTimeZone.ColumnName = "TimeZone";
				colvarTimeZone.DataType = DbType.Double;
				colvarTimeZone.MaxLength = 0;
				colvarTimeZone.AutoIncrement = false;
				colvarTimeZone.IsNullable = true;
				colvarTimeZone.IsPrimaryKey = false;
				colvarTimeZone.IsForeignKey = false;
				colvarTimeZone.IsReadOnly = false;
				colvarTimeZone.DefaultSetting = @"";
				colvarTimeZone.ForeignKeyTableName = "";
				schema.Columns.Add(colvarTimeZone);
				
				TableSchema.TableColumn colvarHTMLEmail = new TableSchema.TableColumn(schema);
				colvarHTMLEmail.ColumnName = "HTMLEmail";
				colvarHTMLEmail.DataType = DbType.Boolean;
				colvarHTMLEmail.MaxLength = 0;
				colvarHTMLEmail.AutoIncrement = false;
				colvarHTMLEmail.IsNullable = false;
				colvarHTMLEmail.IsPrimaryKey = false;
				colvarHTMLEmail.IsForeignKey = false;
				colvarHTMLEmail.IsReadOnly = false;
				
						colvarHTMLEmail.DefaultSetting = @"((1))";
				colvarHTMLEmail.ForeignKeyTableName = "";
				schema.Columns.Add(colvarHTMLEmail);
				
				TableSchema.TableColumn colvarAllowEmailContact = new TableSchema.TableColumn(schema);
				colvarAllowEmailContact.ColumnName = "AllowEmailContact";
				colvarAllowEmailContact.DataType = DbType.Boolean;
				colvarAllowEmailContact.MaxLength = 0;
				colvarAllowEmailContact.AutoIncrement = false;
				colvarAllowEmailContact.IsNullable = false;
				colvarAllowEmailContact.IsPrimaryKey = false;
				colvarAllowEmailContact.IsForeignKey = false;
				colvarAllowEmailContact.IsReadOnly = false;
				
						colvarAllowEmailContact.DefaultSetting = @"((1))";
				colvarAllowEmailContact.ForeignKeyTableName = "";
				schema.Columns.Add(colvarAllowEmailContact);
				
				TableSchema.TableColumn colvarHelpfulKeywords = new TableSchema.TableColumn(schema);
				colvarHelpfulKeywords.ColumnName = "HelpfulKeywords";
				colvarHelpfulKeywords.DataType = DbType.String;
				colvarHelpfulKeywords.MaxLength = 250;
				colvarHelpfulKeywords.AutoIncrement = false;
				colvarHelpfulKeywords.IsNullable = true;
				colvarHelpfulKeywords.IsPrimaryKey = false;
				colvarHelpfulKeywords.IsForeignKey = false;
				colvarHelpfulKeywords.IsReadOnly = false;
				colvarHelpfulKeywords.DefaultSetting = @"";
				colvarHelpfulKeywords.ForeignKeyTableName = "";
				schema.Columns.Add(colvarHelpfulKeywords);
				
				TableSchema.TableColumn colvarUserRoles = new TableSchema.TableColumn(schema);
				colvarUserRoles.ColumnName = "UserRoles";
				colvarUserRoles.DataType = DbType.String;
				colvarUserRoles.MaxLength = 250;
				colvarUserRoles.AutoIncrement = false;
				colvarUserRoles.IsNullable = true;
				colvarUserRoles.IsPrimaryKey = false;
				colvarUserRoles.IsForeignKey = false;
				colvarUserRoles.IsReadOnly = false;
				colvarUserRoles.DefaultSetting = @"";
				colvarUserRoles.ForeignKeyTableName = "";
				schema.Columns.Add(colvarUserRoles);
				
				BaseSchema = schema;
				//add this schema to the provider
				//so we can query it later
				DataService.Providers["Forums"].AddSchema("SS_UserProfile",schema);
			}

		}

		#endregion
		
		#region Props
		
		  
		[XmlAttribute("UserName")]
		public string UserName 
		{
			get { return GetColumnValue<string>("UserName"); }

			set { SetColumnValue("UserName", value); }

		}

		  
		[XmlAttribute("TotalPosts")]
		public int TotalPosts 
		{
			get { return GetColumnValue<int>("TotalPosts"); }

			set { SetColumnValue("TotalPosts", value); }

		}

		  
		[XmlAttribute("MemberSince")]
		public DateTime MemberSince 
		{
			get { return GetColumnValue<DateTime>("MemberSince"); }

			set { SetColumnValue("MemberSince", value); }

		}

		  
		[XmlAttribute("Email")]
		public string Email 
		{
			get { return GetColumnValue<string>("Email"); }

			set { SetColumnValue("Email", value); }

		}

		  
		[XmlAttribute("Signature")]
		public string Signature 
		{
			get { return GetColumnValue<string>("Signature"); }

			set { SetColumnValue("Signature", value); }

		}

		  
		[XmlAttribute("Props")]
		public int Props 
		{
			get { return GetColumnValue<int>("Props"); }

			set { SetColumnValue("Props", value); }

		}

		  
		[XmlAttribute("IsApproved")]
		public bool IsApproved 
		{
			get { return GetColumnValue<bool>("IsApproved"); }

			set { SetColumnValue("IsApproved", value); }

		}

		  
		[XmlAttribute("IsModerated")]
		public bool IsModerated 
		{
			get { return GetColumnValue<bool>("IsModerated"); }

			set { SetColumnValue("IsModerated", value); }

		}

		  
		[XmlAttribute("Bio")]
		public string Bio 
		{
			get { return GetColumnValue<string>("Bio"); }

			set { SetColumnValue("Bio", value); }

		}

		  
		[XmlAttribute("TimeZone")]
		public double? TimeZone 
		{
			get { return GetColumnValue<double?>("TimeZone"); }

			set { SetColumnValue("TimeZone", value); }

		}

		  
		[XmlAttribute("HTMLEmail")]
		public bool HTMLEmail 
		{
			get { return GetColumnValue<bool>("HTMLEmail"); }

			set { SetColumnValue("HTMLEmail", value); }

		}

		  
		[XmlAttribute("AllowEmailContact")]
		public bool AllowEmailContact 
		{
			get { return GetColumnValue<bool>("AllowEmailContact"); }

			set { SetColumnValue("AllowEmailContact", value); }

		}

		  
		[XmlAttribute("HelpfulKeywords")]
		public string HelpfulKeywords 
		{
			get { return GetColumnValue<string>("HelpfulKeywords"); }

			set { SetColumnValue("HelpfulKeywords", value); }

		}

		  
		[XmlAttribute("UserRoles")]
		public string UserRoles 
		{
			get { return GetColumnValue<string>("UserRoles"); }

			set { SetColumnValue("UserRoles", value); }

		}

		
		#endregion
		
		
		#region PrimaryKey Methods
		
		public SubSonic.Forums.PostCollection PostRecords()
		{
			return new SubSonic.Forums.PostCollection().Where(Post.Columns.CreatedBy, UserName).Load();
		}

		public SubSonic.Forums.UserAnswerCollection UserAnswerRecords()
		{
			return new SubSonic.Forums.UserAnswerCollection().Where(UserAnswer.Columns.CreatedBy, UserName).Load();
		}

		public SubSonic.Forums.UserForumRoleCollection UserForumRoleRecords()
		{
			return new SubSonic.Forums.UserForumRoleCollection().Where(UserForumRole.Columns.UserName, UserName).Load();
		}

		public SubSonic.Forums.UserReadThreadCollection UserReadThreadRecords()
		{
			return new SubSonic.Forums.UserReadThreadCollection().Where(UserReadThread.Columns.UserName, UserName).Load();
		}

		public SubSonic.Forums.UserWatchedThreadCollection UserWatchedThreadRecords()
		{
			return new SubSonic.Forums.UserWatchedThreadCollection().Where(UserWatchedThread.Columns.UserName, UserName).Load();
		}

		public SubSonic.Forums.UserSearchSubscriptionCollection UserSearchSubscriptionRecords()
		{
			return new SubSonic.Forums.UserSearchSubscriptionCollection().Where(UserSearchSubscription.Columns.CreatedBy, UserName).Load();
		}

		#endregion
		
			
		
		//no foreign key tables defined (0)
		
		
		
		#region Many To Many Helpers
		
		 
		public SubSonic.Forums.ThreadCollection GetThreadCollection() { return UserProfile.GetThreadCollection(this.UserName); }

		public static SubSonic.Forums.ThreadCollection GetThreadCollection(string varUserName)
		{
			SubSonic.QueryCommand cmd = new SubSonic.QueryCommand(
				"SELECT * FROM SS_Thread INNER JOIN SS_User_WatchedThread ON "+
				"SS_Thread.ThreadID=SS_User_WatchedThread.ThreadID WHERE SS_User_WatchedThread.UserName=@UserName", UserProfile.Schema.Provider.Name);
			
			cmd.AddParameter("@UserName", varUserName, DbType.String);
			IDataReader rdr = SubSonic.DataService.GetReader(cmd);
			ThreadCollection coll = new ThreadCollection();
			coll.LoadAndCloseReader(rdr);
			return coll;
		}

		
		public static void SaveThreadMap(string varUserName, ThreadCollection items)
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_WatchedThread WHERE UserName=@UserName", UserProfile.Schema.Provider.Name);
			cmdDel.AddParameter("@UserName", varUserName);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (Thread item in items)
			{
				UserWatchedThread varUserWatchedThread = new UserWatchedThread();
				varUserWatchedThread.SetColumnValue("UserName", varUserName);
				varUserWatchedThread.SetColumnValue("ThreadID", item.GetPrimaryKeyValue());
				varUserWatchedThread.Save();
			}

		}

		public static void SaveThreadMap(string varUserName, System.Web.UI.WebControls.ListItemCollection itemList) 
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			 QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_WatchedThread WHERE UserName=@UserName", UserProfile.Schema.Provider.Name);
			cmdDel.AddParameter("@UserName", varUserName);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (System.Web.UI.WebControls.ListItem l in itemList) 
			{
				if (l.Selected) 
				{
					UserWatchedThread varUserWatchedThread = new UserWatchedThread();
					varUserWatchedThread.SetColumnValue("UserName", varUserName);
					varUserWatchedThread.SetColumnValue("ThreadID", l.Value);
					varUserWatchedThread.Save();
				}

			}

		}

		public static void SaveThreadMap(string varUserName , string[] itemList) 
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			 QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_WatchedThread WHERE UserName=@UserName", UserProfile.Schema.Provider.Name);
			cmdDel.AddParameter("@UserName", varUserName);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (string item in itemList) 
			{
				UserWatchedThread varUserWatchedThread = new UserWatchedThread();
				varUserWatchedThread.SetColumnValue("UserName", varUserName);
				varUserWatchedThread.SetColumnValue("ThreadID", item);
				varUserWatchedThread.Save();
			}

		}

		
		public static void DeleteThreadMap(string varUserName) 
		{
			QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_WatchedThread WHERE UserName=@UserName", UserProfile.Schema.Provider.Name);
			cmdDel.AddParameter("@UserName", varUserName);
			DataService.ExecuteQuery(cmdDel);
		}

		
		 
		public SubSonic.Forums.ForumRoleCollection GetForumRoleCollection() { return UserProfile.GetForumRoleCollection(this.UserName); }

		public static SubSonic.Forums.ForumRoleCollection GetForumRoleCollection(string varUserName)
		{
			SubSonic.QueryCommand cmd = new SubSonic.QueryCommand(
				"SELECT * FROM SS_ForumRole INNER JOIN SS_User_ForumRole ON "+
				"SS_ForumRole.RoleID=SS_User_ForumRole.roleID WHERE SS_User_ForumRole.userName=@userName", UserProfile.Schema.Provider.Name);
			
			cmd.AddParameter("@userName", varUserName, DbType.String);
			IDataReader rdr = SubSonic.DataService.GetReader(cmd);
			ForumRoleCollection coll = new ForumRoleCollection();
			coll.LoadAndCloseReader(rdr);
			return coll;
		}

		
		public static void SaveForumRoleMap(string varUserName, ForumRoleCollection items)
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_ForumRole WHERE userName=@userName", UserProfile.Schema.Provider.Name);
			cmdDel.AddParameter("@userName", varUserName);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (ForumRole item in items)
			{
				UserForumRole varUserForumRole = new UserForumRole();
				varUserForumRole.SetColumnValue("userName", varUserName);
				varUserForumRole.SetColumnValue("roleID", item.GetPrimaryKeyValue());
				varUserForumRole.Save();
			}

		}

		public static void SaveForumRoleMap(string varUserName, System.Web.UI.WebControls.ListItemCollection itemList) 
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			 QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_ForumRole WHERE userName=@userName", UserProfile.Schema.Provider.Name);
			cmdDel.AddParameter("@userName", varUserName);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (System.Web.UI.WebControls.ListItem l in itemList) 
			{
				if (l.Selected) 
				{
					UserForumRole varUserForumRole = new UserForumRole();
					varUserForumRole.SetColumnValue("userName", varUserName);
					varUserForumRole.SetColumnValue("roleID", l.Value);
					varUserForumRole.Save();
				}

			}

		}

		public static void SaveForumRoleMap(string varUserName , string[] itemList) 
		{
			QueryCommandCollection coll = new SubSonic.QueryCommandCollection();
			//delete out the existing
			 QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_ForumRole WHERE userName=@userName", UserProfile.Schema.Provider.Name);
			cmdDel.AddParameter("@userName", varUserName);
			coll.Add(cmdDel);
			DataService.ExecuteTransaction(coll);
			foreach (string item in itemList) 
			{
				UserForumRole varUserForumRole = new UserForumRole();
				varUserForumRole.SetColumnValue("userName", varUserName);
				varUserForumRole.SetColumnValue("roleID", item);
				varUserForumRole.Save();
			}

		}

		
		public static void DeleteForumRoleMap(string varUserName) 
		{
			QueryCommand cmdDel = new QueryCommand("DELETE FROM SS_User_ForumRole WHERE userName=@userName", UserProfile.Schema.Provider.Name);
			cmdDel.AddParameter("@userName", varUserName);
			DataService.ExecuteQuery(cmdDel);
		}

		
		#endregion
		
		#region ObjectDataSource support
		
		
		/// <summary>
		/// Inserts a record, can be used with the Object Data Source
		/// </summary>
		public static void Insert(string varUserName,int varTotalPosts,DateTime varMemberSince,string varEmail,string varSignature,int varProps,bool varIsApproved,bool varIsModerated,string varBio,double? varTimeZone,bool varHTMLEmail,bool varAllowEmailContact,string varHelpfulKeywords,string varUserRoles)
		{
			UserProfile item = new UserProfile();
			
			item.UserName = varUserName;
			
			item.TotalPosts = varTotalPosts;
			
			item.MemberSince = varMemberSince;
			
			item.Email = varEmail;
			
			item.Signature = varSignature;
			
			item.Props = varProps;
			
			item.IsApproved = varIsApproved;
			
			item.IsModerated = varIsModerated;
			
			item.Bio = varBio;
			
			item.TimeZone = varTimeZone;
			
			item.HTMLEmail = varHTMLEmail;
			
			item.AllowEmailContact = varAllowEmailContact;
			
			item.HelpfulKeywords = varHelpfulKeywords;
			
			item.UserRoles = varUserRoles;
			
		
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		
		/// <summary>
		/// Updates a record, can be used with the Object Data Source
		/// </summary>
		public static void Update(string varUserName,int varTotalPosts,DateTime varMemberSince,string varEmail,string varSignature,int varProps,bool varIsApproved,bool varIsModerated,string varBio,double? varTimeZone,bool varHTMLEmail,bool varAllowEmailContact,string varHelpfulKeywords,string varUserRoles)
		{
			UserProfile item = new UserProfile();
			
				item.UserName = varUserName;
				
				item.TotalPosts = varTotalPosts;
				
				item.MemberSince = varMemberSince;
				
				item.Email = varEmail;
				
				item.Signature = varSignature;
				
				item.Props = varProps;
				
				item.IsApproved = varIsApproved;
				
				item.IsModerated = varIsModerated;
				
				item.Bio = varBio;
				
				item.TimeZone = varTimeZone;
				
				item.HTMLEmail = varHTMLEmail;
				
				item.AllowEmailContact = varAllowEmailContact;
				
				item.HelpfulKeywords = varHelpfulKeywords;
				
				item.UserRoles = varUserRoles;
				
			item.IsNew = false;
			if (System.Web.HttpContext.Current != null)
				item.Save(System.Web.HttpContext.Current.User.Identity.Name);
			else
				item.Save(System.Threading.Thread.CurrentPrincipal.Identity.Name);
		}

		#endregion
		#region Columns Struct
		public struct Columns
		{
			 public static string UserName = @"UserName";
			 public static string TotalPosts = @"TotalPosts";
			 public static string MemberSince = @"MemberSince";
			 public static string Email = @"Email";
			 public static string Signature = @"Signature";
			 public static string Props = @"Props";
			 public static string IsApproved = @"IsApproved";
			 public static string IsModerated = @"IsModerated";
			 public static string Bio = @"Bio";
			 public static string TimeZone = @"TimeZone";
			 public static string HTMLEmail = @"HTMLEmail";
			 public static string AllowEmailContact = @"AllowEmailContact";
			 public static string HelpfulKeywords = @"HelpfulKeywords";
			 public static string UserRoles = @"UserRoles";
						
		}

		#endregion
	}

}

