using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums{
    /// <summary>
    /// Strongly-typed collection for the ThreadWatchList class.
    /// </summary>
    [Serializable]
    public partial class ThreadWatchListCollection : ReadOnlyList<ThreadWatchList, ThreadWatchListCollection>
    {        
        public ThreadWatchListCollection() {}

    }

    /// <summary>
    /// This is  Read-only wrapper class for the SS_ThreadWatchList view.
    /// </summary>
    [Serializable]
    public partial class ThreadWatchList : ReadOnlyRecord<ThreadWatchList> 
    {
    
	    #region Default Settings
	    protected static void SetSQLProps() 
	    {
		    GetTableSchema();
	    }

	    #endregion
        #region Schema Accessor
	    public static TableSchema.Table Schema
        {
            get
            {
                if (BaseSchema == null)
                {
                    SetSQLProps();
                }

                return BaseSchema;
            }

        }

    	
        private static void GetTableSchema() 
        {
            if(!IsSchemaInitialized)
            {
                //Schema declaration
                TableSchema.Table schema = new TableSchema.Table("SS_ThreadWatchList", TableType.View, DataService.GetInstance("Forums"));
                schema.Columns = new TableSchema.TableColumnCollection();
                schema.SchemaName = "dbo";
                //columns
                
                TableSchema.TableColumn colvarEmail = new TableSchema.TableColumn(schema);
                colvarEmail.ColumnName = "Email";
                colvarEmail.DataType = DbType.String;
                colvarEmail.MaxLength = 50;
                colvarEmail.AutoIncrement = false;
                colvarEmail.IsNullable = false;
                colvarEmail.IsPrimaryKey = false;
                colvarEmail.IsForeignKey = false;
                colvarEmail.IsReadOnly = false;
                
                schema.Columns.Add(colvarEmail);
                
                TableSchema.TableColumn colvarUserName = new TableSchema.TableColumn(schema);
                colvarUserName.ColumnName = "UserName";
                colvarUserName.DataType = DbType.String;
                colvarUserName.MaxLength = 50;
                colvarUserName.AutoIncrement = false;
                colvarUserName.IsNullable = false;
                colvarUserName.IsPrimaryKey = false;
                colvarUserName.IsForeignKey = false;
                colvarUserName.IsReadOnly = false;
                
                schema.Columns.Add(colvarUserName);
                
                TableSchema.TableColumn colvarThreadID = new TableSchema.TableColumn(schema);
                colvarThreadID.ColumnName = "ThreadID";
                colvarThreadID.DataType = DbType.Int32;
                colvarThreadID.MaxLength = 0;
                colvarThreadID.AutoIncrement = false;
                colvarThreadID.IsNullable = false;
                colvarThreadID.IsPrimaryKey = false;
                colvarThreadID.IsForeignKey = false;
                colvarThreadID.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadID);
                
                TableSchema.TableColumn colvarThreadUrl = new TableSchema.TableColumn(schema);
                colvarThreadUrl.ColumnName = "ThreadUrl";
                colvarThreadUrl.DataType = DbType.String;
                colvarThreadUrl.MaxLength = 50;
                colvarThreadUrl.AutoIncrement = false;
                colvarThreadUrl.IsNullable = false;
                colvarThreadUrl.IsPrimaryKey = false;
                colvarThreadUrl.IsForeignKey = false;
                colvarThreadUrl.IsReadOnly = false;
                
                schema.Columns.Add(colvarThreadUrl);
                
                TableSchema.TableColumn colvarAllowEmailContact = new TableSchema.TableColumn(schema);
                colvarAllowEmailContact.ColumnName = "AllowEmailContact";
                colvarAllowEmailContact.DataType = DbType.Boolean;
                colvarAllowEmailContact.MaxLength = 0;
                colvarAllowEmailContact.AutoIncrement = false;
                colvarAllowEmailContact.IsNullable = false;
                colvarAllowEmailContact.IsPrimaryKey = false;
                colvarAllowEmailContact.IsForeignKey = false;
                colvarAllowEmailContact.IsReadOnly = false;
                
                schema.Columns.Add(colvarAllowEmailContact);
                
                TableSchema.TableColumn colvarHTMLEmail = new TableSchema.TableColumn(schema);
                colvarHTMLEmail.ColumnName = "HTMLEmail";
                colvarHTMLEmail.DataType = DbType.Boolean;
                colvarHTMLEmail.MaxLength = 0;
                colvarHTMLEmail.AutoIncrement = false;
                colvarHTMLEmail.IsNullable = false;
                colvarHTMLEmail.IsPrimaryKey = false;
                colvarHTMLEmail.IsForeignKey = false;
                colvarHTMLEmail.IsReadOnly = false;
                
                schema.Columns.Add(colvarHTMLEmail);
                
                TableSchema.TableColumn colvarAnswerOnly = new TableSchema.TableColumn(schema);
                colvarAnswerOnly.ColumnName = "AnswerOnly";
                colvarAnswerOnly.DataType = DbType.Boolean;
                colvarAnswerOnly.MaxLength = 0;
                colvarAnswerOnly.AutoIncrement = false;
                colvarAnswerOnly.IsNullable = false;
                colvarAnswerOnly.IsPrimaryKey = false;
                colvarAnswerOnly.IsForeignKey = false;
                colvarAnswerOnly.IsReadOnly = false;
                
                schema.Columns.Add(colvarAnswerOnly);
                
                TableSchema.TableColumn colvarEmailNotify = new TableSchema.TableColumn(schema);
                colvarEmailNotify.ColumnName = "EmailNotify";
                colvarEmailNotify.DataType = DbType.Boolean;
                colvarEmailNotify.MaxLength = 0;
                colvarEmailNotify.AutoIncrement = false;
                colvarEmailNotify.IsNullable = false;
                colvarEmailNotify.IsPrimaryKey = false;
                colvarEmailNotify.IsForeignKey = false;
                colvarEmailNotify.IsReadOnly = false;
                
                schema.Columns.Add(colvarEmailNotify);
                
                
                BaseSchema = schema;
                //add this schema to the provider
                //so we can query it later
                DataService.Providers["Forums"].AddSchema("SS_ThreadWatchList",schema);
            }

        }

        #endregion
        
        #region Query Accessor
	    public static Query CreateQuery()
	    {
		    return new Query(Schema);
	    }

	    #endregion
	    
	    #region .ctors
	    public ThreadWatchList()
	    {
            SetSQLProps();
            SetDefaults();
            MarkNew();
        }

        public ThreadWatchList(bool useDatabaseDefaults)
	    {
		    SetSQLProps();
		    if(useDatabaseDefaults)
		    {
				ForceDefaults();
			}

			MarkNew();
	    }

	    
	    public ThreadWatchList(object keyID)
	    {
		    SetSQLProps();
		    LoadByKey(keyID);
	    }

    	 
	    public ThreadWatchList(string columnName, object columnValue)
        {
            SetSQLProps();
            LoadByParam(columnName,columnValue);
        }

        
	    #endregion
	    
	    #region Props
	    
          
        [XmlAttribute("Email")]
        public string Email 
	    {
		    get
		    {
			    return GetColumnValue<string>("Email");
		    }

            set 
		    {
			    SetColumnValue("Email", value);
            }

        }

	      
        [XmlAttribute("UserName")]
        public string UserName 
	    {
		    get
		    {
			    return GetColumnValue<string>("UserName");
		    }

            set 
		    {
			    SetColumnValue("UserName", value);
            }

        }

	      
        [XmlAttribute("ThreadID")]
        public int ThreadID 
	    {
		    get
		    {
			    return GetColumnValue<int>("ThreadID");
		    }

            set 
		    {
			    SetColumnValue("ThreadID", value);
            }

        }

	      
        [XmlAttribute("ThreadUrl")]
        public string ThreadUrl 
	    {
		    get
		    {
			    return GetColumnValue<string>("ThreadUrl");
		    }

            set 
		    {
			    SetColumnValue("ThreadUrl", value);
            }

        }

	      
        [XmlAttribute("AllowEmailContact")]
        public bool AllowEmailContact 
	    {
		    get
		    {
			    return GetColumnValue<bool>("AllowEmailContact");
		    }

            set 
		    {
			    SetColumnValue("AllowEmailContact", value);
            }

        }

	      
        [XmlAttribute("HTMLEmail")]
        public bool HTMLEmail 
	    {
		    get
		    {
			    return GetColumnValue<bool>("HTMLEmail");
		    }

            set 
		    {
			    SetColumnValue("HTMLEmail", value);
            }

        }

	      
        [XmlAttribute("AnswerOnly")]
        public bool AnswerOnly 
	    {
		    get
		    {
			    return GetColumnValue<bool>("AnswerOnly");
		    }

            set 
		    {
			    SetColumnValue("AnswerOnly", value);
            }

        }

	      
        [XmlAttribute("EmailNotify")]
        public bool EmailNotify 
	    {
		    get
		    {
			    return GetColumnValue<bool>("EmailNotify");
		    }

            set 
		    {
			    SetColumnValue("EmailNotify", value);
            }

        }

	    
	    #endregion
    
	    #region Columns Struct
	    public struct Columns
	    {
		    
		    
            public static string Email = @"Email";
            
            public static string UserName = @"UserName";
            
            public static string ThreadID = @"ThreadID";
            
            public static string ThreadUrl = @"ThreadUrl";
            
            public static string AllowEmailContact = @"AllowEmailContact";
            
            public static string HTMLEmail = @"HTMLEmail";
            
            public static string AnswerOnly = @"AnswerOnly";
            
            public static string EmailNotify = @"EmailNotify";
            
	    }

	    #endregion
    }

}

