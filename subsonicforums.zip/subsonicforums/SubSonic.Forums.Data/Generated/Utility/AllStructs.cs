using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace SubSonic.Forums
{
	#region Tables Struct
	public partial struct Tables
	{
		
		public static string CmsContent = @"CMS_Content";
        
		public static string CmsPage = @"CMS_Page";
        
		public static string ApplicationLog = @"SS_ApplicationLog";
        
		public static string Censorship = @"SS_Censorship";
        
		public static string FormatBlock = @"SS_FormatBlock";
        
		public static string Forum = @"SS_Forum";
        
		public static string ForumGroup = @"SS_Forum_Group";
        
		public static string ForumRole = @"SS_ForumRole";
        
		public static string MailQueue = @"SS_MailQueue";
        
		public static string Post = @"SS_Post";
        
		public static string PostType = @"SS_PostType";
        
		public static string Thread = @"SS_Thread";
        
		public static string ThreadType = @"SS_ThreadType";
        
		public static string ThreadTypeResponse = @"SS_ThreadTypeResponse";
        
		public static string UserAnswer = @"SS_User_Answer";
        
		public static string UserForumRole = @"SS_User_ForumRole";
        
		public static string UserReadThread = @"SS_User_ReadThread";
        
		public static string UserWatchedThread = @"SS_User_WatchedThread";
        
		public static string UserProfile = @"SS_UserProfile";
        
		public static string UserSearchSubscription = @"SS_UserSearchSubscription";
        
	}

	#endregion
    #region View Struct
    public partial struct Views 
    {
		
		public static string PostView = @"SS_PostView";
        
		public static string ThreadPostType = @"SS_ThreadPostType";
        
		public static string ThreadResponse = @"SS_ThreadResponses";
        
		public static string ThreadSummary = @"SS_ThreadSummary";
        
		public static string ThreadView = @"SS_ThreadView";
        
		public static string ThreadWatchList = @"SS_ThreadWatchList";
        
		public static string UserReadForum = @"SS_UserReadForums";
        
    }

    #endregion
}

#region Databases
public partial struct Databases 
{
	
	public static string Forums = @"Forums";
    
}

#endregion
