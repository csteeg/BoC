using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace SubSonic.Forums {
    
    public class ForumSettings:ConfigurationSection {

        [ConfigurationProperty("ForumName", DefaultValue = "My Forums")]
        public string ForumName {
            get { return base["ForumName"].ToString(); }
            set { base["ForumName"] = value; }
        }


        [ConfigurationProperty("AdminEmail", DefaultValue = "admin@forums.com")]
        public string AdminEmail {
            get { return base["AdminEmail"].ToString(); }
            set { base["AdminEmail"] = value; }
        }


        [ConfigurationProperty("ReplyEmail", DefaultValue = "admin@forums.com")]
        public string ReplyEmail {
            get { return base["ReplyEmail"].ToString(); }
            set { base["ReplyEmail"] = value; }
        }

        [ConfigurationProperty("SendMailIntervalMinutes", DefaultValue = 10)]
        public int SendMailIntervalMinutes {
            get { return (int)base["SendMailIntervalMinutes"]; }
            set { base["SendMailIntervalMinutes"] = value; }
        }
        [ConfigurationProperty("ForumRootUrl", DefaultValue = "http://localhost/forums")]
        public string ForumRootUrl {
            get { return base["ForumRootUrl"].ToString(); }
            set { base["ForumRootUrl"] = value; }
        }
        
        [ConfigurationProperty("NoReplyEmail", DefaultValue = "no-reply@forums.com")]
        public string NoReplyEmail {
            get { return base["NoReplyEmail"].ToString(); }
            set { base["NoReplyEmail"] = value; }
        }

        [ConfigurationProperty("MailerInterval", DefaultValue = 10)]
        public int MailerInterval {
            get { return (int)base["MailerInterval"]; }
            set { base["MailerInterval"] = value; }
        }

        static ForumSettings setting = null;
        public static ForumSettings LoadSettings() {
            if (setting == null)
                setting = (ForumSettings)System.Configuration.ConfigurationManager.GetSection("ForumService");
            return setting;
        }

    }
}
