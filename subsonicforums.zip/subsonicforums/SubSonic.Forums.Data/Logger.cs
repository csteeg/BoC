using System;
using System.Collections.Generic;
using System.Text;
using SubSonic;

namespace SubSonic.Forums {
    public class Logger {


        public static void LogIt(string message, Enums.LogContext context){
            LogIt(message, context, "System", "");
        }
        public static void LogIt(string message, Enums.LogContext context, string userName) {
            LogIt(message, context, userName, "");
        }
        public static void LogIt(string message, Enums.LogContext context, string userName, string extraInfo) {
            ApplicationLog log = new ApplicationLog();
            log.Context = Enum.GetName(typeof(Enums.LogContext), context);
            log.Description = message;
            log.LogDate = DateTime.Now;
            log.ExtraInfo = extraInfo;
            log.UserName = userName;
            log.Save(userName);

        }
        public static void LogIt(Exception x, string userName) {
            LogIt(x.Message, Enums.LogContext.Exception, userName, x.StackTrace);
        }
        public static void LogIt(Exception x) {
            LogIt(x.Message, Enums.LogContext.Exception, "System", x.StackTrace);

        }
    }
}
