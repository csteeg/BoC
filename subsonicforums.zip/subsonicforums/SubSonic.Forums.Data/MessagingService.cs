using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;
using System.Net;
using System.Net.Mail;

namespace SubSonic.Forums {
    public class MessagingService {


        static ForumSettings setting = null;

        public static string LoadTextFromManifest(string templateFileName) {
            string templateText = null;
            Assembly asm = Assembly.GetExecutingAssembly();
            Stream stream = asm.GetManifestResourceStream("SubSonic.Forums.Templates." + templateFileName);
            if (stream != null) {
                StreamReader sReader = new StreamReader(stream);
                templateText = sReader.ReadToEnd();
                sReader.Close();
            }
            return templateText;
        }

        static void LoadSettings() {
            setting= ForumSettings.LoadSettings();

        }

        public static void QueueAnswerWatchResponses(int threadID, string answeredBy) {
            LoadSettings();

            //pull the template
            string template = LoadTextFromManifest("AnsweredThreadTemplate.htm");
            string messageBody = template;

            //pull the thread to get the author's email
            Thread t = new Thread(threadID);

            //the tags are 
            //#SUBJECT#
            //#ANSWEREDBY#
            //#PROFILELINK#
            //#THREADURL#

            messageBody = messageBody.Replace("#SUBJECT#", t.Subject);
            messageBody = messageBody.Replace("#ANSWEREDBY#", answeredBy);
            messageBody = messageBody.Replace("#PROFILELINK#", Path.Combine(setting.ForumRootUrl, "/forums/forumprofile.aspx"));
            messageBody = messageBody.Replace("#THREADURL#", Path.Combine(setting.ForumRootUrl, t.ThreadUrl));

            //pull out all the users that are watching this thread for an answer, and queue them up
            ThreadWatchListCollection items = new ThreadWatchListCollection().Where(ThreadWatchList.Columns.ThreadID, threadID).Where(ThreadWatchList.Columns.AnswerOnly, true).Load();
            foreach (ThreadWatchList item in items) {
                if (!SubSonic.Utilities.Utility.IsMatch(answeredBy, item.UserName)) {
                    QueueMessage(item.UserName, setting.ForumName + ": Reply Received", messageBody);
                }
            }


        }
        public static void QueueThreadWatchResponses(int threadID, string userName) {
            LoadSettings();
            
            //pull the template
            string template = LoadTextFromManifest("WatchedThreadTemplate.htm");
            string messageBody = template;

            //pull the thread to get the author's email
            Thread t = new Thread(threadID);

            //the tags are 
            //#SUBJECT#
            //#REPLYAUTHOR#
            //#PROFILELINK#
            //#THREADURL#

            messageBody = messageBody.Replace("#SUBJECT#", t.Subject);
            messageBody = messageBody.Replace("#REPLYAUTHOR#", t.LastReplyAuthor);
            messageBody = messageBody.Replace("#PROFILELINK#", Path.Combine(setting.ForumRootUrl,"/forums/forumprofile.aspx"));
            messageBody = messageBody.Replace("#THREADURL#", Path.Combine(setting.ForumRootUrl, t.ThreadUrl));


            //pull out all the users that are watching this thread for an answer, and queue them up
            ThreadWatchListCollection items = new ThreadWatchListCollection().Where(ThreadWatchList.Columns.ThreadID, threadID).Where(ThreadWatchList.Columns.AnswerOnly, false).Load();
            foreach (ThreadWatchList item in items) {
                if (!SubSonic.Utilities.Utility.IsMatch(userName, item.UserName)) {
                    QueueMessage(item.UserName, setting.ForumName + ": Reply Received", messageBody);
                }
            }

        }

        static void QueueMessage(string userName, string subject, string messageBody) {
            UserProfile prof = new UserProfile(userName);

            MailQueue q = new MailQueue();
            q.UserName = userName;
            q.Body = messageBody;
            q.IsHtml = prof.HTMLEmail;

            //always add to the queue - this way
            //they can see all the messages if they ever
            //change their mind
            q.ShouldSend = prof.AllowEmailContact;
            q.RetryCount = 5;
            q.Subject = subject;
            q.Email = prof.Email;
            q.QueueDate = DateTime.Now;
            //save it up
            q.Save(userName);
        }

        public static void SendQueuedMessages() {
            LoadSettings();
            //pull the queued messages and send them off!
            MailQueueCollection queue = new MailQueueCollection().Where(MailQueue.Columns.WasSent, false).Load();
            
            foreach(MailQueue q in queue){
                bool result = SendEmail(q.Email, "", "", q.Subject, q.Body);
                q.LastTry = DateTime.Now;
                q.RetryCount--;

                if (result) {
                    Logger.LogIt("Message sent to " + q.Email + " RE: " + q.Subject, Enums.LogContext.Mailer, "System");

                    //set the queue as sent
                    q.WasSent = true;
                    q.SendDate = DateTime.Now;


                } else {
                    //failed for some reason - log it
                    Logger.LogIt("FAILED SEND send to " + q.Email + " RE: " + q.Subject, Enums.LogContext.Mailer, "System");

                }
                q.Save("Mailer System");
            }


        }


        public static bool SendEmail(string toList, string ccList, string bccList, string subject, string body) {
            
            System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
            using (System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage()) {
                
                bool bOut = false;

                if (!String.IsNullOrEmpty(toList)) {
                    string[] splitList = toList.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string to in splitList) {
                        message.To.Add(new MailAddress(to));
                    }
                }
                if (!String.IsNullOrEmpty(ccList)) {
                    string[] splitList = ccList.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string cc in splitList) {
                        message.CC.Add(new MailAddress(cc));
                    }
                }

                if (!String.IsNullOrEmpty(bccList)) {
                    string[] splitList = bccList.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string bcc in splitList) {
                        message.Bcc.Add(new MailAddress(bcc));
                    }
                }
                message.Subject = subject;
                message.IsBodyHtml = true;
                message.Body = body;
                try {
                    
                    client.Send(message);

                    //string returnState = "message sent";
                    //client.SendAsync(message, returnState);
                    bOut = true;
                } catch (System.Net.Mail.SmtpException x) {
                    Logger.LogIt(x);
                }
                return bOut;
            }
        }


    }
}
