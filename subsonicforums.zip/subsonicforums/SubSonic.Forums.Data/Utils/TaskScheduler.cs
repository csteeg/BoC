using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.Threading;
using System.Collections;

namespace SubSonic.Forums {
    class TaskScheduler {
    }
    ///<summary>
    ///Interface for Scheduler Jobs
    ///</summary>
    public interface ISchedulerJob {
        void Execute();
    }
      ///<summary>
      ///Sample Job
      ///</summary>
      public class MailerJob : ISchedulerJob
      {
        public void Execute()
        {
            MessagingService.SendQueuedMessages();
        }
      }
      ///<summary>
      ///Scheduler Configuration.
      ///</summary>
      public class SchedulerConfiguration
      {
        private int sleepInterval;
        private ArrayList jobs = new ArrayList();

        public int SleepInterval { get {

                return sleepInterval;
        } }
        public ArrayList Jobs { get { return jobs; } }

        public SchedulerConfiguration(int newSleepInterval)
        {
          sleepInterval = newSleepInterval;
        }
      }
      ///<summary>
      ///Scheduler Engine.
      ///</summary>
    public class Scheduler {
        private SchedulerConfiguration configuration = null;

        public Scheduler(SchedulerConfiguration config) {
            configuration = config;
        }

        public void Start()
        {
              while(true)
              {
                try
                {
                  //for each job, call the execute method
                  foreach(ISchedulerJob job in configuration.Jobs)
                  {
                    job.Execute();
                  }
                }
                catch(Exception) {}
                finally
                {
                  System.Threading.Thread.Sleep(configuration.SleepInterval);
                }
              }
        }
    }


}
