using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace SubSonic.Forums.Enums {


    public enum PostType {
        [Description("Question")]
        Question = 1,
        [Description("Suggestion")]
        Suggestion = 2,
        [Description("Comment")]
        Comment = 3,
        [Description("Reply")]
        Reply = 4,
        [Description("Problem")]
        Problem = 6
    }

    public enum ThreadResponse {
        [Description("Answered")]
        Answered = 1,
        [Description("Resolved")]
        Resolved = 2,
        [Description("Shelved")]
        Shelved = 3,
        [Description("Accepted")]
        Accepted = 4,
        [Description("Declined")]
        Declined = 5,
        [Description("Reported")]
        Reported = 6,
        [Description("Work Item")]
        WorkItem = 7,
        [Description("Thumbs Up")]
        ThumbsUp = 8,
        [Description("Thumbs Down")]
        ThumbsDown = 9,
        [Description("Committed")]
        Committed = 10,
        [Description("Good Idea")]
        GoodIdea = 16
    }

    public enum ThreadWatchOptions {
        None,
        AnswersOnly,
        All
    }

    public enum LogContext {
        Security,
        Mailer,
        Exception,
        Warning
    }

}
