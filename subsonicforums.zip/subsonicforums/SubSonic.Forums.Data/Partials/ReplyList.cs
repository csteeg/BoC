using System;
using System.Collections.Generic;
using System.Text;

namespace SubSonic.Forums {
    public partial class ReplyList {

        private bool _postIsAnswered = false;

        public bool IsAnswered {
            get { return _postIsAnswered; }
            set { _postIsAnswered = value; }
        }
        private string _answerStatus="";

        public string AnswerStatus {
            get { return _answerStatus; }
            set { _answerStatus = value; }
        }
	


        private bool _userKickedPost = false;

        public bool UserKickedPost {
            get { return _userKickedPost; }
            set { _userKickedPost = value; }
        }

        private string _kickStatus;

        public string KickStatus {
            get { return _kickStatus; }
            set { _kickStatus = value; }
        }
	

    }
}
