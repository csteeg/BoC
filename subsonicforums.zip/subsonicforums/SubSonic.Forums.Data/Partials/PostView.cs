using System;
using System.Collections.Generic;
using System.Text;

namespace SubSonic.Forums {
    public partial class PostView {

        private string _responseStatus="";

        public string ResponseStatus {
            get { return _responseStatus; }
            set { _responseStatus = value; }
        }

        public bool ShowSignature {
            get {
                 return !String.IsNullOrEmpty(Signature);
            }
        }

        private bool _showAsAnswer;

        public bool ShowAsAnswer {
            get { return _showAsAnswer; }
            set { _showAsAnswer = value; }
        }
	
	
    }

}
