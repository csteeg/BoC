using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace SubSonic.Forums {
    public partial class Forum {
        private int _threadCount=0;

        public int ThreadCount {
            get { return _threadCount; }
            set { _threadCount = value; }
        }

        private int _postCount=0;
        public int PostCount {
            get { return _postCount; }
            set { _postCount = value; }
        }

        //overriding the base method so we can include thread count
        public new void Load(DataRow dr) {
            base.Load(dr);
            try {
                this.ThreadCount = (int)dr["ThreadCount"];
                this.PostCount = (int)dr["PostCount"];
            } catch {
                //swallow it
            }
        }

        private ThreadCollection _threads=new ThreadCollection();
        /// <summary>
        /// Child collection of threads for this forum
        /// </summary>
        public ThreadCollection Threads {
            get { return _threads; }
            set { _threads = value; }
        }
	
    }
}
