using System;
using System.Collections.Generic;
using System.Text;

namespace SubSonic.Forums {
    public partial class ForumGroup {

        private ForumCollection _forums=new ForumCollection();

        public ForumCollection Forums {
            get { return _forums; }
            set { _forums = value; }
        }

        private int _forumCount;

        public int ForumCount {
            get {
                return _forums.Count;
            }
        }
	    
    }
}
