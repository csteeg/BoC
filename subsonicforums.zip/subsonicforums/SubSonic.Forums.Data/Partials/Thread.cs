using System;
using System.Collections.Generic;
using System.Text;

namespace SubSonic.Forums {
    public partial class Thread {

        private bool _userIsWatching=false;

        public bool UserIsWatching {
            get { return _userIsWatching; }
            set { _userIsWatching = value; }
        }
	

        private bool _userHasRead=false;

        public bool UserHasRead {
            get { return _userHasRead; }
            set { _userHasRead = value; }
        }


        private Forum _parentForum;

        public Forum ParentForum {
            get { return _parentForum; }
            set { _parentForum = value; }
        }
	

        private PostCollection _posts = new PostCollection();
        private PostView _threadStarter;

        public PostView ThreadStarter {
            get { return _threadStarter; }
            set { _threadStarter = value; }
        }


        private PostViewCollection _replies;
        public PostViewCollection Replies {
            get { return _replies; }
            set { _replies = value; }
        }

        private ThreadResponseCollection _answers;

        public ThreadResponseCollection Answers {
            get { return _answers; }
            set { _answers = value; }
        }
	
        private List<UserProfile> _threadPosters;
        public List<UserProfile> ThreadPosters {
            get { return _threadPosters; }
            set { _threadPosters = value; }
        }
        bool _isAnswered = false;
        public bool IsAnswered {
            get {
                return _isAnswered;

            }
        }
        private string _answerStatus;

        public string AnswerStatus {
            get { return _answerStatus; }
            set { _answerStatus = value; }
        }
	

        private ThreadTypeResponseCollection _responseOptions;

        public ThreadTypeResponseCollection ResponseOptions {
            get { return _responseOptions; }
            set { _responseOptions = value; }
        }

        private bool _userCanSetAnswer=false;

        public bool UserCanSetAnswer {
            get { return _userCanSetAnswer; }
            set { _userCanSetAnswer = value; }
        }

        private string _threadTypeDescription="";

        public string ThreadTypeDescription {
            get { return _threadTypeDescription; }
            set { _threadTypeDescription = value; }
        }

        private Enums.ThreadWatchOptions _watchOptions=Enums.ThreadWatchOptions.None;

        public Enums.ThreadWatchOptions UserWatchOption {
            get { return _watchOptions; }
            set { _watchOptions = value; }
        }
	
	
    }
}
