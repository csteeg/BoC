using System;
using System.Collections.Generic;
using System.Text;

namespace SubSonic.Forums {
    public partial class ForumGroupCollection {

        public ForumCollection GetForums(int groupID) {
            ForumCollection result = new ForumCollection();
            ForumGroup group = (ForumGroup)this.Find(groupID);
            if (group != null) {
                result = group.Forums;
            }
            return result;
        }
    }
}
