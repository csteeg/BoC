using System;
using System.Collections.Generic;
using System.Text;

namespace SubSonic.Forums {
    public partial class Post {

        private Enums.PostType _postType;

        public Enums.PostType PostTypeEnum {
            get { return _postType; }
            set { _postType = value; }
        }
	
	
    }
}
