using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
namespace SubSonic.Forums {
    public partial class ForumCollection {

        public new void Load(DataTable tbl) {
            foreach (DataRow dr in tbl.Rows) {
                Forum item = new Forum();
                item.Load(dr);
                Add(item);
            }
        }
    }
}
