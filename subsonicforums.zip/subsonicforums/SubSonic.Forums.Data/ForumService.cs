using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Text.RegularExpressions;
using Manoli.Utils.CSharpFormat;
using System.Collections;

namespace SubSonic.Forums {
    public class ForumService {
    

        public static void CreateUserProfile(string userName, string email){ 
            
            UserProfile prof = new SubSonic.Forums.UserProfile();
            prof.UserName = userName;
            prof.Email = email;
            prof.TotalPosts = 0;
            prof.MemberSince = DateTime.Now;
            prof.AllowEmailContact = true;

            prof.Save(userName);

        }
        public static ForumGroupCollection GetForumGroups(){
            string sql = string.Empty;
            ForumGroupCollection result = new ForumGroupCollection();

            DataSet ds = SPs.GetForumGroups().GetDataSet();

            if (ds.Tables.Count > 0) {
                //first, get the groups
                ForumGroupCollection groups = new ForumGroupCollection();
                groups.Load(ds.Tables[0]);

                //second table is forums
                ForumCollection forums = new ForumCollection();
                forums.Load(ds.Tables[1]);


                //now, loop the groups and load up the result set
                foreach (ForumGroup group in groups) {

                    //loop the forums and add them in
                    foreach (Forum forum in forums) {
                        if (forum.GroupID == group.GroupID) {
                            group.Forums.Add(forum);
                        }
                    }
                    result.Add(group);
                }

            }
            return result;

        }

        public static ThreadCollection GetForumThreadList(string authorName, int pageNumber) {

            Query q = new Query(Thread.Schema).WHERE("createdBy", authorName).AND("Deleted", 0).ORDER_BY("LastReplyDate", "DESC");
            q.PageSize = 50;
            q.PageIndex = pageNumber;

            ThreadCollection threads = new ThreadCollection();
            threads.LoadAndCloseReader(q.ExecuteReader());


            return threads;

        }
        public static ThreadCollection GetForumThreadList(int forumID, int pageNumber, string userName) {

            Query q = new Query(Thread.Schema).WHERE("forumID", forumID).AND("Deleted", 0).ORDER_BY("LastReplyDate", "DESC");
            q.PageSize = 50;
            q.PageIndex = pageNumber;

            ThreadCollection threads = new ThreadCollection();
            threads.LoadAndCloseReader(q.ExecuteReader());

            //load up the user's read threads
            if (!String.IsNullOrEmpty(userName)) {
                q = new Query("SS_UserReadForums").WHERE("userName", userName).AND("ForumID", forumID);
                UserReadThreadCollection readThreads = new UserReadThreadCollection();
                readThreads.LoadAndCloseReader(q.ExecuteReader());

                foreach (UserReadThread read in readThreads) {
                    foreach (Thread t in threads) {
                        if (read.ThreadID == t.ThreadID)
                            t.UserHasRead = true;
                    }
                }
            }

            return threads;

        }
        public static void EditPost(int postID, string newText, string userName) {
            Post p = new Post(postID);

            if (p.IsLoaded) {
                string formattedText = FormatPostBody(newText);
                p.PostText = newText;

                //weird bug with the parser
                if (formattedText.StartsWith("<br><br>")) {
                    formattedText = formattedText.Remove(0, 8);
                }
                p.FormattedPostText = formattedText;
                //save it
                p.Save(userName);
            }


        }
        public static string SaveNewPost(Post p, string userName, int forumID, int threadTypeID) {

            //make sure there's no post already with this exact text
            Post pCheck = new Post("postText", p.PostText);
            p.PostTypeID = 1;
            if (!pCheck.IsLoaded) {

                //format the new post bits
                //format the reply
                string formattedText = FormatPostBody(p.PostText);
                p.Subject = CleanPostText(p.Subject);

                //weird bug with the parser
                if (formattedText.StartsWith("<br><br>")) {
                    formattedText = formattedText.Remove(0, 8);
                }



                p.FormattedPostText = formattedText;

                //create new thread
                Thread t = new Thread();
                t.Subject = p.Subject;
                t.ForumID = forumID;
                t.LastReplyDate = DateTime.Now;
                t.LastViewDate = DateTime.Now;
                t.LastReplyAuthor = userName;
                t.Resolution = "Open";
                t.ThreadTypeID = threadTypeID;

                Query q = new Query(Tables.ThreadType).WHERE("threadTypeID", threadTypeID);
                q.SelectList = "description";
                t.Resolution = q.ExecuteScalar().ToString();
                
                t.Save(userName);

                //reset status
                t.IsNew = false;

                //format the return url
                t.ThreadUrl = FormatThreadUrl(t);
                p.ThreadID = t.ThreadID;

                p.Save(userName);
                
                //save the start post info
                t.StartPostID = p.PostID;
                t.Save(userName);
               

                //put this user in as watching this thread by default
                SetThreadWatch(Enums.ThreadWatchOptions.All, userName, t.ThreadID);

                return t.ThreadUrl;


            } else {

                throw new Exception("This is a duplicate post - not allowed");

            }

        }
        public static int SaveReply(Post reply, string userName) {
            
            //format the reply
            string formattedText = FormatPostBody(reply.PostText);

            //weird bug with the parser
            if (formattedText.StartsWith("<br><br>")) {
                formattedText=formattedText.Remove(0, 8);
            }

            //replies are just regular posts
            reply.FormattedPostText = formattedText;
            
            //append the signature, if there is one
            UserProfile p = new UserProfile(userName);
            reply.AuthorEmail = p.Email;
            reply.Save(userName);

            //update the Thread
            Thread t = new Thread(reply.ThreadID);
            t.LastReplyAuthor = userName;
            t.LastReplyDate = DateTime.Now;
            t.TotalReplies = new Query(Post.Schema).WHERE("threadID", t.ThreadID).GetCount("postID");

            t.Save(userName);


            //update all of the Read Threads
            Query q = new Query(UserReadThread.Schema).WHERE("threadID", t.ThreadID).AND("userName", Comparison.NotEquals, userName);
            q.QueryType = QueryType.Delete;
            q.Execute();


            //notifications
            MessagingService.QueueThreadWatchResponses(t.ThreadID,userName);

            return reply.PostID;

        }
        public static void ChangeThreadPostType(int threadID, int newTypeID, string userName) {

            //pull the thread
            Thread t = new Thread(threadID);
            ThreadType threadType = new ThreadType(newTypeID);

            t.ThreadTypeID = newTypeID;

            //reset the Resolution of the thread
            t.Resolution = threadType.Description;

            //save em
            t.Save(userName);

        }


        public static string FormatForumUrl(Forum f) {
            string result = f.ForumName;

            //string out extra spaces
            result = SubSonic.Sugar.Strings.Squeeze(result);

            //set all spaces to dashes
            result = result.Replace(" ", "-");

            //set to lower case
            result = result.ToLower();
            
            //strip out URL bad characters
            result = result.Replace("&", "").Replace(">", "").Replace("%", "");

            return result + ".aspx";
        }

        public static string FormatThreadUrl(Thread t) {
            Forum f = new Forum(t.ForumID);
            string forumUrl = f.ForumUrl.Replace(".aspx", "");
            string threadUrl = "thread/" + forumUrl + "/" + t.ThreadID.ToString() + ".aspx";
            //format the return url
            return threadUrl;
            
        }
        /// <summary>
        /// Returns a Thread object with all the display information ready to go
        /// </summary>
        /// <param name="threadID">The ID of the thread</param>
        /// <param name="userName">The user wanting to view the thread</param>
        /// <returns></returns>
        public static Thread GetThreadDisplay(int threadID, string userName) {

           
            //wrap in single connection
            Thread result = new Thread();

            DataSet ds = SPs.GetThread(threadID, userName).GetDataSet();

            //thread info
            result.Load(ds.Tables[0]);
            result.UserCanSetAnswer = (bool)ds.Tables[0].Rows[0]["authorcandesignateanswer"];
            result.ThreadTypeDescription = ds.Tables[0].Rows[0]["threadtype"].ToString();

            //starter post
            result.ThreadStarter = new PostView();
            result.ThreadStarter.Load(ds.Tables[1]);
            
            
            //replies
            result.Replies = new PostViewCollection();
            result.Replies.Load(ds.Tables[2]);
            
            //parent forums
            result.ParentForum = new Forum();
            result.ParentForum.Load(ds.Tables[3]);


            //ansewrs
            result.Answers = new ThreadResponseCollection();
            result.Answers.Load(ds.Tables[4]);
            
            //thread posters
            //loop the replies
            result.ThreadPosters = new List<UserProfile>();
            ArrayList collectedNames = new ArrayList();
            UserProfile threadAuthor = new UserProfile();
            threadAuthor.UserName = result.ThreadStarter.CreatedBy;
            result.ThreadPosters.Add(threadAuthor);
            collectedNames.Add(threadAuthor.UserName);

            UserProfile prof = null;
            foreach (PostView post in result.Replies) {
                prof = new UserProfile();
                prof.UserName = post.CreatedBy;
                if (!collectedNames.Contains(prof.UserName)) {
                    result.ThreadPosters.Add(prof);
                    collectedNames.Add(prof.UserName);
                }
            }


            //response options
            result.ResponseOptions = new ThreadTypeResponseCollection();
            result.ResponseOptions.Load(ds.Tables[5]);
            
            //Is Watched
            result.UserIsWatching = (bool)ds.Tables[6].Rows[0][0];



            return result;

        }

        public static void DeleteThread(int threadID) {

            //delete the posts
            Post.Delete("threadID", threadID);

            //delete the thread
            Thread.Delete(threadID);

        }
        
        public static string FormatPostBody(string postText) {

            //first, clean up any bad words and script bombs
            string result = CleanPostText(postText);


            //make sure there's no script bombs hidden
            result = SubSonic.Utilities.Utility.FastReplace(result, "<script", "BLOCKED", StringComparison.InvariantCultureIgnoreCase);

            //html encode
            result = System.Web.HttpUtility.HtmlEncode(result);


            //parse the wiki text
            result = WikiParser.GenerateWikiText(result);


            //these are Regex/Replace definitions from the DB
            FormatBlockCollection blocks = new FormatBlockCollection().Load();
            System.Text.RegularExpressions.Regex reg;
            
            //loop the formatters, and do some special trickery with the quote and the code tags
            foreach (FormatBlock block in blocks) {
                reg = new System.Text.RegularExpressions.Regex(block.Definition,RegexOptions.Singleline);
                MatchCollection matches = reg.Matches(result);

                string startBlockWith = "";
                string endBlockWith = "";

                startBlockWith = block.StartBlockWith;
                endBlockWith = block.EndBlockWith;


                int matchCount = 1;
                foreach (Match match in matches) {
                    if (block.Description == "Quote") {
                        string quoteText = match.Value;
                        //see if there is a "user=" attribute
                        if (match.Value.ToLower().StartsWith("[quote user=")) {
                            quoteText = quoteText.Replace("[quote user=", "");
                            
                            //read in the user's name to the next quote
                            string userName = quoteText.Substring(0, quoteText.IndexOf("]"));
                            userName = userName.Replace("\"", "").Trim();

                            //now remove the userName and the following bits
                            quoteText = quoteText.Replace(userName + "]", "").Trim();

                            //do the transform
                            quoteText = block.Replacement.Replace("#TEXT#", "<b>" + userName + " said:</b><br><br> \"" + quoteText + "\"");
                        }

                        result = result.Replace(match.Value, quoteText);

                    } else if (block.Description == "Code") {

                        //determine the language
                        string lang = "C#";
                        string codeText = "";
                        if (match.Value.ToLower().StartsWith("[code language=")) {
                            codeText = match.Value.Replace("[code language=", "");

                            //read in the language name to the next quote
                            lang = codeText.Substring(0, codeText.IndexOf("]"));
                            lang = lang.Replace("\"", "").Trim();


                        } else {
                            codeText = match.Value.Replace("[code]", "");
                        }
                        codeText=codeText.Replace("[/code]","");

                        //now remove the userName and the following bits
                        codeText = codeText.Replace(lang + "]", "").Trim();

                        //use CsharpFormat to transform the output
                        switch (lang.ToLower()) {
                            case "html":
                                
                                HtmlFormat html=new HtmlFormat();
                                codeText=html.FormatCode(codeText);
                                break;
                            case "t-sql":
                            case "sql":
                                TsqlFormat sql=new TsqlFormat();
                                codeText = sql.FormatCode(codeText);
                                break;
                            case "vb":
                            case "vb.net":
                                VisualBasicFormat vb = new VisualBasicFormat();
                                codeText = vb.FormatCode(codeText);
                                break;
                            default:
                                CSharpFormat f = new CSharpFormat();
                                codeText = f.FormatCode(codeText);
                                break;

                        }

                        //do the transform
                        codeText = block.Replacement.Replace("#TEXT#", codeText);
                        result = result.Replace(match.Value, codeText);


                    } else {

                        //regular transforms
                        string transformText = match.Value;

                        if (matchCount > 1)
                            startBlockWith = "";

                        transformText = startBlockWith+block.Replacement.Replace("#TEXT#", transformText).Replace(block.StartTag, "").Replace(block.EndTag, "");


                        if(matchCount==matches.Count)
                            transformText = transformText+endBlockWith;
                        
                        result = result.Replace(match.Value, transformText);




                    }

                    matchCount++;
                }


            }

            result = result.Replace("\n", "<br>");
            return result;

        }

        public static void SetPostAsAnswer(int postID, Enums.ThreadResponse responseType, string userName) {
            
            Post p = new Post(postID);
            Thread t = new Thread(p.ThreadID);

            ThreadTypeResponse response = new ThreadTypeResponse((int)responseType);
            
            //set the denormalized thread response
            t.Resolution = response.Description;
            t.Save(userName);

            p.IsAnswer = true;

            //set the props accordingly
            int propsForThreadAuthor = response.ThreadAuthorPropsValue;
            int propsForAnswerer = response.AnswererPropsValue;

            UserProfile prof = null;
            if (propsForThreadAuthor > 0) {
                prof = new UserProfile(t.CreatedBy);
                prof.Props += propsForThreadAuthor;
                prof.Save(userName);
            }
            if (propsForAnswerer > 0) {
                prof = new UserProfile(p.CreatedBy);
                prof.Props += propsForThreadAuthor;
                prof.Save(userName);

            }
            

            //remove this post from the answers if it's in there
            DeleteAnswer(postID);
            
            //add the response to the responses table
            UserAnswer answer = new UserAnswer();
            answer.PostID = postID;
            answer.ThreadTypeResponseID = response.ThreadTypeResponseID;
            answer.CreatedBy = p.CreatedBy;
            answer.CreatedOn = DateTime.Now;

            answer.Save(userName);
            
            //notifications

            MessagingService.QueueAnswerWatchResponses(t.ThreadID, p.CreatedBy);



        }
        public static void DeletePost(int postID) {
            Post.Delete(postID);
        }
        static void DeleteAnswer(int postID) {
            //remove this post from the answers if it's in there
            Query q = new Query(Tables.UserAnswer).WHERE(UserAnswer.Columns.PostID, postID);
            q.QueryType = QueryType.Delete;
            q.Execute();

        }
        public static void RemoveAnswer(int postID, string userName) {

            Query q = new Query(UserAnswer.Schema).WHERE(Post.Columns.PostID, postID).AND(Post.Columns.CreatedBy, userName);
            UserAnswer answer = new UserAnswer();
            answer.LoadAndCloseReader(q.ExecuteReader());
            
            //pull the post
            Post p = new Post(postID);

            //pull the thread
            Thread t = new Thread(p.ThreadID);

            //pull the response type
            ThreadTypeResponse responseType = answer.ThreadTypeResponse;
            
            //set the props accordingly
            int propsForThreadAuthor = responseType.ThreadAuthorPropsValue;
            int propsForAnswerer = responseType.AnswererPropsValue;



            //debit the props
            UserProfile prof = null;
            if (propsForThreadAuthor > 0) {
                prof = new UserProfile(t.CreatedBy);
                prof.Props -= propsForThreadAuthor;
                prof.Save(userName);
            }
            if (propsForAnswerer > 0) {
                prof = new UserProfile(p.CreatedBy);
                prof.Props -= propsForThreadAuthor;
                prof.Save(userName);

            }

            //remove this post from the answers if it's in there
            DeleteAnswer(postID);


            //reset the resolution to the thread type
            t.Resolution = t.ThreadType.Description;
            t.Save(userName);




        }
        


        public static string CleanPostText(string postText) {
            string result = postText;
            CensorshipCollection baddies = new CensorshipCollection().Load();
            //loop the collection and replace the bad bits

            // Regex search and replace
            RegexOptions options = RegexOptions.IgnoreCase;

            foreach (Censorship c in baddies) {
                //result=SubSonic.Utilities.Utility.FastReplace(result, "\\b"+c.Expression, c.Replacement, StringComparison.InvariantCultureIgnoreCase);
                Regex regex = new Regex(@"\b"+c.Expression, options);
                string input = result;
                string replacement = c.Replacement;
                result = regex.Replace(input, replacement);

            }
            return result;

        }


        public static void SetThreadWatch(Enums.ThreadWatchOptions option, string userName, int threadID) {

            //first, make sure there aren't any records there
            Query q = new Query(Tables.UserWatchedThread).WHERE(UserWatchedThread.Columns.UserName, userName).AND(UserWatchedThread.Columns.ThreadID, threadID);
            q.QueryType = QueryType.Delete;
            q.Execute();

            Thread thread = new Thread(threadID);

            if (option==Enums.ThreadWatchOptions.All || option==Enums.ThreadWatchOptions.AnswersOnly) {
                //create a new map record and save
                UserWatchedThread t = new UserWatchedThread();
                t.UserName = userName;
                t.ThreadID = threadID;
                t.ThreadUrl = thread.ThreadUrl;
                t.CreatedOn = DateTime.Now;
                
                t.AnswerOnly = option == Enums.ThreadWatchOptions.AnswersOnly;

                t.Save(userName);

            }
        }



    }
}
